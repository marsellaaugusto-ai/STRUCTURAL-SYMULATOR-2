"""
main.py — entry point. Wires the five tabs (Truss, Beam, Arch, Cable,
Cable Web) into one ttk.Notebook. Run this file to launch the app:

    python main.py

Everything lives together under this folder: common.py and main.py here,
plus each tab's code in its own subpackage under apps/ (apps/truss/,
apps/beam/, apps/arch/, apps/cable/, apps/cable_web/). The whole
structural_simulator_modules/ folder must be kept together and intact --
don't move main.py out on its own.

If you hit "ModuleNotFoundError: No module named 'apps'" (common in VS
Code depending on how Run/Debug is configured, or if the editor's working
directory isn't this folder), it's because Python's import path didn't
include this folder. The sys.path insert below fixes that automatically
by adding this script's own directory to the path before anything else
is imported, regardless of what directory the process was actually
launched from.
"""
import os
import sys

# Make sure THIS folder (the one main.py lives in -- which also contains
# apps/ and common.py) is importable no matter how this script was
# launched (double-click, `python main.py` from elsewhere, VS Code
# Run/Debug with a different cwd, etc.). Without this, imports below can
# fail with "ModuleNotFoundError: No module named 'apps'" purely because
# of how the process happened to be started, not because of any missing
# file.
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

import tkinter as tk
from tkinter import ttk

from apps.truss.truss_app import TrussApp
from apps.beam.beam_app import BeamApp
from apps.arch.arch_app import ArchApp
from apps.cable.cable_app import CableApp
from apps.cable_web.cable_web_app import CableWebApp

class App:
    def __init__(self, root):
        # root is always tk.Tk() when launched from __main__
        try:
            root.title('Structural Engineering Calculator')
            root.resizable(True, True)
        except Exception:
            pass   # safety: never called with a Frame

        style = ttk.Style()
        try:
            style.theme_use('clam')
        except Exception:
            pass

        nb = ttk.Notebook(root)
        nb.pack(fill='both', expand=True)

        truss_tab = tk.Frame(nb)
        beam_tab = tk.Frame(nb)
        arch_tab = tk.Frame(nb)
        cable_tab = tk.Frame(nb)
        cable_web_tab = tk.Frame(nb)
        nb.add(truss_tab, text='Truss')
        nb.add(beam_tab, text='Beam')
        nb.add(arch_tab, text='Arch')
        nb.add(cable_tab, text='Cable')
        nb.add(cable_web_tab, text='Cable Web')

        TrussApp(truss_tab)
        beam_app = BeamApp(beam_tab)
        beam_app.pack(fill='both', expand=True)
        arch_app = ArchApp(arch_tab)
        arch_app.pack(fill='both', expand=True)
        cable_app = CableApp(cable_tab)
        cable_app.pack(fill='both', expand=True)
        cable_web_app = CableWebApp(cable_web_tab)
        cable_web_app.pack(fill='both', expand=True)


# ═══════════════════════════════════════════════════════════════════════════════
if __name__ == '__main__':
    root = tk.Tk()
    App(root)
    root.mainloop()