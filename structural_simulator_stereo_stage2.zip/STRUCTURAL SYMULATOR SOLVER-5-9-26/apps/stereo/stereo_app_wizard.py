"""The Custom Surface Wizard dialog: build a mesh from a typed expression.

A self-contained Toplevel that lets the user define a surface either as a
height field z = f(x, y) or as a full parametric x/y/z triple, choose the
sampling domain (Cartesian or polar), the module pattern and the layer
depth, and generate either one surface or a double layer between two.

Expression parsing lives in expr_math.py and the sampling itself in
stereo_geometry_custom_surface.py -- this module is only the dialog.
"""
import math
import tkinter as tk
from tkinter import ttk

from apps.stereo import stereo_geometry as sg
from apps.stereo import expr_math as em
from apps.stereo.stereo_app_constants import BG
from apps.stereo import stereo_app_wizard_keypad as keypad


class StereoWizardMixin:
    """The Custom Surface Wizard dialog."""

    def _open_custom_surface_wizard(self):
        """A Toplevel dialog for defining a surface by typed expression
        (a GeoGebra-style calculator palette inserts operators/functions
        into whichever expression field last had focus) and sampling it
        into a mesh: a domain coordinate system (Cartesian or Polar), a
        module pattern (square/diagonal/isometric), and either a single
        surface (2D one layer, or 3D that surface plus an auto-offset
        second layer) or two independently-defined surfaces connected as
        a top/bottom double layer -- see stereo_geometry.custom_surface_grid
        and custom_surface_between for what each choice actually builds.
        """
        win = tk.Toplevel(self.root)
        win.title('Custom Surface Wizard')
        win.geometry('680x800')

        # Everything is built into a SCROLLING body rather than straight into
        # the Toplevel. In two-surface mode the dialog carries two surface
        # panels with a keypad each and needs 829px of height -- past the
        # window, which left the Generate button off the bottom edge with no
        # scrollbar and no way to reach it. The window still sizes itself to
        # its content where the screen allows; the scrollbar is what makes
        # the dialog finishable when it does not.
        body_canvas = tk.Canvas(win, bg=BG, highlightthickness=0)
        body_sb = tk.Scrollbar(win, orient='vertical', command=body_canvas.yview)
        body_canvas.configure(yscrollcommand=body_sb.set)
        body_sb.pack(side='right', fill='y')
        body_canvas.pack(side='left', fill='both', expand=True)
        body = tk.Frame(body_canvas, bg=BG)
        body_window = body_canvas.create_window((0, 0), window=body, anchor='nw')

        def _fit_body(_event=None):
            body_canvas.configure(scrollregion=body_canvas.bbox('all'))
            body_canvas.itemconfigure(body_window, width=body_canvas.winfo_width())

        body.bind('<Configure>', _fit_body)
        body_canvas.bind('<Configure>', _fit_body)
        for seq in ('<MouseWheel>', '<Button-4>', '<Button-5>'):
            body_canvas.bind_all(seq, lambda e: body_canvas.yview_scroll(
                -1 if getattr(e, 'delta', 0) > 0 or e.num == 4 else 1, 'units')
                if body_canvas.winfo_exists() else None)
        win.bind('<Destroy>', lambda e: [body_canvas.unbind_all(sq) for sq in
                                         ('<MouseWheel>', '<Button-4>', '<Button-5>')]
                 if e.widget is win else None)

        # Every tk.*Var below is created with master=win explicitly, not
        # left to default: a StringVar/IntVar/etc. with no master binds
        # itself to whatever tkinter._default_root happens to be at THAT
        # moment, which is not necessarily the Tcl interpreter `win`'s own
        # widgets actually live in when more than one Tk() root exists in
        # the process (e.g. one per test file's own session fixture, as
        # in this app's own test suite) -- when it is not, the widget and
        # its "own" Python Variable object silently talk to two different
        # interpreters, so editing an Entry never reaches var.get() at all
        # (found by running this dialog's tests as part of the FULL suite
        # rather than alone: every field read back as its untouched
        # default, no matter what the widget visibly showed).
        active_entry = {'widget': None}

        def insert_token(text, cursor_back=0):
            w = active_entry['widget']
            if w is None:
                return
            w.insert(tk.INSERT, text)
            if cursor_back:
                w.icursor(w.index(tk.INSERT) - cursor_back)
            w.focus_set()

        def backspace():
            """Delete the character before the caret, like the ⌫ key on
            GeoGebra's own keyboard. Without it the palette can only ever
            add, and a mistyped function has to be fixed with the physical
            keyboard -- which is the workflow the palette exists to avoid."""
            w = active_entry['widget']
            if w is None:
                return
            if w.selection_present():
                w.delete('sel.first', 'sel.last')
            else:
                at = w.index(tk.INSERT)
                if at > 0:
                    w.delete(at - 1, at)
            w.focus_set()

        def make_expr_row(parent, label_text, var):
            row = tk.Frame(parent, bg=BG)
            row.pack(fill='x', padx=6, pady=2)
            tk.Label(row, text=label_text, bg=BG, width=9, anchor='w',
                    font=('Helvetica', 9)).pack(side='left')
            entry = tk.Entry(row, textvariable=var, font=('Helvetica', 9))
            entry.pack(side='left', fill='x', expand=True)
            entry.bind('<FocusIn>', lambda e, w=entry: active_entry.__setitem__('widget', w))
            # The keypad needs a target BEFORE anyone has clicked into a
            # field, or the first key press vanishes with no feedback --
            # pressing sqrt on a freshly-opened wizard has an obvious
            # intended destination, and it is the field the palette sits
            # under. Only the first row of each panel claims it; a click
            # moves it anywhere via the FocusIn binding above.
            if active_entry['widget'] is None:
                active_entry['widget'] = entry
            return entry

        def make_palette(parent):
            """GeoGebra's own keyboard, tab for tab.

            The keys carry real notation -- √, π, x², |x|, × -- and insert the
            ASCII expr_math compiles, so the expression reads like the
            mathematics while staying inside the parser's whitelist. See
            stereo_app_wizard_keypad for the layout and for why GeoGebra's
            Greek and logic tabs are not reproduced.
            """
            box = tk.LabelFrame(parent, text='Insert (into the last-focused field above)',
                                bg=BG, font=('Helvetica', 8, 'bold'))
            box.pack(fill='x', padx=6, pady=(2, 6))
            book = ttk.Notebook(box)
            book.pack(fill='x', padx=3, pady=3)
            for tab_name, rows in keypad.TABS:
                page = tk.Frame(book, bg=BG)
                book.add(page, text=tab_name)
                for keys in rows:
                    row = tk.Frame(page, bg=BG)
                    row.pack(anchor='w')
                    for label, text, back in keys:
                        if text is None:          # the ⌫ key deletes, never inserts
                            cmd = backspace
                        else:
                            cmd = (lambda t=text, b=back: insert_token(t, b))
                        tk.Button(row, text=label, width=5,
                                 font=('DejaVu Sans', 9), command=cmd
                                 ).pack(side='left', padx=1, pady=1)

        def make_surface_panel(parent, title):
            """One surface's own definition block: height-field or
            parametric, its own expression field(s), and its own copy of
            the calculator palette. Returns a zero-arg callable that
            compiles the CURRENT field contents into a surface(p, q) ->
            (x, y, z) callable, raising expr_math.ExpressionError for a
            bad expression -- compiled fresh on every call (not once at
            panel-build time) so editing a field after an earlier failed
            Generate attempt is picked up without reopening the dialog.

            Returns (build, fill, first_entry); `first_entry` is the panel's
            own leading expression field, which is where the keypad types
            when nobody has clicked into anything yet."""
            box = tk.LabelFrame(parent, text=title, bg=BG, font=('Helvetica', 9, 'bold'))
            box.pack(fill='x', padx=6, pady=4)

            surf_type = tk.StringVar(master=win, value='height')
            type_row = tk.Frame(box, bg=BG)
            type_row.pack(fill='x', padx=6, pady=2)
            tk.Radiobutton(type_row, text='Height field: z = f(x, y)', value='height',
                          variable=surf_type, bg=BG, font=('Helvetica', 8),
                          command=lambda: toggle()).pack(anchor='w')
            tk.Radiobutton(type_row, text='Parametric: x, y, z of (u, v) -- for a shape '
                                         'no height field can express (a torus, a cylinder...)',
                          value='param', variable=surf_type, bg=BG, font=('Helvetica', 8),
                          wraplength=520, justify='left',
                          command=lambda: toggle()).pack(anchor='w')

            z_var = tk.StringVar(master=win, value='0')
            height_frame = tk.Frame(box, bg=BG)
            first_entry = make_expr_row(height_frame, 'z(x,y) =', z_var)

            x_var = tk.StringVar(master=win, value='u')
            y_var = tk.StringVar(master=win, value='v')
            zp_var = tk.StringVar(master=win, value='0')
            param_frame = tk.Frame(box, bg=BG)
            make_expr_row(param_frame, 'x(u,v) =', x_var)
            make_expr_row(param_frame, 'y(u,v) =', y_var)
            make_expr_row(param_frame, 'z(u,v) =', zp_var)

            def toggle():
                if surf_type.get() == 'height':
                    param_frame.pack_forget()
                    height_frame.pack(fill='x')
                else:
                    height_frame.pack_forget()
                    param_frame.pack(fill='x')

            height_frame.pack(fill='x')
            make_palette(box)

            def build():
                if surf_type.get() == 'height':
                    return sg.make_height_field_surface(z_var.get())
                return sg.make_parametric_surface(x_var.get(), y_var.get(), zp_var.get())

            def fill(kind, expressions):
                """Put an example's own surface back into these fields."""
                surf_type.set('height' if kind == 'height' else 'param')
                if kind == 'height':
                    z_var.set(expressions.get('z', '0'))
                else:
                    x_var.set(expressions.get('x', 'u'))
                    y_var.set(expressions.get('y', 'v'))
                    zp_var.set(expressions.get('z', '0'))
                toggle()

            return build, fill, first_entry

        # ── mode: one surface, or two connected as a top/bottom double layer ──
        mode_var = tk.StringVar(master=win, value='single')
        mode_row = tk.Frame(body, bg=BG)
        mode_row.pack(fill='x', padx=6, pady=(6, 2))
        tk.Radiobutton(mode_row, text='Single surface', value='single', variable=mode_var,
                      bg=BG, command=lambda: on_mode_change()).pack(side='left', padx=(0, 12))
        tk.Radiobutton(mode_row, text='Two surfaces (top + bottom)', value='between',
                      variable=mode_var, bg=BG, command=lambda: on_mode_change()
                     ).pack(side='left')

        surfaces_frame = tk.Frame(body, bg=BG)
        surfaces_frame.pack(fill='x')
        single_frame = tk.Frame(surfaces_frame, bg=BG)
        single_build, single_fill, single_first = make_surface_panel(
            single_frame, 'Surface')
        between_frame = tk.Frame(surfaces_frame, bg=BG)
        top_build, top_fill, top_first = make_surface_panel(
            between_frame, 'Top surface')
        bottom_build, bottom_fill, _bottom_first = make_surface_panel(
            between_frame, 'Bottom surface')
        single_frame.pack(fill='x')

        # ── domain ──────────────────────────────────────────────────────────
        domain_box = tk.LabelFrame(body, text='Domain', bg=BG, font=('Helvetica', 9, 'bold'))
        domain_box.pack(fill='x', padx=6, pady=4)
        coord_var = tk.StringVar(master=win, value='cartesian')
        coord_row = tk.Frame(domain_box, bg=BG)
        coord_row.pack(fill='x', padx=6, pady=2)
        tk.Radiobutton(coord_row, text='Cartesian', value='cartesian', variable=coord_var,
                      bg=BG, command=lambda: on_coord_change()).pack(side='left')
        tk.Radiobutton(coord_row, text='Polar', value='polar', variable=coord_var,
                      bg=BG, command=lambda: on_coord_change()).pack(side='left')
        coord_hint = tk.Label(domain_box, text='', bg=BG, fg='#666', font=('Helvetica', 8))
        coord_hint.pack(anchor='w', padx=6)

        p0_var = tk.DoubleVar(master=win, value=-5.0)
        p1_var = tk.DoubleVar(master=win, value=5.0)
        q0_var = tk.DoubleVar(master=win, value=-5.0)
        q1_var = tk.DoubleVar(master=win, value=5.0)
        n1_var = tk.IntVar(master=win, value=8)
        n2_var = tk.IntVar(master=win, value=8)

        p_label_var = tk.StringVar(master=win, value='p range:')
        prow = tk.Frame(domain_box, bg=BG)
        prow.pack(fill='x', padx=6, pady=2)
        tk.Label(prow, textvariable=p_label_var, bg=BG, width=10, anchor='w',
                font=('Helvetica', 9)).pack(side='left')
        tk.Entry(prow, textvariable=p0_var, width=8).pack(side='left')
        tk.Label(prow, text='to', bg=BG).pack(side='left', padx=2)
        tk.Entry(prow, textvariable=p1_var, width=8).pack(side='left')
        tk.Label(prow, text='n1:', bg=BG).pack(side='left', padx=(10, 2))
        tk.Entry(prow, textvariable=n1_var, width=5).pack(side='left')

        q_label_var = tk.StringVar(master=win, value='q range:')
        qrow = tk.Frame(domain_box, bg=BG)
        qrow.pack(fill='x', padx=6, pady=2)
        tk.Label(qrow, textvariable=q_label_var, bg=BG, width=10, anchor='w',
                font=('Helvetica', 9)).pack(side='left')
        tk.Entry(qrow, textvariable=q0_var, width=8).pack(side='left')
        tk.Label(qrow, text='to', bg=BG).pack(side='left', padx=2)
        tk.Entry(qrow, textvariable=q1_var, width=8).pack(side='left')
        tk.Label(qrow, text='n2:', bg=BG).pack(side='left', padx=(10, 2))
        tk.Entry(qrow, textvariable=n2_var, width=5).pack(side='left')

        full_circle_var = tk.BooleanVar(master=win, value=False)

        def on_full_circle():
            if full_circle_var.get():
                q0_var.set(0.0)
                q1_var.set(round(2.0 * math.pi, 6))
        full_circle_chk = tk.Checkbutton(domain_box, text='Full circle (q: 0 to 2*pi)',
                                         variable=full_circle_var, bg=BG,
                                         command=on_full_circle)

        # ── where the pole sits ─────────────────────────────────────────────
        # A polar grid's rings follow the surface's contours and its ribs run
        # straight down the fall -- both true only ABOUT THE SUMMIT. The pole
        # used to be stuck at the parameter origin, so a surface whose summit
        # is anywhere else got rings cutting across its contours at an angle
        # that changed as they went round.
        pole_frame = tk.Frame(domain_box, bg=BG)
        pole_x_var = tk.DoubleVar(master=win, value=0.0)
        pole_y_var = tk.DoubleVar(master=win, value=0.0)
        polerow = tk.Frame(pole_frame, bg=BG)
        polerow.pack(fill='x', padx=6, pady=2)
        tk.Label(polerow, text='pole at:', bg=BG, width=10, anchor='w',
                font=('Helvetica', 9)).pack(side='left')
        tk.Entry(polerow, textvariable=pole_x_var, width=8).pack(side='left')
        tk.Label(polerow, text=',', bg=BG).pack(side='left', padx=2)
        tk.Entry(polerow, textvariable=pole_y_var, width=8).pack(side='left')
        summit_label = tk.Label(pole_frame, text='', bg=BG, fg='#666',
                                font=('Helvetica', 8), justify='left',
                                wraplength=420)
        summit_label.pack(anchor='w', padx=6)

        def find_summits():
            """Count the surface's summits and offer to sit the pole on the
            highest. The COUNT is the real answer: one summit and a polar
            grid is the right chart; several and no single pole can serve
            them all, which is the moment to reach for a Cartesian or
            isometric lattice (no pole at all) or one polar patch per
            summit."""
            try:
                # whichever surface the wizard is currently defining -- in
                # two-surface mode the TOP one is the shape whose summit a
                # polar grid is laid out about
                surface = (single_build() if mode_var.get() == 'single'
                           else top_build())
            except Exception as exc:          # a half-typed expression
                summit_label.config(text=f'Cannot read the surface yet: {exc}')
                return
            try:
                span = (float(p1_var.get()) - float(p0_var.get())) or 1.0
                cx, cy = float(pole_x_var.get()), float(pole_y_var.get())
            except (tk.TclError, ValueError):
                summit_label.config(text='Enter a numeric range and pole first.')
                return
            window = (cx - abs(span), cx + abs(span)), (cy - abs(span), cy + abs(span))
            try:
                tops = sg.surface_summits(surface, window[0], window[1], samples=61)
            except Exception as exc:
                summit_label.config(text=f'Cannot sample the surface: {exc}')
                return
            if not tops:
                summit_label.config(
                    text='No summit inside this window -- the surface only rises '
                         'towards its edge here, so there is nothing for a pole to '
                         'sit on. A Cartesian domain suits this shape better.')
                return
            best = tops[0]
            pole_x_var.set(round(best['x'], 4))
            pole_y_var.set(round(best['y'], 4))
            if len(tops) == 1:
                summit_label.config(
                    text=f"One summit, at ({best['x']:.3f}, {best['y']:.3f}), "
                         f"z = {best['z']:.3f}. The pole is on it: rings now follow "
                         f"the contours and ribs run down the fall.")
            else:
                summit_label.config(
                    text=f"{len(tops)} summits in this window. The pole is on the "
                         f"highest, ({best['x']:.3f}, {best['y']:.3f}), but ONE polar "
                         f"grid cannot be centred on {len(tops)} -- the others get "
                         f"rings cutting across their own contours. Either use a "
                         f"Cartesian or isometric domain (no pole, so it does not "
                         f"care where the summits are), or build one polar patch per "
                         f"summit and join them along the valleys.")

        tk.Button(pole_frame, text='Find the summit(s)', command=find_summits
                 ).pack(anchor='w', padx=6, pady=(2, 4))

        def on_coord_change():
            if coord_var.get() == 'polar':
                p_label_var.set('r range:')
                q_label_var.set('theta range:')
                coord_hint.config(text='Polar: p is read as radius, q as angle '
                                       '(radians), about the pole below.')
                full_circle_chk.pack(anchor='w', padx=6, pady=(0, 4))
                pole_frame.pack(fill='x')
            else:
                p_label_var.set('p range:')
                q_label_var.set('q range:')
                coord_hint.config(text='Cartesian: p, q ARE the surface\'s own x, y (or u, v).')
                full_circle_chk.pack_forget()
                pole_frame.pack_forget()
        on_coord_change()

        # ── pattern ─────────────────────────────────────────────────────────
        pattern_box = tk.LabelFrame(body, text='Module pattern', bg=BG,
                                    font=('Helvetica', 9, 'bold'))
        pattern_box.pack(fill='x', padx=6, pady=4)
        pattern_var = tk.StringVar(master=win, value='square')
        for val, label in (('square', 'Square'), ('diagonal', 'Diagonal'),
                          ('isometric', 'Isometric (60°/equilateral)')):
            tk.Radiobutton(pattern_box, text=label, value=val, variable=pattern_var,
                          bg=BG, font=('Helvetica', 9)).pack(side='left', padx=6)

        # ── module (single-surface mode only) ──────────────────────────────
        module_box = tk.LabelFrame(body, text='Module', bg=BG, font=('Helvetica', 9, 'bold'))
        module_var = tk.StringVar(master=win, value='2d')
        mrow = tk.Frame(module_box, bg=BG)
        mrow.pack(fill='x', padx=6, pady=2)
        tk.Radiobutton(mrow, text='2D (single layer)', value='2d', variable=module_var,
                      bg=BG, command=lambda: on_module_change()).pack(side='left', padx=(0, 12))
        tk.Radiobutton(mrow, text='3D (double layer)', value='3d', variable=module_var,
                      bg=BG, command=lambda: on_module_change()).pack(side='left')

        depth_var = tk.DoubleVar(master=win, value=0.5)
        depth_row = tk.Frame(module_box, bg=BG)
        tk.Label(depth_row, text='Offset depth (m):', bg=BG, width=18, anchor='w',
                font=('Helvetica', 9)).pack(side='left')
        tk.Entry(depth_row, textvariable=depth_var, width=8).pack(side='left')

        side_var = tk.StringVar(master=win, value='top')
        side_row = tk.Frame(module_box, bg=BG)
        tk.Label(side_row, text='This surface is the:', bg=BG, width=18, anchor='w',
                font=('Helvetica', 9)).pack(side='left')
        tk.Radiobutton(side_row, text='Top', value='top', variable=side_var,
                      bg=BG, font=('Helvetica', 9)).pack(side='left')
        tk.Radiobutton(side_row, text='Bottom', value='bottom', variable=side_var,
                      bg=BG, font=('Helvetica', 9)).pack(side='left')

        def on_module_change():
            if module_var.get() == '3d':
                depth_row.pack(fill='x', padx=6, pady=2)
                side_row.pack(fill='x', padx=6, pady=2)
            else:
                depth_row.pack_forget()
                side_row.pack_forget()
        module_box.pack(fill='x', padx=6, pady=4)
        on_module_change()

        def on_mode_change():
            # Switching modes hides the panel the keypad was aimed at, so
            # re-aim it at the first field of the one now showing rather
            # than leaving it pointed into a frame nobody can see.
            if mode_var.get() == 'single':
                between_frame.pack_forget()
                single_frame.pack(fill='x')
                module_box.pack(fill='x', padx=6, pady=4)
                active_entry['widget'] = single_first
            else:
                single_frame.pack_forget()
                between_frame.pack(fill='x')
                module_box.pack_forget()
                active_entry['widget'] = top_first

        note_var = tk.StringVar(master=win, value='')
        tk.Label(body, textvariable=note_var, bg=BG, fg='#2f6f4f', wraplength=620,
                justify='left', font=('Helvetica', 8, 'italic')
                ).pack(fill='x', padx=6, pady=(4, 0))

        status_var = tk.StringVar(master=win, value='')
        status_label = tk.Label(body, textvariable=status_var, bg=BG, fg='#a3241a',
                                wraplength=620, justify='left', font=('Helvetica', 9))
        status_label.pack(fill='x', padx=6, pady=(2, 4))

        def on_generate():
            status_var.set('')
            try:
                p_range = (float(p0_var.get()), float(p1_var.get()))
                q_range = (float(q0_var.get()), float(q1_var.get()))
                n1, n2 = int(n1_var.get()), int(n2_var.get())
                coord, pattern = coord_var.get(), pattern_var.get()
                pole = (float(pole_x_var.get()), float(pole_y_var.get()))
                if mode_var.get() == 'single':
                    surface = single_build()
                    mesh = sg.custom_surface_grid(
                        surface, coord=coord, pattern=pattern, p_range=p_range,
                        q_range=q_range, n1=n1, n2=n2, module=module_var.get(),
                        depth=float(depth_var.get()), offset_side=side_var.get(),
                        pole=pole)
                else:
                    mesh = sg.custom_surface_between(
                        top_build(), bottom_build(), coord=coord, pattern=pattern,
                        p_range=p_range, q_range=q_range, n1=n1, n2=n2, pole=pole)
            except (em.ExpressionError, ValueError, tk.TclError) as exc:
                status_var.set(str(exc))
                return
            self._load_mesh(mesh, push_undo=True, undo_label='custom surface wizard')
            win.destroy()

        def load_recipe(recipe):
            """Show the settings that produced the model currently loaded.

            Loading an example is the quickest way to see what this tab can
            build, and the next question is always "how would I make one like
            it?" -- so the wizard opens already filled in with the example's
            own surfaces and node configuration.

            Several examples are NOT wizard surfaces: they come straight from
            a stereo_geometry generator, and no expression in these fields
            would reproduce them. Those carry only a note naming the generator
            and its arguments, and the fields are left at their defaults
            rather than filled with something that would quietly generate a
            different structure.
            """
            if not recipe:
                return
            note_var.set(recipe.get('note', ''))
            if not recipe.get('mode'):
                return
            mode_var.set(recipe['mode'])
            on_mode_change()
            exprs = {k: recipe[k] for k in ('x', 'y', 'z') if k in recipe}
            kind = recipe.get('kind', 'height')
            if recipe['mode'] == 'single':
                single_fill(kind, exprs)
            else:
                top_fill(kind, exprs)
                bottom_fill(recipe.get('bottom_kind', 'height'),
                            {'z': recipe.get('bottom_z', '0')})
            coord_var.set(recipe.get('coord', 'cartesian'))
            on_coord_change()
            pattern_var.set(recipe.get('pattern', 'square'))
            p_range = recipe.get('p_range', (-5.0, 5.0))
            q_range = recipe.get('q_range', (-5.0, 5.0))
            p0_var.set(p_range[0]); p1_var.set(p_range[1])
            q0_var.set(q_range[0]); q1_var.set(q_range[1])
            n1_var.set(int(recipe.get('n1', 8)))
            n2_var.set(int(recipe.get('n2', 8)))
            module_var.set(recipe.get('module', '2d'))
            depth_var.set(float(recipe.get('depth', 0.5)))
            side_var.set(recipe.get('side', 'top'))
            pole = recipe.get('pole', (0.0, 0.0))
            pole_x_var.set(pole[0]); pole_y_var.set(pole[1])
            on_module_change()

        load_recipe(getattr(self, '_wizard_recipe', None))

        tk.Button(body, text='Generate', font=('Helvetica', 9, 'bold'), bg='#dff0d8',
                 command=on_generate).pack(pady=8)

        # Grow to fit rather than clipping: two surfaces with a keypad each
        # need more height than one, and the mode is switchable at any time.
        def _size_to_content(_event=None):
            win.update_idletasks()
            need = body.winfo_reqheight() + 16
            room = int(win.winfo_screenheight() * 0.92)
            win.geometry(f'{max(680, body.winfo_reqwidth() + 24)}x{min(need, room)}')

        _size_to_content()
        mode_var.trace_add('write', lambda *_a: _size_to_content())
