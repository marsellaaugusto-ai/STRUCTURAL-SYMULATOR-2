"""3D direct-stiffness solver for the Stereo (space-structure) tab.

Storage units, kept consistent with the rest of the app (see units.py /
common.UnitsMixin): node coordinates in metres, member area in cm², E and G
in GPa, Fy/Fu in MPa, nodal loads in kN, self-weight density in kN/m³.
Internally everything is converted to SI (m, N, Pa) for the assembly, the
same boundary as truss_math.py crosses with its own *1e9/*1e-4/*1e3 factors.

MODEL
-----
nodes   : list of (x, y, z) tuples, metres. Node identity is list index.
members : list of dicts, each an axial bar ('pin', the default -- a
          ball-jointed space-truss member carrying only axial force, which
          is what MERO/Nodus/Triodetic-type real space structures actually
          build) or a full 3D beam-column ('rigid' -- a moment-transferring
          connection, for a Vierendeel-type space frame), with:
              a, b        : node indices
              conn        : 'pin' (default) | 'rigid'
              E           : GPa
              A           : cm²
              Fy, Fu      : MPa      (for the CIRSOC checks)
              K           : effective-length factor (default 1.0)
              r_gyr       : cm, weak-axis radius of gyration (pin members;
                            used for the compression buckling check)
              I           : cm⁴, weak-axis second moment (rigid members
                            only -- both bending planes are given this one
                            value, i.e. a doubly-symmetric section is
                            assumed; documented simplification)
              J           : cm⁴, torsion constant (rigid members only;
                            defaults to I if omitted -- another named
                            simplification, exact for a circular/round
                            tube and conservative-ish otherwise)
loads   : list of {'node': i, 'fx': kN, 'fy': kN, 'fz': kN,
                    'mx': kN·m, 'my': kN·m, 'mz': kN·m}, global axes.
          The moment components are optional (default 0) and only make
          physical sense at a node that can actually resist a moment; a
          node loaded with a nonzero mx/my/mz is granted rotational DOFs
          for exactly that reason, on top of the 'rigid member' and
          'restrained rotation' triggers below.
supports: list of {'node': i, 'type': preset_name_or_None,
                    'dofs': {dof_name: bool, ...}}
          -- see `support_restraints` below. This is deliberately NOT a
          fixed enum of support "types": `type` supplies a starting preset
          (or none at all) and `dofs` may restrain or free ANY of the six
          DOF names on top of it, so a user is never limited to a menu of
          canned support conditions.

BOUNDARY CONDITIONS -- "any combination the user pleases"
----------------------------------------------------------
Every one of the six DOFs at every node (ux, uy, uz, rx, ry, rz) is an
independent boolean: restrained or free. A preset ('pin', 'fixed',
'rollerX', ...) is only a convenience that fills in a starting `dofs` dict;
`support_restraints` always applies the user's explicit per-DOF overrides
on top of it, and a support with no preset at all (`type=None`) is
perfectly valid -- pick exactly the DOFs you want restrained. This is what
lets a genuinely unusual condition (e.g. a node free to translate but
restrained against rotation about one axis only, or a diagonal roller) be
built without inventing a new preset name for it. `check_boundary_setup`
below validates the result (rigid-body mechanism / over-restraint) so a
mistake shows up as a clear message instead of a silently wrong or
singular solve.

DOF ALLOCATION
--------------
Exactly the same lazy trick as truss_math.py's `needs_theta`, generalized
from one rotational DOF to three: a node gets rotational DOFs (rx,ry,rz)
only if a 'rigid' member touches it, or a support at that node restrains
at least one rotational DOF. A model built entirely from 'pin' members and
translation-only supports reduces exactly to a classic 3-DOF/node space
truss.
"""
import math
import warnings
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

from common import _beam_gauss_solve

gauss_solve = _beam_gauss_solve

DOF_NAMES = ('ux', 'uy', 'uz', 'rx', 'ry', 'rz')
ROT_DOFS = ('rx', 'ry', 'rz')

DEFAULT_STEEL_UNIT_WEIGHT = 78.5   # kN/m^3
DEFAULT_NU = 0.3                   # Poisson's ratio, for G = E / (2(1+nu))

PRESET_SUPPORTS = {
    'free':    {},
    'pin':     {'ux': True, 'uy': True, 'uz': True},
    'fixed':   {'ux': True, 'uy': True, 'uz': True, 'rx': True, 'ry': True, 'rz': True},
    'rollerX': {'uy': True, 'uz': True},    # free to slide along global X only
    'rollerY': {'ux': True, 'uz': True},    # free to slide along global Y only
    'rollerZ': {'ux': True, 'uy': True},    # free to slide along global Z only
    'cable':   {'uz': True},                # vertical cable: restrains only uz (crane hoist)
}


def support_restraints(support):
    """The full 6-bool restraint dict for one support entry: a named preset
    (if any) merged with any explicit per-DOF override. This is the one
    place "any boundary condition the user pleases" is realised -- nothing
    downstream ever looks at `type` again, only at this resolved dict."""
    base = dict.fromkeys(DOF_NAMES, False)
    preset = support.get('type')
    if preset:
        if preset not in PRESET_SUPPORTS:
            raise ValueError(f'unknown support preset {preset!r}; expected one of '
                              f'{tuple(PRESET_SUPPORTS)} or None')
        base.update(PRESET_SUPPORTS[preset])
    base.update(support.get('dofs') or {})
    return base


def member_vector(nodes, member):
    na, nb = nodes[member['a']], nodes[member['b']]
    dx, dy, dz = nb[0] - na[0], nb[1] - na[1], nb[2] - na[2]
    L = math.sqrt(dx * dx + dy * dy + dz * dz)
    return dx, dy, dz, L


def _local_axes(dx, dy, dz, L):
    """A right-handed local (x,y,z) basis for a 3D frame element: local x
    along the member; local y and z from a fixed global reference vector,
    exactly like every standard 3D frame-element formulation (McGuire,
    Gallagher & Ziemian; Przemieniecki). Global Z is the reference vector
    unless the member itself is (near-)vertical, in which case global Y is
    used instead -- otherwise the cross product used to build local y would
    be with a parallel vector and degenerate to zero."""
    lx, ly, lz = dx / L, dy / L, dz / L
    if abs(lx) < 1e-9 and abs(ly) < 1e-9:
        ref = (0.0, 1.0, 0.0)
    else:
        ref = (0.0, 0.0, 1.0)
    # local y = ref x local_x, normalized
    yx = ref[1] * lz - ref[2] * ly
    yy = ref[2] * lx - ref[0] * lz
    yz = ref[0] * ly - ref[1] * lx
    nrm = math.sqrt(yx * yx + yy * yy + yz * yz)
    yx, yy, yz = yx / nrm, yy / nrm, yz / nrm
    # local z = local_x x local_y
    zx = ly * yz - lz * yy
    zy = lz * yx - lx * yz
    zz = lx * yy - ly * yx
    return (lx, ly, lz), (yx, yy, yz), (zx, zy, zz)


def _pin_stiffness(E_GPa, A_cm2, L):
    k = (E_GPa * 1e9) * (A_cm2 * 1e-4) / L
    return k


def _rigid_local_stiffness(E_GPa, A_cm2, I_cm4, J_cm4, L, nu=DEFAULT_NU):
    """The standard 12x12 local stiffness matrix for a 3D Euler-Bernoulli
    beam-column, DOF order (ux,uy,uz,rx,ry,rz) at node a then node b.
    Bending about local z (in-plane uy/rz) uses Iz; bending about local y
    (in-plane uz/ry) uses Iy. A doubly-symmetric section is assumed
    (Iy = Iz = I, the member's one given `I`), which is exact for a round
    or square hollow section -- the common choice for space-structure
    members -- and a documented simplification otherwise."""
    E = E_GPa * 1e9
    G = E / (2.0 * (1.0 + nu))
    A = A_cm2 * 1e-4
    Iy = Iz = I_cm4 * 1e-8
    J = J_cm4 * 1e-8

    EA_L = E * A / L
    GJ_L = G * J / L
    k = np.zeros((12, 12))

    k[0, 0] = k[6, 6] = EA_L
    k[0, 6] = k[6, 0] = -EA_L

    # bending in the local x-y plane (uy, rz), stiffness from Iz
    k[1, 1] = k[7, 7] = 12 * E * Iz / L ** 3
    k[1, 7] = k[7, 1] = -12 * E * Iz / L ** 3
    k[1, 5] = k[5, 1] = 6 * E * Iz / L ** 2
    k[1, 11] = k[11, 1] = 6 * E * Iz / L ** 2
    k[5, 7] = k[7, 5] = -6 * E * Iz / L ** 2
    k[7, 11] = k[11, 7] = -6 * E * Iz / L ** 2
    k[5, 5] = k[11, 11] = 4 * E * Iz / L
    k[5, 11] = k[11, 5] = 2 * E * Iz / L

    # bending in the local x-z plane (uz, ry), stiffness from Iy
    k[2, 2] = k[8, 8] = 12 * E * Iy / L ** 3
    k[2, 8] = k[8, 2] = -12 * E * Iy / L ** 3
    k[2, 4] = k[4, 2] = -6 * E * Iy / L ** 2
    k[2, 10] = k[10, 2] = -6 * E * Iy / L ** 2
    k[4, 8] = k[8, 4] = 6 * E * Iy / L ** 2
    k[8, 10] = k[10, 8] = 6 * E * Iy / L ** 2
    k[4, 4] = k[10, 10] = 4 * E * Iy / L
    k[4, 10] = k[10, 4] = 2 * E * Iy / L

    # torsion (rx)
    k[3, 3] = k[9, 9] = GJ_L
    k[3, 9] = k[9, 3] = -GJ_L

    return k


def _fixed_end_forces_local(wx, wy, wz, L):
    """The 12-vector of local end forces that hold a prismatic member's two
    ends FIXED under a uniform span load (wx, wy, wz) in LOCAL N/m.

    This is what makes a span load different from splitting it in half and
    hanging it on the two joints. Lumping gets the end SHEARS right --
    wL/2 each, which is why the two agree on a pin-jointed truss -- but it
    silently throws away the end MOMENTS, wL^2/12, and with them the whole
    reason a rigid joint behaves differently from a hinge. Every moment
    this app reports for a rigid member used to be missing that term.

    Sign convention follows _rigid_local_stiffness's own: the local x-y
    plane pairs uy with rz, and the local x-z plane pairs uz with ry with
    the sign reversed, so the two planes' fixed-end moments carry opposite
    signs here for the same reason their stiffness terms do.

    Used as `f_local = k_local @ d_local + f_fixed`, with `-f_fixed`
    released onto the joints as the equivalent nodal load -- the standard
    direct-stiffness treatment of an element load.
    """
    f = np.zeros(12)
    half_x, half_y, half_z = wx * L / 2.0, wy * L / 2.0, wz * L / 2.0
    m_y = wy * L * L / 12.0
    m_z = wz * L * L / 12.0

    f[0] = -half_x
    f[6] = -half_x

    f[1] = -half_y
    f[7] = -half_y
    f[5] = -m_y
    f[11] = +m_y

    f[2] = -half_z
    f[8] = -half_z
    f[4] = +m_z
    f[10] = -m_z
    return f


def _rotation_12(local_x, local_y, local_z):
    """Block-diagonal 12x12 transformation (global -> local) from the 3x3
    direction-cosine matrix, repeated once per translational/rotational
    triplet at each of the two nodes."""
    r3 = np.array([local_x, local_y, local_z])
    T = np.zeros((12, 12))
    for blk in range(4):
        T[blk * 3:blk * 3 + 3, blk * 3:blk * 3 + 3] = r3
    return T


def analyze(nodes, members, loads, supports, member_loads=None):
    """Solve the space structure. Returns (result, error). On failure,
    result is None and error is a human-readable string (mirroring every
    other solver in this app, e.g. truss_math.analyze).

    result = {
        'node_res': [{'ux','uy','uz' (mm), 'rx','ry','rz' (rad)}, ...],
        'member_res': [{'N' (kN, +tension), and for rigid members also
                         'Vy_a','Vz_a','Vy_b','Vz_b' (kN), 'T',
                         'My_a','My_b','Mz_a','Mz_b' (kN·m), and
                         'w_local' (wx,wy,wz in kN/m) when the member
                         carries a span load}, ...],
        'reactions': {node_idx: {'Fx','Fy','Fz' (kN), 'Mx','My','Mz' (kN·m)}},
    }

    `member_loads` is an optional {member_index: (wx, wy, wz)} of uniform
    span loads in GLOBAL kN/m. A rigid member gets the proper
    direct-stiffness treatment -- consistent fixed-end forces onto the
    joints, and the span term carried back into its own end actions. A pin
    member cannot carry transverse load in the truss idealisation at all,
    so its span load is lumped half-and-half onto its ends exactly as
    before.
    """
    err = check_boundary_setup(nodes, members, supports)
    if err:
        return None, err

    N = len(nodes)
    restraints = [dict.fromkeys(DOF_NAMES, False) for _ in range(N)]
    for sp in supports:
        r = support_restraints(sp)
        node_r = restraints[sp['node']]
        for d in DOF_NAMES:
            node_r[d] = node_r[d] or r[d]

    needs_rot = [False] * N
    for m in members:
        if m.get('conn', 'pin') == 'rigid':
            needs_rot[m['a']] = True
            needs_rot[m['b']] = True
    for i in range(N):
        if any(restraints[i][d] for d in ROT_DOFS):
            needs_rot[i] = True
    for ld in loads:
        if any(ld.get(k, 0.0) for k in ('mx', 'my', 'mz')):
            needs_rot[ld['node']] = True

    dof_of = [None] * N   # (ux,uy,uz, rx_or_None, ry_or_None, rz_or_None)
    ndof = 0
    for i in range(N):
        idx = [ndof, ndof + 1, ndof + 2]
        ndof += 3
        if needs_rot[i]:
            idx += [ndof, ndof + 1, ndof + 2]
            ndof += 3
        else:
            idx += [None, None, None]
        dof_of[i] = tuple(idx)

    coo_rows = []
    coo_cols = []
    coo_vals = []

    pin_members = []
    rigid_members = []
    member_geom = [None] * len(members)
    for mi, m in enumerate(members):
        dx, dy, dz, L = member_vector(nodes, m)
        member_geom[mi] = (dx, dy, dz, L)
        if L < 1e-9:
            continue
        if m.get('conn', 'pin') != 'rigid':
            pin_members.append(mi)
        else:
            rigid_members.append(mi)

    if pin_members:
        n_pin = len(pin_members)
        EA_over_L = np.empty(n_pin)
        dirs = np.empty((n_pin, 3))
        pin_idx = np.empty((n_pin, 6), dtype=np.intp)
        for pi, mi in enumerate(pin_members):
            m = members[mi]
            dx, dy, dz, L = member_geom[mi]
            EA_over_L[pi] = (m['E'] * 1e9) * (m['A'] * 1e-4) / L
            dirs[pi] = (dx / L, dy / L, dz / L)
            a_dof, b_dof = dof_of[m['a']], dof_of[m['b']]
            pin_idx[pi] = (a_dof[0], a_dof[1], a_dof[2],
                           b_dof[0], b_dof[1], b_dof[2])
        ke33_batch = EA_over_L[:, None, None] * (dirs[:, :, None] * dirs[:, None, :])
        ke_batch = np.empty((n_pin, 6, 6))
        ke_batch[:, :3, :3] = ke33_batch
        ke_batch[:, :3, 3:] = -ke33_batch
        ke_batch[:, 3:, :3] = -ke33_batch
        ke_batch[:, 3:, 3:] = ke33_batch
        row_idx = pin_idx[:, :, None].repeat(6, axis=2)
        col_idx = pin_idx[:, None, :].repeat(6, axis=1)
        coo_rows.append(row_idx.ravel())
        coo_cols.append(col_idx.ravel())
        coo_vals.append(ke_batch.ravel())

    for mi in rigid_members:
        m = members[mi]
        dx, dy, dz, L = member_geom[mi]
        local_x, local_y, local_z = _local_axes(dx, dy, dz, L)
        kloc = _rigid_local_stiffness(m['E'], m['A'], m.get('I', 0.0),
                                       m.get('J', m.get('I', 0.0)), L)
        T = _rotation_12(local_x, local_y, local_z)
        kgl = T.T @ kloc @ T
        a_dof, b_dof = dof_of[m['a']], dof_of[m['b']]
        idx = np.array(list(a_dof) + list(b_dof), dtype=np.intp)
        ri = idx[:, None].repeat(12, axis=1)
        ci = idx[None, :].repeat(12, axis=0)
        coo_rows.append(ri.ravel())
        coo_cols.append(ci.ravel())
        coo_vals.append(kgl.ravel())

    if coo_rows:
        all_rows = np.concatenate(coo_rows)
        all_cols = np.concatenate(coo_cols)
        all_vals = np.concatenate(coo_vals)
    else:
        all_rows = np.array([], dtype=np.intp)
        all_cols = np.array([], dtype=np.intp)
        all_vals = np.array([], dtype=float)

    K_sparse = coo_matrix((all_vals, (all_rows, all_cols)),
                           shape=(ndof, ndof)).tocsc()

    # Span loads become consistent fixed-end forces on a rigid member, and
    # the equivalent joint load released onto the structure is their
    # negative. A pin member is a two-force member by definition -- it can
    # carry no transverse load at all -- so its span load is lumped to its
    # ends exactly as before, which is why a pin-jointed model solves to
    # the same numbers with or without this path.
    fef_local = {}
    fef_lumped = []
    for mi, w in (member_loads or {}).items():
        if not (0 <= mi < len(members)):
            continue
        wx_g, wy_g, wz_g = (float(w[0]), float(w[1]), float(w[2]))
        if not (wx_g or wy_g or wz_g):
            continue
        m = members[mi]
        dx, dy, dz, L = member_geom[mi]
        if L < 1e-9:
            continue
        if m.get('conn', 'pin') != 'rigid':
            half = L / 2.0
            for nid in (m['a'], m['b']):
                fef_lumped.append({'node': nid, 'fx': wx_g * half,
                                   'fy': wy_g * half, 'fz': wz_g * half})
            continue
        local_x, local_y, local_z = _local_axes(dx, dy, dz, L)
        w_loc = (wx_g * local_x[0] + wy_g * local_x[1] + wz_g * local_x[2],
                 wx_g * local_y[0] + wy_g * local_y[1] + wz_g * local_y[2],
                 wx_g * local_z[0] + wy_g * local_z[1] + wz_g * local_z[2])
        f_loc = _fixed_end_forces_local(w_loc[0] * 1e3, w_loc[1] * 1e3,
                                        w_loc[2] * 1e3, L)
        fef_local[mi] = (f_loc, w_loc)

    F = np.zeros(ndof)
    for mi, (f_loc, _w_loc) in fef_local.items():
        m = members[mi]
        dx, dy, dz, L = member_geom[mi]
        T = _rotation_12(*_local_axes(dx, dy, dz, L))
        f_gl = T.T @ f_loc
        idx = list(dof_of[m['a']]) + list(dof_of[m['b']])
        for k, dofi in enumerate(idx):
            if dofi is not None:
                F[dofi] -= f_gl[k]

    for ld in list(loads) + fef_lumped:
        idx = dof_of[ld['node']]
        F[idx[0]] += ld.get('fx', 0.0) * 1e3
        F[idx[1]] += ld.get('fy', 0.0) * 1e3
        F[idx[2]] += ld.get('fz', 0.0) * 1e3
        for k, key in ((3, 'mx'), (4, 'my'), (5, 'mz')):
            v = ld.get(key, 0.0)
            if v:
                F[idx[k]] += v * 1e3

    constrained = set()
    for sp in supports:
        r = support_restraints(sp)
        idx = dof_of[sp['node']]
        for k, d in enumerate(DOF_NAMES):
            if r[d]:
                if idx[k] is None:
                    raise AssertionError('internal: rotational DOF missing '
                                          'for a restrained rotation')
                constrained.add(idx[k])

    free = sorted(i for i in range(ndof) if i not in constrained)
    if not free:
        return None, 'All degrees of freedom are constrained -- nothing can move.'

    free_arr = np.array(free, dtype=np.intp)
    Kf = K_sparse[np.ix_(free_arr, free_arr)]
    Ff = F[free_arr]
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', category=Warning)
            U_free = spsolve(Kf.tocsc(), Ff)
    except Exception:
        return None, ('Singular stiffness matrix -- the structure (or some part '
                       'of it) is a mechanism, or a node is floating with no '
                       'load path to a support. Check for missing members or '
                       'missing boundary conditions.')
    if not np.all(np.isfinite(U_free)):
        return None, ('Singular stiffness matrix -- the structure (or some part '
                       'of it) is a mechanism, or a node is floating with no '
                       'load path to a support. Check for missing members or '
                       'missing boundary conditions.')
    coords = np.array(nodes, dtype=float)
    span = max((coords.max(axis=0) - coords.min(axis=0)).max(), 1.0)
    if np.max(np.abs(U_free)) > span * 1e4:
        return None, ('Singular stiffness matrix -- the structure (or some part '
                       'of it) is a mechanism, or a node is floating with no '
                       'load path to a support. Check for missing members or '
                       'missing boundary conditions.')

    U = np.zeros(ndof)
    U[free_arr] = U_free

    node_res = []
    for i in range(N):
        idx = dof_of[i]
        node_res.append({
            'ux': U[idx[0]] * 1000.0, 'uy': U[idx[1]] * 1000.0, 'uz': U[idx[2]] * 1000.0,
            'rx': U[idx[3]] if idx[3] is not None else 0.0,
            'ry': U[idx[4]] if idx[4] is not None else 0.0,
            'rz': U[idx[5]] if idx[5] is not None else 0.0,
        })

    member_res = []
    if pin_members:
        U_pin_a = U[pin_idx[:, :3]]
        U_pin_b = U[pin_idx[:, 3:]]
        elong = np.sum((U_pin_b - U_pin_a) * dirs, axis=1)
        N_forces = EA_over_L * elong / 1e3
    pin_result_idx = 0
    for mi, m in enumerate(members):
        dx, dy, dz, L = member_geom[mi]
        if L < 1e-9:
            member_res.append({'N': 0.0, 'conn': m.get('conn', 'pin'), 'length_m': 0.0})
            continue

        if m.get('conn', 'pin') != 'rigid':
            member_res.append({'N': float(N_forces[pin_result_idx]),
                               'conn': 'pin', 'length_m': L})
            pin_result_idx += 1
        else:
            local_x, local_y, local_z = _local_axes(dx, dy, dz, L)
            kloc = _rigid_local_stiffness(m['E'], m['A'], m.get('I', 0.0),
                                           m.get('J', m.get('I', 0.0)), L)
            T = _rotation_12(local_x, local_y, local_z)
            a_dof, b_dof = dof_of[m['a']], dof_of[m['b']]
            idx = list(a_dof) + list(b_dof)
            dgl = np.array([U[i] for i in idx])
            dloc = T @ dgl
            f_fixed, w_loc = fef_local.get(mi, (None, None))
            floc = kloc @ dloc
            if f_fixed is not None:
                floc = floc + f_fixed
            entry = {
                'N': floc[6] / 1e3, 'conn': 'rigid', 'length_m': L,
                'Vy_a': floc[1] / 1e3, 'Vz_a': floc[2] / 1e3, 'T': floc[3] / 1e3,
                'Vy_b': floc[7] / 1e3, 'Vz_b': floc[8] / 1e3,
                'My_a': floc[4] / 1e3, 'Mz_a': floc[5] / 1e3,
                'My_b': floc[10] / 1e3, 'Mz_b': floc[11] / 1e3,
            }
            if w_loc is not None:
                entry['w_local'] = w_loc
            member_res.append(entry)

    reactions = {}
    Ku = K_sparse @ U
    for sp in supports:
        r = support_restraints(sp)
        if not any(r.values()):
            continue
        idx = dof_of[sp['node']]
        rxn = reactions.setdefault(sp['node'], {'Fx': 0.0, 'Fy': 0.0, 'Fz': 0.0,
                                                 'Mx': 0.0, 'My': 0.0, 'Mz': 0.0})
        labels = ('Fx', 'Fy', 'Fz', 'Mx', 'My', 'Mz')
        for k, d in enumerate(DOF_NAMES):
            if r[d] and idx[k] is not None:
                resid = Ku[idx[k]] - F[idx[k]]
                rxn[labels[k]] += resid / 1e3

    return {'node_res': node_res, 'member_res': member_res, 'reactions': reactions}, None


def self_weight_split(nodes, members, unit_weight_kN_m3=DEFAULT_STEEL_UNIT_WEIGHT):
    """Self weight as (nodal_loads, member_loads).

    A pin member is a two-force member -- it carries no transverse load by
    definition -- so its weight is lumped half-and-half onto its ends,
    exactly what `self_weight_loads` has always done and exact within the
    truss idealisation. A RIGID member is a beam: its weight is a span
    load, and handing it to `analyze` as one is what lets the solver put
    the wL^2/12 fixed-end moments where they belong instead of discarding
    them.

    Splitting rather than replacing is deliberate: a fully pin-jointed
    model comes out of this with an empty member_loads dict and therefore
    solves to numbers identical to the ones it produced before span loads
    existed at all.
    """
    nodal = {}
    span = {}
    for mi, m in enumerate(members):
        _, _, _, L = member_vector(nodes, m)
        if L < 1e-12:
            continue
        W = m['A'] * 1e-4 * L * unit_weight_kN_m3        # kN over the member
        if m.get('conn', 'pin') == 'rigid':
            span[mi] = (0.0, 0.0, -W / L)                # kN/m, downward
        else:
            half = W / 2.0
            nodal[m['a']] = nodal.get(m['a'], 0.0) + half
            nodal[m['b']] = nodal.get(m['b'], 0.0) + half
    loads = [{'node': n, 'fx': 0.0, 'fy': 0.0, 'fz': -w}
             for n, w in nodal.items()]
    return loads, span


def member_diagram(mr, n_samples=21):
    """Shear and bending along ONE member, sampled from end a to end b.

    Returns {'x': [...], 'Vy','Vz','My','Mz': [...], 'V','M': [...]} where
    V and M are the resultant magnitudes. Units kN and kN*m, x in metres.

    The end actions alone give a straight moment line, which is the whole
    truth only when nothing is applied between the ends. With a span load
    the line becomes a parabola, and the sag it adds is exactly the part a
    report that drew only the two end values used to be missing. A pin
    member carries no shear or moment at all, so it samples as zeros.
    """
    L = float(mr.get('length_m', 0.0) or 0.0)
    n = max(2, int(n_samples))
    xs = [L * i / (n - 1) for i in range(n)] if L > 0 else [0.0] * n
    if mr.get('conn') != 'rigid':
        zeros = [0.0] * n
        return {'x': xs, 'Vy': list(zeros), 'Vz': list(zeros),
                'My': list(zeros), 'Mz': list(zeros),
                'V': list(zeros), 'M': list(zeros)}

    wy = wz = 0.0
    w_loc = mr.get('w_local')
    if w_loc:
        wy, wz = float(w_loc[1]), float(w_loc[2])
    Vy_a, Vz_a = mr.get('Vy_a', 0.0), mr.get('Vz_a', 0.0)
    My_a, Mz_a = mr.get('My_a', 0.0), mr.get('Mz_a', 0.0)

    out = {'x': xs, 'Vy': [], 'Vz': [], 'My': [], 'Mz': [], 'V': [], 'M': []}
    for x in xs:
        vy = -(Vy_a + wy * x)
        vz = -(Vz_a + wz * x)
        mz = -(Mz_a + Vy_a * x + wy * x * x / 2.0)
        my = -(My_a + Vz_a * x + wz * x * x / 2.0)
        out['Vy'].append(vy)
        out['Vz'].append(vz)
        out['My'].append(my)
        out['Mz'].append(mz)
        out['V'].append(math.hypot(vy, vz))
        out['M'].append(math.hypot(my, mz))
    return out


def member_peak_actions(mr, n_samples=21):
    """The governing |V| and |M| anywhere along a member, and where.

    What "maximum solicitation" means for a rod: not the larger of its two
    end values, which is all the end actions show, but the peak over the
    whole span -- which under a span load sits between the ends.
    """
    d = member_diagram(mr, n_samples)
    if not d['M']:
        return {'V_max': 0.0, 'M_max': 0.0, 'x_V': 0.0, 'x_M': 0.0}
    iv = max(range(len(d['V'])), key=lambda i: d['V'][i])
    im = max(range(len(d['M'])), key=lambda i: d['M'][i])
    return {'V_max': d['V'][iv], 'M_max': d['M'][im],
            'x_V': d['x'][iv], 'x_M': d['x'][im]}


def node_moment_vectors(nodes, members, member_res):
    """The internal moment (Mx, My, Mz, kN*m, in GLOBAL axes) each RIGID
    member end imposes on the joint it frames into, picking -- per node --
    the single connected member end with the LARGEST resultant magnitude
    as that joint's representative value. Returned as {node_idx: {'Mx',
    'My', 'Mz'}}, one entry per node touched by at least one rigid member
    (a purely pin-jointed joint carries no moment by definition and is
    omitted, exactly like a pin-jointed truss's support reads ~0 moment).

    Built with the exact same local-axis transform analyze() itself uses
    (_local_axes / _rotation_12) so the result is directly comparable,
    axis-for-axis, to a support's own reaction Mx/My/Mz -- e.g. through
    stereo_app's reaction_moment_signed, which works unchanged on either
    dict since both only need Mx/My/Mz keys.

    A plain SUM across every member framing into a joint was deliberately
    rejected: at an unloaded interior joint, moment CONTINUITY means the
    incoming member-end moments are equal and opposite by joint
    equilibrium, so a naive sum would read ~0 there regardless of how much
    bending the joint is actually carrying -- the opposite of useful for a
    "how much moment is happening here" visualization. Taking the single
    largest-magnitude incident end instead avoids that cancellation and
    reads as "the worst-loaded member framing into this joint", which for
    the common case of two collinear continuous members is the same
    (equal-and-opposite) value either end would give.

    member_res is the 'member_res' list an earlier analyze() call already
    returned -- this function does not re-solve anything, only re-expresses
    already-solved local end-moments in global axes.
    """
    best = {}
    for m, res in zip(members, member_res):
        if m.get('conn', 'pin') != 'rigid' or res.get('length_m', 0.0) < 1e-9:
            continue
        dx, dy, dz, L = member_vector(nodes, m)
        local_x, local_y, local_z = _local_axes(dx, dy, dz, L)
        T = res.get('T', 0.0)
        ends = ((m['a'], T, res.get('My_a', 0.0), res.get('Mz_a', 0.0)),
                (m['b'], -T, res.get('My_b', 0.0), res.get('Mz_b', 0.0)))
        for node, t_end, my, mz in ends:
            gx = local_x[0] * t_end + local_y[0] * my + local_z[0] * mz
            gy = local_x[1] * t_end + local_y[1] * my + local_z[1] * mz
            gz = local_x[2] * t_end + local_y[2] * my + local_z[2] * mz
            mag = math.sqrt(gx * gx + gy * gy + gz * gz)
            cur = best.get(node)
            if cur is None or mag > cur[0]:
                best[node] = (mag, {'Mx': gx, 'My': gy, 'Mz': gz})
    return {node: vec for node, (_mag, vec) in best.items()}


def degree_of_indeterminacy(nodes, members, supports):
    """The structure's degree of STATIC INDETERMINACY: how many more
    independent force/moment unknowns (member internal forces plus
    support reactions) exist than the equilibrium equations available to
    solve for them. 0 = statically determinate (exactly enough load
    paths, textbook "simple" structure); positive = redundant (more load
    paths than the bare minimum -- the classic meaning of "indeterminate"
    in the sense every statics course uses); negative = UNDER-restrained
    -- a genuine mechanism, the same condition `analyze()` would reject
    with a singular stiffness matrix (or `check_boundary_setup` catches
    even earlier). This is a property of the STRUCTURE alone (geometry,
    connectivity, supports) -- deliberately independent of any particular
    load case, the conventional meaning of the term.

    Generalizes the textbook single-typology formulas -- DSI = m + r - 3j
    for a pure pin-jointed truss, DSI = 6m + r - 6j for a pure rigid
    frame (m = members, r = individual restrained DOF components, j =
    joints) -- to any pin/rigid MIX, using the exact same per-node DOF-
    counting rule analyze() itself uses (a node needs 6 DOF, not just 3,
    the moment it touches a RIGID member or has a restrained rotation) so
    a mixed structure is counted consistently with how it is actually
    solved:

        DSI = (member unknowns: 1 per pin member, 6 per rigid member)
            + (total restrained DOF count across every support)
            - (total ACTIVE DOF count across every node)

    Verified against hand-checkable cases in
    tests/test_stereo_math.py::test_degree_of_indeterminacy_* -- a fully
    triangulated 3D tetrahedron (6 pin members, 4 joints) with the
    minimum 6 restraint components needed for 3D stability comes out
    to exactly 0; adding one redundant brace makes it +1; a fixed-fixed
    single rigid member (no intermediate joint) comes out to +6, the
    same result 2D statics gets for a fixed-fixed beam once the extra
    out-of-plane DOF a 3D formulation carries are accounted for.
    """
    N = len(nodes)
    restraints = [dict.fromkeys(DOF_NAMES, False) for _ in range(N)]
    for sp in supports:
        r = support_restraints(sp)
        node_r = restraints[sp['node']]
        for d in DOF_NAMES:
            node_r[d] = node_r[d] or r[d]

    needs_rot = [False] * N
    for m in members:
        if m.get('conn', 'pin') == 'rigid':
            needs_rot[m['a']] = True
            needs_rot[m['b']] = True
    for i in range(N):
        if any(restraints[i][d] for d in ROT_DOFS):
            needs_rot[i] = True

    ndof = sum(6 if needs_rot[i] else 3 for i in range(N))
    restraint_count = sum(1 for i in range(N) for d in DOF_NAMES if restraints[i][d])
    member_unknowns = sum(6 if m.get('conn', 'pin') == 'rigid' else 1 for m in members)
    return member_unknowns + restraint_count - ndof


def total_restrained_dofs(nodes, supports):
    """Total count of individual restrained DOF components (ux/uy/uz/rx/ry/rz)
    across every support, merging duplicate restraints on the same node.

    A 3D rigid body has exactly 6 possible rigid-body motions (3
    translations + 3 rotations). Suppressing all of them requires AT LEAST
    6 restrained DOF components in total, correctly placed -- this is a
    hard lower bound, independent of how many members exist or how they
    are arranged. Below this count the structure is a free-floating
    mechanism no matter how large `degree_of_indeterminacy` computes,
    because that formula only balances unknowns against equations in
    aggregate and cannot by itself see that missing EXTERNAL restraint
    can never be compensated for by internal bracing redundancy. Callers
    should treat `total_restrained_dofs(...) < 6` as an unconditional
    instability warning, checked separately from the DSI sign/value.
    """
    N = len(nodes)
    restraints = [dict.fromkeys(DOF_NAMES, False) for _ in range(N)]
    for sp in supports:
        r = support_restraints(sp)
        node_r = restraints[sp['node']]
        for d in DOF_NAMES:
            node_r[d] = node_r[d] or r[d]
    return sum(1 for i in range(N) for d in DOF_NAMES if restraints[i][d])


def check_boundary_setup(nodes, members, supports):
    """Validate supports BEFORE assembly, so a bad boundary-condition setup
    reads as a clear message instead of a numpy singular-matrix traceback
    or (worse) a silently wrong answer.

    Catches:
      * a support naming a node index out of range;
      * an unknown preset name (surfaced from `support_restraints`);
      * fewer than 3 independent translational restraints anywhere in the
        model, which always leaves at least a rigid-body translation or
        rotation free regardless of how the members are arranged -- the
        classic "floating in space" mistake. This is a coarse necessary
        check, not a full mechanism/stability analysis (a real mechanism
        hiding inside an otherwise adequately-supported model is instead
        caught by the singular-matrix guard in `analyze`).
    """
    N = len(nodes)
    for sp in supports:
        if not (0 <= sp['node'] < N):
            return f"support references node {sp['node']}, but the model has {N} nodes"
        try:
            support_restraints(sp)
        except ValueError as exc:
            return str(exc)

    restrained_axes = set()
    any_restraint = False
    for sp in supports:
        r = support_restraints(sp)
        for d in ('ux', 'uy', 'uz'):
            if r[d]:
                restrained_axes.add(d)
                any_restraint = True
    if not any_restraint:
        return ('No boundary conditions are defined -- the structure is free to '
                'translate and rotate as a rigid body. Restrain at least one node.')
    if len(restrained_axes) < 3:
        missing = sorted({'ux', 'uy', 'uz'} - restrained_axes)
        return ('The supports restrain translation along ' +
                ', '.join(sorted(a[-1] for a in restrained_axes)) +
                f' only; {", ".join(a[-1] for a in missing)} is free everywhere, so '
                'the whole structure can translate as a rigid body in that '
                'direction. Restrain it somewhere.')
    return None


def self_weight_loads(nodes, members, unit_weight_kN_m3=DEFAULT_STEEL_UNIT_WEIGHT):
    """Lump each member's self weight (kN) half-and-half onto its two end
    nodes as a downward (-z) nodal load -- the standard space-truss
    idealisation, exact for a pin member (which can carry no distributed
    load anyway) and the usual practical approximation for a rigid one."""
    totals = {}
    for m in members:
        _, _, _, L = member_vector(nodes, m)
        W = m['A'] * 1e-4 * L * unit_weight_kN_m3   # cm² -> m², times length, times kN/m3
        half = W / 2.0
        totals[m['a']] = totals.get(m['a'], 0.0) + half
        totals[m['b']] = totals.get(m['b'], 0.0) + half
    return [{'node': n, 'fx': 0.0, 'fy': 0.0, 'fz': -w} for n, w in totals.items()]


def area_load_to_nodal_loads(load_nodes, q_kN_m2, direction=(0.0, 0.0, -1.0)):
    """Convert a uniform pressure q (kN/m², e.g. snow/dead roof load) into
    nodal loads, using the exact/converged tributary areas a geometry
    generator returns as its `load_nodes` dict (node_idx -> area_m2; see
    stereo_geometry.py). `direction` is a unit-ish vector (normalized here,
    so the caller need not pre-normalize); the default -z matches
    `self_weight_loads`'s downward convention."""
    dx, dy, dz = direction
    norm = math.sqrt(dx * dx + dy * dy + dz * dz)
    if norm < 1e-12:
        raise ValueError('direction must be a nonzero vector')
    dx, dy, dz = dx / norm, dy / norm, dz / norm
    loads = []
    for node, area in load_nodes.items():
        P = q_kN_m2 * area
        loads.append({'node': node, 'fx': P * dx, 'fy': P * dy, 'fz': P * dz})
    return loads


def varying_area_load_to_nodal_loads(node_coords, load_nodes, q_at,
                                     direction=(0.0, 0.0, -1.0), only=None):
    """A pressure that VARIES over the surface, as nodal loads.

    Same tributary areas as area_load_to_nodal_loads -- the exact ones a
    generator hands back in `load_nodes` -- but the pressure is sampled per
    node instead of being one number for the whole roof. `q_at(x, y, z)`
    returns kN/m2 at that point, which is what lets a drift, a wind
    distribution or any other non-uniform field be applied without inventing
    a load case format: the caller builds the function, this only integrates
    it over the areas.

    `only` restricts the load to a set of node indices -- a snow drift on
    half a roof, a live load over one bay -- and nodes outside it are left
    alone rather than loaded with zero, so combine_loads can still layer
    another field on top of them.

    The direction is a fixed vector, not a per-node surface normal: a
    pressure that always acts along the local normal is a different load
    case (an inflation, a hydrostatic push) and would need the surface's own
    orientation, which a node's tributary area does not carry.
    """
    dx, dy, dz = direction
    norm = math.sqrt(dx * dx + dy * dy + dz * dz)
    if norm < 1e-12:
        raise ValueError('direction must be a nonzero vector')
    dx, dy, dz = dx / norm, dy / norm, dz / norm
    loads = []
    for node, area in load_nodes.items():
        if only is not None and node not in only:
            continue
        if not (0 <= node < len(node_coords)):
            continue
        x, y, z = node_coords[node]
        P = float(q_at(x, y, z)) * area
        if P == 0.0:
            continue
        loads.append({'node': node, 'fx': P * dx, 'fy': P * dy, 'fz': P * dz})
    return loads


def combine_loads(*load_lists):
    """Merge several load lists (e.g. applied loads + self_weight_loads)
    into one, summing contributions that land on the same node instead of
    leaving them as separate entries analyze() would otherwise just add
    anyway -- kept separate only for readability of the combined list."""
    totals = {}
    for loads in load_lists:
        for ld in loads:
            t = totals.setdefault(ld['node'], {'node': ld['node'], 'fx': 0.0, 'fy': 0.0, 'fz': 0.0})
            t['fx'] += ld.get('fx', 0.0)
            t['fy'] += ld.get('fy', 0.0)
            t['fz'] += ld.get('fz', 0.0)
    return list(totals.values())
