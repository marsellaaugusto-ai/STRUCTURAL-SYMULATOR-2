"""Regression guard for DIAGNOSIS_TRUSS_2026-09-05 finding T-1.

What went wrong: the right-hand panel was packed AFTER the expanding canvas,
so Tk handed it whatever the canvas did not want. As the window narrowed the
panel's controls first ran off the right edge and then stopped being mapped at
all -- at 800 px the entire panel, Analyze button included, was gone, with no
scrollbar and no error. The toolbar failed the same way from the other end:
its last two buttons were already unreachable at 1600 px.

Measured before the fix (61 interactive controls in the tab):

    width   mapped  overflowing   worst overflow
    1600      49         0            --
    1200      46         0            --
    1000      42        18          +102 px
     900      41        22          +202 px
     800      17         0          -- (the panel is GONE, not fixed)

Note the trap in that last row, and why this file asserts on the MAPPED count
rather than only on overflow: an unmapped widget cannot overflow, so
"0 overflowing" at 800 px read like a pass while being the worst case in the
table. A metric that improves when the thing it measures disappears is not
measuring the right thing. Both numbers are asserted here for that reason.

Per MANIFESTO sec 2 these are live widget measurements against a real window,
not inferences from the layout code.
"""
import gc
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    import tkinter as tk
except Exception:
    tk = None

import pytest


WIDTHS = (1600, 1200, 1000, 900, 800, 700, 600)

#: Read off the app rather than hard-coded, so a seventh mode cannot be
#: added without this sweep covering it. Guarded like the tkinter import
#: above: the app module imports tkinter unconditionally, and collection
#: must not fail where it is missing -- the tests themselves skip.
try:
    from apps.truss.truss_app import TrussApp as _TrussApp
    MODE_KEYS = _TrussApp.MODES
except Exception:
    MODE_KEYS = (('analyse',),)

CONTROL_CLASSES = ('Button', 'TButton', 'Checkbutton', 'TCheckbutton',
                   'Radiobutton', 'TRadiobutton', 'TCombobox', 'Entry',
                   'TEntry', 'Scale', 'Listbox')


def _new_root_or_skip():
    if tk is None:
        pytest.skip('tkinter not importable in this environment')
    last = None
    for attempt in range(4):
        try:
            return tk.Tk()
        except Exception as ex:
            last = ex
            gc.collect()
            time.sleep(0.25 * (attempt + 1))
    pytest.skip(f'no display available to run this UI-level check ({last})')


def _all_widgets(w, out):
    try:
        if not w.winfo_exists():
            return
    except Exception:
        return
    out.append(w)
    try:
        kids = w.winfo_children()
    except Exception:
        return
    for ch in kids:
        _all_widgets(ch, out)


def _label_of(w):
    try:
        v = str(w.cget('text'))
        if v and not v.startswith('PY_VAR'):
            return v
    except Exception:
        pass
    return w.winfo_class()


@pytest.fixture()
def truss_app():
    from tkinter import messagebox, filedialog
    for name in ('showerror', 'showwarning', 'showinfo'):
        setattr(messagebox, name, lambda *a, **k: None)
    filedialog.askopenfilename = lambda *a, **k: ''
    filedialog.asksaveasfilename = lambda *a, **k: ''

    from apps.truss.truss_app import TrussApp
    root = _new_root_or_skip()
    root.geometry('1600x950+0+0')
    host = tk.Frame(root)
    host.pack(fill='both', expand=True)
    app = TrussApp(host)
    # Measure EVERY control: the tab opens in Simple mode, which hides the
    # power-user sections on purpose (tests/test_truss_learn.py covers that).
    # Here the question is whether the layout can lose a control, so all of
    # them must be on show.
    app.advanced.set(True)
    app._apply_mode()
    app._load_example()
    app._run_analysis()
    # Both context editors are only packed by the Load / Support tool's click
    # handler; pack them here so their controls are measured too -- otherwise
    # seven of the tab's controls are "unmapped" for a legitimate reason and
    # a real disappearance would hide among them. They live inside their own
    # mode frame now, so they are packed there rather than before the
    # Selection box, which is no longer their sibling.
    app.load_frame.pack(fill='x', padx=8, pady=4)
    app.sup_frame.pack(fill='x', padx=8, pady=4)
    _settle(root)
    try:
        yield root, host, app
    finally:
        try:
            root.destroy()
        finally:
            gc.collect()


def _settle(root, n=12):
    for _ in range(n):
        root.update_idletasks()
        root.update()
        time.sleep(0.03)


def _measure(root, host):
    """(mapped, unmapped, [(label, overflow_px), ...]) at the current width."""
    widgets = []
    _all_widgets(host, widgets)
    controls = [w for w in widgets if w.winfo_class() in CONTROL_CLASSES]
    mapped = unmapped = 0
    overflowing = []
    root_w = root.winfo_width()
    for w in controls:
        try:
            if not w.winfo_ismapped():
                unmapped += 1
                continue
            x = w.winfo_rootx() - root.winfo_rootx()
            over = x + w.winfo_width() - root_w
        except Exception:
            continue
        mapped += 1
        if over > 2:
            overflowing.append((_label_of(w)[:28], over))
        elif x < -2:
            overflowing.append((_label_of(w)[:28], x))
    return mapped, unmapped, overflowing


def _deliberately_hidden(app):
    """Controls the tab hides ON PURPOSE at the current moment, which must not
    be counted against the layout.

    The Construction-geometry panel shows only the fields the chosen guide
    kind uses -- a straight line has no radius, an arc has no expression --
    so a handful of entries are always unpacked and CANNOT all be visible at
    once. That is a different thing from a control the layout has lost, which
    is what this file is guarding, so it is subtracted precisely rather than
    the assertion being softened to a threshold.
    """
    hidden = set()
    for key, row in getattr(app, '_guide_rows', {}).items():
        if row.winfo_manager():
            continue
        hidden.update(str(c) for c in row.winfo_children()
                      if c.winfo_class() in CONTROL_CLASSES)
    # A SET, not a running total: the construction-geometry rows live
    # inside the Build mode frame, so while any other mode is showing,
    # every one of their fields is hidden for BOTH reasons and adding the
    # two counts subtracts nine controls that only exist once.
    hidden.update(_hidden_by_mode(app))
    # The load chooser shows only while "Trace where one load goes" is on.
    lp = getattr(app, 'lp_row', None)
    if lp is not None and not lp.winfo_manager():
        hidden.update(str(c) for c in lp.winfo_children()
                      if c.winfo_class() in CONTROL_CLASSES)
    return len(hidden)


def _hidden_by_mode(app):
    """The controls belonging to a mode the rail is not showing.

    The panel is a mode rail now: Build, Support, Load, Section, Analyse,
    Results, one at a time. Five of the six frames are `pack_forget`-ed
    at any moment BY DESIGN -- that is the whole point of the rail -- so
    counting them as lost would make this test fail on the feature rather
    than on a bug. They are subtracted precisely, and the test below then
    runs the full width sweep once PER MODE, so every control is still
    measured at every width; none is let off.
    """
    frames = getattr(app, '_mode_frames', None)
    if not frames:
        return set()
    active = app.rail.active()
    hidden = set()
    for key, frame in frames.items():
        if key == active:
            continue
        kids = []
        _all_widgets(frame, kids)
        hidden.update(str(w) for w in kids
                      if w.winfo_class() in CONTROL_CLASSES)
    return hidden


@pytest.mark.parametrize('mode', [m[0] for m in MODE_KEYS])
def test_no_control_is_dropped_or_pushed_off_as_the_window_narrows(
        truss_app, mode):
    """Once per mode, because the panel shows one mode at a time.

    Running this on the active mode alone would leave five sixths of the
    panel unmeasured, and the clipping this file exists to catch would
    simply move into whichever mode nobody looked at.
    """
    root, host, _app = truss_app
    _app.rail.select(mode)
    seen = {}
    for width in WIDTHS:
        root.geometry('%dx950+0+0' % width)
        _settle(root)
        mapped, unmapped, overflowing = _measure(root, host)
        seen[width] = (mapped, unmapped - _deliberately_hidden(_app), overflowing)

    widest = seen[WIDTHS[0]][0]
    assert widest > 0, 'measured no controls at all -- the harness is broken'

    for width in WIDTHS:
        mapped, unmapped, overflowing = seen[width]
        assert unmapped == 0, (
            'in %s mode at %d px, %d control(s) are not mapped at all, over '
            'and above the guide fields and the other modes the panel hides '
            'on purpose. Before T-1 the whole right panel vanished below '
            '850 px; check the pack order in _build_ui -- the ScrollPanel '
            'must be packed BEFORE the expanding ZoomCanvas.'
            % (mode, width, unmapped))
        assert mapped == widest, (
            'in %s mode at %d px only %d of %d controls are mapped -- the '
            'count must not fall as the window narrows'
            % (mode, width, mapped, widest))
        assert not overflowing, (
            'in %s mode at %d px these controls sit past the window edge: %s'
            % (mode, width, ', '.join('%s (%+d px)' % t for t in overflowing)))


def test_toolbar_wraps_to_more_rows_as_the_window_narrows(truss_app):
    """The toolbar must actually re-flow, not merely avoid overflowing by
    luck. Its wrapped-row count is the direct evidence FlowBar is running."""
    root, _host, app = truss_app

    def row_count(flow):
        return sum(1 for w in flow.bar.winfo_children()
                   if getattr(w, '_is_flow_row', False))

    root.geometry('1600x950+0+0')
    _settle(root)
    wide = row_count(app.toolbar_flow)

    root.geometry('700x950+0+0')
    _settle(root)
    narrow = row_count(app.toolbar_flow)

    assert wide >= 1, 'the toolbar was never laid out by its FlowBar'
    assert narrow > wide, (
        'the toolbar did not wrap: %d row(s) at 1600 px, %d at 700 px'
        % (wide, narrow))


def test_panel_keeps_its_content_reachable(truss_app):
    """The panel is allowed to be narrower than its content -- that is what
    the horizontal scrollbar is for -- but only when the window is genuinely
    tight, and the scrollbar must actually appear when it happens."""
    root, _host, app = truss_app
    panel = app.panel_outer

    root.geometry('1600x950+0+0')
    _settle(root)
    assert panel.canvas.winfo_width() >= panel.interior.winfo_reqwidth() - 2, (
        'on a wide window the panel should fit its own content without '
        'needing horizontal scrolling')

    root.geometry('600x950+0+0')
    _settle(root)
    if panel.interior.winfo_reqwidth() > panel.canvas.winfo_width() + 1:
        assert panel._hsb_shown, (
            'the panel content is wider than the panel but no horizontal '
            'scrollbar is shown -- the content is unreachable')
        assert panel.hsb.winfo_ismapped() and panel.hsb.winfo_height() > 0, (
            'the horizontal scrollbar is flagged as shown but has no size; '
            'a pack()ed latecomer next to an expand=True canvas gets zero '
            'space -- it must be grid()ed')


@pytest.mark.parametrize('report', ('_show_rod_calculations_report',
                                    '_show_node_vectors_report'))
def test_analysis_still_shows_diagrams_after_a_report_window_opened(
        truss_app, report):
    """The diagram pane was packed "before the root's last child". Once a
    report window was open that child was a Toplevel, which is not packed,
    and every later analysis raised TclError ("isn't packed") instead of
    showing the diagrams.

    The pane is a PanedWindow pane now (common.AppShell), so it is no
    longer packed at all and cannot fail that way again -- but the
    behaviour this guards is the same and still worth pinning: open a
    report, lose the pane, analyse, and the diagrams must come back
    without raising.
    """
    root, host, app = truss_app
    getattr(app, report)()
    _settle(root, 4)
    app.shell.hide_lower()
    _settle(root, 2)
    assert not app.shell.lower_visible()

    app._run_analysis()
    _settle(root, 4)
    assert app.shell.lower_visible(), (
        'the diagram pane did not come back after an analysis with a '
        'report window open')
    assert app.diag_outer.winfo_ismapped()
    assert app.diag_zc.canvas.find_all(), 'the pane is back but empty'


def test_the_diagram_pane_sits_below_the_drawing_and_above_the_status_bar(
        truss_app):
    """What the old pack-order assertion was really protecting: the
    diagrams read under the structure they describe, not over it."""
    root, host, app = truss_app
    app._run_analysis()
    _settle(root, 4)
    assert app.shell.lower_visible()
    assert app.zc.winfo_rooty() < app.diag_outer.winfo_rooty()
    assert app.diag_outer.winfo_rooty() < app.status_bar.winfo_rooty()


def _canvas_texts(c):
    return [c.itemcget(i, 'text') for i in c.find_all() if c.type(i) == 'text']


def test_pure_truss_gets_one_compact_axial_chart(truss_app):
    """Every rod of the example is pinned and loaded at its nodes: the
    diagram pane shows a signed N bar per rod, not empty V/M boxes."""
    root, host, app = truss_app
    texts = _canvas_texts(app.diag_zc.canvas)
    assert not any(t.startswith('Shear V') for t in texts)
    assert any(t.startswith('Axial force N in every rod') for t in texts)
    for i, r in enumerate(app.results['rod_res']):
        assert ('Rod %d' % i) in texts
        assert any(t.startswith('%+.2f' % r['force']) for t in texts)


def test_vierendeel_keeps_shear_and_moment_rows(truss_app):
    root, host, app = truss_app
    app._load_example_vierendeel()
    app._run_analysis()
    _settle(root, 4)
    texts = _canvas_texts(app.diag_zc.canvas)
    assert any(t.startswith('Shear V') for t in texts)
    assert any(t.startswith('Axial force N (') for t in texts)


def test_solved_rods_carry_their_axial_force_and_a_key(truss_app):
    root, host, app = truss_app
    c = app.zc.canvas
    labels = {c.itemcget(i, 'text') for i in c.find_withtag('rod_label')}
    for i, r in enumerate(app.results['rod_res']):
        assert '%d: %+.1f' % (i, r['force']) in labels
    key = c.find_withtag('force_key')
    assert key
    # pinned to the bottom of the canvas even after the diagram pane opened
    assert all(abs(c.coords(k)[1] - (c.winfo_height() - 12)) < 2 for k in key)
    # editing un-solves the model: back to bare numbers, no key
    app.results = None
    app._draw()
    assert not c.find_withtag('force_key')
    assert {c.itemcget(i, 'text') for i in c.find_withtag('rod_label')} == \
        {str(i) for i in range(len(app.rods))}


def test_status_bar_tells_the_truth_after_a_failed_or_unloaded_analysis(truss_app):
    root, host, app = truss_app
    app._load_example()
    del app.rods[1]                       # a diagonal gone: a mechanism
    app._run_analysis()
    assert app.status_var.get().startswith('Analysis failed')
    app._load_example()
    app.loads = []
    app._run_analysis()
    assert 'no loads are applied' in app.status_var.get()
