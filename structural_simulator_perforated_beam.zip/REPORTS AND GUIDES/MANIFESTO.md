# Cable Web — Project Manifesto

**Read this before changing anything in `apps/cable_web/`.**

This document exists because the project's own history (see the other
files in this folder — `DIAGNOSTIC_REPORT.md`, `CONVERGENCE_FIX_V11.md`,
`UI_NAVIGATION_CABLE_WEB_V12.md`, `REGRESSION_NOTES.md`) shows a repeating
pattern across sessions: fix X, silently reintroduce Y; fix Y, quietly
regress X. Each individual report was technically correct about the bug
it fixed. What was missing was a stable place to write down the *general
lesson* behind each fix, so a future session (or future me) recognizes
the pattern before repeating it. That's what this file is for. It is
meant to be **added to, not replaced**, the next time a session here
learns something the hard way.

Last updated: 2026-08-20 (second pass same day), after fixing the flat
"plateau" artifact at a slack segment's low point (an under-resolved mesh
in the §3h fix) and the identical bug in the ghost/reference catenary,
by extracting both into one shared, properly-resolved, timing-tested
helper — see §3i, §3j, §3k. Before that: fixed support drag not working
when a load overlaps it, and a wrong sinusoidal path on slack/zero-tension
cable segments (§3g, §3h). Originally written 2026-08-19 after a
diagnostic pass that fixed three UI bugs (support placement not
redrawing, mouse-wheel zoom/pan not redrawing, and toolbar rows rendering
off-screen or invisible) and confirmed all three `cableweb_report*.xlsx`
cases import and solve correctly through the real UI pipeline.

---

## 1. Architectural invariants — do not violate these

1. **The UI never does structural equilibrium math.** `cable_web_app.py`
   builds a solver model and calls `solve_force_density` /
   `solve_analysis` from `cable_web_math.py`; it does not compute
   tensions, reactions, or geometry itself. If a UI feature seems to need
   new math, the math goes in `cable_web_math.py` (or a thin adapter
   layer next to it), not in a button callback.
2. **A non-converged result is never shown as if it were valid.**
   `_solve_exact` already enforces this (`if not result.converged: self.result
   = None`) — preserve this. A near-equilibrium Newton iterate that
   *looks* like a funicular but isn't one is worse than no result at all.
3. **Object ids are stable and never reused or renumbered on delete.**
   Don't refactor toward list-index-based identity for nodes/cables/loads
   — that reintroduces exactly the class of bug stable ids were adopted
   to avoid.
4. **`cable_web_math.py` is expensive to modify, cheap to leave alone.**
   It is validated (see `tests/test_cable_web_math.py`, 7/7 passing as of
   this writing) and its convergence behavior (including the ~20s solves
   on indeterminate-junction networks, see §4) is understood and
   accepted, not accidental. Don't touch its numerical strategy to chase
   a UI-perceived problem (e.g. "it's slow") — fix the UI's *handling* of
   that behavior instead (see the busy-cursor fix in §3e below), and only
   revisit the solver itself as a deliberate, dedicated, separately-tested
   effort.

---

## 2. Diagnostic method that actually works — use this, not guesswork

Every bug in this session was found by **running the real UI under a
virtual display (Xvfb) and either taking an actual screenshot or directly
querying live widget geometry** — never by reading the code and reasoning
about what it "should" do. Two specific traps this project has already
fallen into make static reasoning unreliable here:

- A widget can report `winfo_ismapped() == True` with entirely correct
  `x, y, width, height` and still be **completely invisible**, painted
  over by a sibling widget with a higher stacking position (§3d). Don't
  trust geometry queries alone as proof something is visible.
- Screenshotting an Xvfb session with `import -window root` can silently
  capture a stale/blank buffer. Get the specific window's id via
  `root.winfo_id()` and screenshot *that* (`import -window <id>`) —
  confirmed reliable in this session; `root` was not.

**Standard verification checklist for any change in this app:**
1. Run `python3 -m pytest -q` from `structural_simulator_modules/` — must
   be 7/7 (or however many exist by the time you read this) passing.
2. Launch the app under Xvfb, actually take a screenshot at 2–3 window
   widths spanning wide to narrow (e.g. 1600px, 1000px, 550px), and
   *look at it*. Don't infer from `winfo_ismapped()` alone.
3. Programmatically invoke every toolbar button (monkeypatch
   `filedialog.askopenfilename/asksaveasfilename` to return a fixed path
   or `''`, `messagebox.*` to no-ops, and `tk.Toplevel.wait_window` to a
   no-op, or a button that opens a blocking dialog will hang the test
   process indefinitely) and confirm none raise.
4. Re-import at least one `cableweb_report*.xlsx` (or equivalent) through
   the real `_import_excel` → `_validate_model` → `_solve_exact` pipeline
   and confirm it still converges. These three files are a good
   regression fixture — keep them, or equivalents, for this purpose.

---

## 3. Specific hard-won lessons from this session (bug *classes*, not just instances)

### a. Every model-mutating branch of a click handler must redraw
`_canvas_press`'s `'support'` branch called `self._invalidate(...)` but
never `self._draw()` — every sibling branch (`'cable'`, etc.) did. The
result: a newly placed support was fully created in the model and
invisible until *any* unrelated redraw happened to fire (e.g. switching
to the Select tool). **When adding or editing a tool branch in a click
handler, check that it ends in a redraw, by direct comparison with a
sibling branch that's known to work — don't assume `_invalidate` or
similar bookkeeping helpers redraw internally.**

### b. `ZoomCanvas._on_zoom_changed` must be wired up explicitly
`common.py`'s `ZoomCanvas` updates `zoom`/`pan_x`/`pan_y` internally on
wheel-scroll and middle-drag, and calls `self._on_zoom_changed()` — a
no-op placeholder by default. Every other tab
(`self.zc._on_zoom_changed = self._draw`, see `truss_app.py`) overrides
it; Cable Web didn't, so wheel zoom and middle-drag pan silently changed
internal state with the view never repainting. **Any new `ZoomCanvas`
instance must wire `_on_zoom_changed` to a redraw in the same line it's
constructed — there's no other signal that this was forgotten.**

### c. Don't cache a layout decision keyed only on "did the input change"
The toolbar's responsive relayout short-circuited when
`bar.winfo_width()` matched a cached `_toolbar_last_width`. The *first*
call (from `after_idle`, before the window had fully stabilized) could
read a transient, wrong width, compute a wrong layout from it, and cache
that width — after which a later, legitimate resize back to the *same*
final width would hit the cache and never re-run the correct
computation. **A perf-guarding cache is only safe if the cached decision
is re-validated against reality sometime, not just re-used verbatim
because a proxy input matched.** If in doubt, don't cache a `<Configure>`
handler's work at all — for anything under a few hundred widgets it's not
worth the risk.

### d. `grid(row=, column=)` is the wrong tool for an independent flow layout
Tk's grid geometry manager sizes **each column to the widest occupant of
that column across every row** of the same parent. A "wrap groups to new
rows as needed" layout built with `grid(row=, column=)` directly on one
parent will misalign/overflow any row whose column widths don't happen to
match another row's — which they generally won't, since different rows
hold different numbers/widths of items. **For any layout where each row
should be sized independently (a flow/wrap layout), use one `Frame` per
row, `pack(side='left')` items inside it, and `pack(side='top')` the row
frames — never `grid(row=, column=)` shared across rows of varying
content.**

### e. `pack(in_=sibling_frame)` needs `.lower()` on that sibling, or it hides its own contents
Fixing (d) by introducing per-row anchor frames and
`child.pack(in_=row_frame, ...)` looks like it reparents `child` under
`row_frame` — **it does not.** `child`'s true Tk parent stays whatever it
was created with; `pack(in_=...)` only controls *where* it's drawn.
`row_frame` and `child` are still true siblings under the original
parent, and Tk's stacking order among true siblings is governed by
creation time — so a freshly-created `row_frame` (built *after* the
long-lived widgets it's meant to position) paints **on top of** them,
hiding them completely, even though every individual widget reports
itself correctly mapped and positioned. This is exactly the kind of bug
§2's "geometry looks right but isn't visible" warning is about,
and it's why the toolbar could pass a geometric overlap/off-screen check
and still render completely blank. **Any time you create a new Frame
purely as a `pack(in_=...)` positioning anchor for already-existing
sibling widgets, call `.lower()` on that anchor frame immediately** so it
sits behind, not in front of, the content it's positioning.

### f. Long synchronous solves need a busy indicator, not a rewrite
`solve_analysis` runs on the Tk main thread; a ~20s solve (observed and
expected — see §4 — for the multi-junction topology in all three
`cableweb_report*.xlsx` cases) freezes the entire UI with zero feedback
unless something explicitly shows a status message and busy cursor
*before* the blocking call, forced to paint via `update_idletasks()`.
This was missing in `_solve_exact` and has been added (status text +
`toplevel.config(cursor='watch')`, reset in a `finally:`). **This is a UI
fix, not a performance fix** — it does not change how long the solve
takes, only whether the user can tell the app is working rather than
frozen. Don't conflate "make the wait less confusing" with "make the
solver faster" — they're different problems with very different risk
profiles (see §1.4).

### g. Hit-testing must compare distances across candidate types, not use a fixed priority order
`_hit()` checked loads, then nodes, then cables, in that fixed order —
so a load positioned at or near a support (an entirely ordinary layout;
a UDL starting exactly at s=0 sits right on top of its cable's start
support) always won the hit test, even when the support was the far
closer (or exactly co-located) candidate. This silently made select+drag
on a support "not work" any time a load happened to sit there, which
reads as a random, hard-to-reproduce bug rather than what it actually
was: a deterministic priority-order defect. **Fixed by gathering the
closest candidate of each type with its own distance and picking the
global minimum** (node checked first in the candidate list so it wins
ties, e.g. a load positioned at exactly zero distance from a node — see
the code comment at `_hit()` for why ties should favor the structural
point). Verified via `_hit()` called directly at a support's exact
position with a UDL starting there (now returns the node), and at the
load's own body away from the support (still returns the load). If you
add a new selectable object type later, route it through this same
distance-comparison, not a new priority tier.

### h. A slack, unloaded (zero-tension) cable segment has no unique shape — don't trust its raw solved interior positions for display
A segment with more prescribed length than its straight-line span
(slack) and zero applied load (no self-weight, no point/UDL loads) has
**tension ≈ 0 everywhere along it** in the true solved equilibrium. This
is not a solver defect: with T=0, the force-balance equations impose no
directional preference at all, so *any* sufficiently loose configuration
of its free interior nodes is equally valid. The solver's Newton
iteration lands on whatever such configuration it happens to converge
to — which can be a visually wiggly, multi-hump path with no physical
significance, even though it satisfies the length/equilibrium
constraints exactly and the solve genuinely converges.

Diagnosed 2026-08-20 on the Picture Test example: the stretch between
a junction and its neighboring support had 2.85 units of slack, zero
load, and tensions of order `1e-12` against a network scale of
100-200 (i.e. correctly, genuinely zero) — yet displayed a sinusoidal
path (4 sign changes in the y-sequence between its 6 control points,
where a proper single-lobe catenary should show at most 1). Confirmed
this was in the RAW solved points themselves (before `_smooth_polyline`
ever runs), not a smoothing/interpolation artifact — ruling out §3d/e-style
display-math causes first, rather than assuming.

**Fix (display-only, in `_draw_solver_result`): when every edge in a
drawn group has near-zero tension (`< max(tmax * 1e-6, 1e-9)`), don't
trust that group's raw interior solved positions. Instead, treat its two
endpoints (junctions/supports/point-load nodes — always trustworthy,
never part of the arbitrary interior) as fixed, and re-derive a clean
shape by solving a small independent model with a nominal self-weight
(`weight_per_length=1.0`) between them — exactly the technique the
codebase already uses for the unloaded reference ghost in
`_update_reference_result`.** This never touches the real solved model,
tensions, or reactions — the reported `T≈0` for that stretch is correct
and is displayed as-is; only the *curve shape* drawn for that one group
is substituted. Verified by extracting the actual live `_smooth_polyline`
call arguments before/after the fix: sign changes in the affected
group's y-sequence went from 4 to 1, with zero change to the other five
groups in the same example.

**If you see another wiggly/wrong-looking cable segment in the future,
check tension first** (`result.tensions.get(eid)` for its edges) before
assuming it's a display bug — a near-zero-tension slack segment is a
different problem (and a different, already-solved fix) than an
actually-loaded segment whose curve looks wrong for some other reason.

### i. A resolution cap is not the same thing as the formula that chooses resolution
Both `_solver_breakpoints`' mesh density and the original
`_update_reference_result`/`_draw_solver_result` mini-catenary code used
`nseg = max(4, min(SOME_CAP, ceil(target/2.5)))`. It's tempting to assume
raising `SOME_CAP` fixes an under-resolved curve — it doesn't, if the
*formula* (`ceil(target/2.5)`) already produces a value well below every
cap in sight. Diagnosed 2026-08-20: for `target=11.0`, `ceil(11/2.5)=5`,
which is less than caps of 8, 10, *and* 12 — so raising the cap alone,
which was the first thing that looked like the fix, would have changed
nothing. The actual under-resolution came from the divisor (2.5 units
per segment was too coarse for this size of slack/sag), not the cap.
**When a mesh/resolution bug shows up, check what the un-capped formula
actually evaluates to for the specific case at hand before assuming the
cap is the lever to pull.**

### j. The same sub-problem solved in two places will drift unless it's actually the same code
The "give a slack, unloaded stretch a sensible nominal-self-weight shape"
logic existed independently in `_update_reference_result` (the ghost) and
in `_draw_solver_result` (the zero-tension substitution added in §3h) —
copy-pasted with a slightly different `nseg` formula in each. The
resolution bug in §3h was fixed once in the display code; the *identical*
bug was still sitting in the ghost/reference code, reported separately as
"a second flaw in the ghost catenary system" a session later. **Extracted
both into one shared method, `_solve_nominal_catenary`,** so this class of
fix now only has one place to land. If you're about to fix a bug in one
of these two call sites again, check whether it's still calling the
shared helper (it should be) rather than a reintroduced local copy.

### k. Mind the solve-time cliff when choosing a mesh resolution
Measured directly on this exact case (`target=11.0`, plain hanging chain,
nominal self-weight): 11 segments → 0.4s, 12 → 0.7s, 14 → 0.9s, 20 →
11.7s, 30 → did not converge within 30s. The relationship is not smooth
or predictable — there's a cliff somewhere between 14 and 20 for this
solver's current Newton/multi-seed strategy. `_solve_nominal_catenary`
caps at 14 for exactly this reason. **Do not raise that cap without
re-measuring timing on a range of realistic cases first** — "a bit more
resolution" can silently turn into an 11-second stall per affected
segment, and per §1.4, that's a solver-timing question, not something to
guess at.

---

## 4. Known, accepted performance characteristic (not a bug)

All three provided `cableweb_report*.xlsx` cases share the same topology
pattern: two attachment nodes, each where 3 cables meet (an indeterminate
junction — more tension unknowns than equilibrium equations at that
node). `solve_analysis`'s multi-seed fallback strategy for this case
takes roughly **20 seconds** on this hardware, converging to a residual
around `1e-8`–`1e-15` (correct, just slow to reach). This was confirmed
across all three files, not just the most complex one. If this becomes a
priority to improve, treat it as a dedicated profiling/optimization task
against the existing validated test suite — not something to touch as a
side effect of a UI fix.

---

## 5. What's next (not done in this pass, deliberately)

This pass was scoped to: fix reported UI bugs (support visibility, wheel
zoom/pan, toolbar rendering), confirm the three provided Excel cases
still solve correctly, and write this manifesto. Not touched, and not
implied to be broken:

- The ~20s solve performance (§4) — flagged, not addressed.
- Any load-tool/dialog UI beyond what the existing button-invocation
  check covers (every toolbar button was invoked and didn't raise, but
  that's not the same as a full workflow test of every dialog's fields).
- `truss_app.py`, `beam_app.py`, `arch_app.py`, and their solvers — not
  touched, per the instruction to leave other tabs alone.

If you're picking this project up next: read this file, run the
checklist in §2, and only then start changing things.
