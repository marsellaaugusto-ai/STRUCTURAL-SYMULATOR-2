"""
truss_app.py — Truss / Vierendeel tab.

Pin-jointed OR rigid-jointed 2D frame solver (analyze()), the Truss/
Vierendeel schematic + diagram UI (TrussApp), and this tab's Excel
report/import (export_excel / import_excel_model). A rod left "pin" behaves
exactly like a classic truss bar; a rod set to "rigid" carries N, V and end
moments Ma/Mb via a full 2D frame element -- the mechanism a Vierendeel
girder uses in place of diagonals. See TrussApp's docstrings and the
"Vierendeel diagram" toggle for the rest.
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import copy
import math, os

import units

from common import (
    _ensure_openpyxl, _ensure_matplotlib,
    SNAP, PX_PER_M, PANEL_W, INIT_CW, INIT_CH, INIT_DH,
    UnitsMixin,
    CT, CC, CZ, CD, CN, CS, CL, CSP, CG, CG_MINOR, CG_MICRO, CV, CM, CR, CMOM,
    _beam_gauss_solve, ZoomCanvas, FlowBar, ScrollPanel, LoadScale,
    AppShell, CollapsibleSection, ModeRail,
)
gauss_solve = _beam_gauss_solve  # truss's analyze() historically calls this
                                  # name; both solvers are the same algorithm

def _nice_grid_step(base_px, z, target_px=55):
    """Smallest 1-2-5x10^k multiple of base_px whose screen spacing (at the
    given zoom z) is at least target_px. Shared by the adaptive LOD grid
    drawing and the grid-snap increment, so they always stay in sync."""
    seq = (1, 2, 5)
    i = 0
    while True:
        mult = seq[i % 3] * (10 ** (i // 3))
        step = base_px * mult
        if step * z >= target_px or i > 60:
            return step, mult
        i += 1

def _grid_subdiv_of(mult):
    """1-2-5 convention: a '1' or '5' leading digit subdivides by 5, a '2'
    leading digit subdivides by 2 (keeps every intermediate step itself a
    'nice' 1-2-5 multiple)."""
    exp = math.floor(math.log10(mult) + 1e-9)
    lead = mult / (10 ** exp)
    return 2 if abs(lead - 2) < 0.05 else 5

def dist_seg(px, py, ax, ay, bx, by):
    dx, dy = bx-ax, by-ay
    l2 = dx*dx+dy*dy
    if l2 == 0:
        return math.hypot(px-ax, py-ay)
    t = max(0.0, min(1.0, ((px-ax)*dx+(py-ay)*dy)/l2))
    return math.hypot(px-ax-t*dx, py-ay-t*dy)

def near_node(nodes, wx, wy, thr=14):
    """world-space hit test"""
    for i in range(len(nodes)-1, -1, -1):
        if math.hypot(nodes[i][0]-wx, nodes[i][1]-wy) < thr:
            return i
    return -1

def near_rod(nodes, rods, wx, wy, thr=7):
    for i in range(len(rods)-1, -1, -1):
        r = rods[i]
        a, b = nodes[r['a']], nodes[r['b']]
        if dist_seg(wx, wy, a[0], a[1], b[0], b[1]) < thr:
            return i
    return -1

# `analyze` and `compute_diagrams` are also imported FROM this module by
# tests/test_truss_load_signs.py, so this line is a public re-export surface,
# not just a local convenience -- don't prune it down to "what truss_app.py
# itself calls" without checking the tests first.
from .truss_math import (analyze, compute_diagrams, find_zero_crossings, plate_node_loop,
                          deformed_shape_points, deformed_point_at,
                          compute_fiber_stress, compute_node_design_actions)
from .truss_reports import export_excel, import_excel_model
from . import truss_plates, truss_guides, truss_loadpath
from .truss_app_learn import TrussLearnMixin, LIVE_MAX_RODS
from .truss_app_design import TrussDesignMixin
from .truss_app_play import TrussPlayMixin
from .truss_app_buckling import TrussBucklingMixin

class TrussApp(TrussLearnMixin, TrussDesignMixin, TrussPlayMixin,
               TrussBucklingMixin, UnitsMixin):
    # This tab does NOT store stress the way the others do. Plate yield and
    # electrode strength have always been typed in MPa here, while the Beam
    # tab holds allowable stresses in kN/cm2. Declaring the difference is
    # safer than changing either, since changing one would silently
    # reinterpret every model already saved in it. Plate and bolt dimensions
    # are `detail_length`, which is mm in storage and in every SI convention.
    STORAGE_UNITS = units.storage_like('truss storage', stress=units.MPA)

    def __init__(self, root):
        self.root = root
        self.init_units(repaint=self._on_units_changed)

        # model data
        self.nodes    = []
        self.rods     = []
        self.plates   = []      # gusset (P-1, annotation) + panel (P-2, member)
        self.guides   = []      # construction geometry (not structure)
        self.sel_guide = None   # index of the selected guide, or None
        self._guide_drag = None # in-progress guide/handle drag
        self._picking_conic = False
        self._array_history = {}  # guide index -> {'kw':..., 'nodes':[...]}
        self._undo_stack = []   # [(label, snapshot)], oldest first
        self._redo_stack = []
        self._clipboard  = None # {'nodes':..,'rods':..,'base':(wx,wy)}
        self.loads    = []
        self.supports = []
        self.results  = None
        self.diagrams = None
        self.profiles = {'Default': {'E': 200.0, 'A': 10.0, 'I': 8000.0}}   # rod "families"

        # interaction
        self.tool         = tk.StringVar(value='node')
        self.rod_start    = None
        self.selected_nodes = set()     # multi-select capable (box or piece)
        self.selected_rods  = set()
        self.pending_load = set()
        self.pending_sup  = set()
        self.active_profile = tk.StringVar(value='Default')
        self._tip_win     = None
        self.plate_checks = []
        self._tip_after   = None

        # box-select drag state
        self._press_sx = self._press_sy = None
        self._press_wx = self._press_wy = None
        self._dragging_box = False
        self._box_cur = None
        self._moving_sel = False      # dragging the selection, not a box
        self._move_from = None        # world point the move started at
        self._move_orig = None        # {node index: original (wx, wy)}

        # CAD precision state
        self.cad_mode       = tk.StringVar(value='free')  # free|coord|polar|angle_snap
        self.snap_grid      = tk.BooleanVar(value=True)
        self.snap_node      = tk.BooleanVar(value=True)
        self.snap_angle     = tk.BooleanVar(value=False)
        self.snap_curve     = tk.BooleanVar(value=True)
        self.snap_angle_deg = tk.IntVar(value=15)
        self.cad_x          = self.unit_var(tk.DoubleVar(value=0.0), 'length')
        self.cad_y          = self.unit_var(tk.DoubleVar(value=0.0), 'length')
        self.cad_dist       = self.unit_var(tk.DoubleVar(value=1.0), 'length')
        self.cad_angle      = tk.DoubleVar(value=0.0)
        self.ruler_active   = tk.BooleanVar(value=False)
        self._space_pan     = False   # space held down -> drag pans
        self._lp = None               # the load-path trace being shown
        self._lp_phase = 0.0          # chevron travel, 0..1
        self._lp_job = None
        self._lp_node = None          # the load picked to trace, by joint
        self.ruler_start    = None   # world (wx,wy) or None
        self._mouse_wx      = 0.0   # live world cursor position
        self._mouse_wy      = 0.0
        self._ghost_wx      = None  # where next node would land
        self._ghost_wy      = None
        self._build_ui()
        self._draw()

    # ══════════════════════════════════════════════════════════════════════════
    #  UI
    # ══════════════════════════════════════════════════════════════════════════
    def _build_ui(self):
        root = self.root
        root.configure(bg='#f5f5f3')

        # ── toolbar ──────────────────────────────────────────────────────────
        # Laid out by a FlowBar (common.py): buttons are grouped by purpose,
        # and whole groups drop to a second/third row rather than running off
        # the right edge. Before this the tail of the bar -- Node Force
        # Vectors and Rod Calculations -- was already unreachable at 1600 px,
        # and the row lost roughly one more button per 100 px below that.
        # Do NOT pack() straight into `tb`: build into a group and let the
        # FlowBar place it, or it will be dropped from the relayout.
        # LAYOUT. Everything below is placed inside a common.AppShell:
        # toolbar on top, control panel on the LEFT behind a draggable sash,
        # drawing filling the rest, diagram pane under it behind a second
        # sash, status bar at the bottom. The panel was on the RIGHT at a
        # fixed 235 px -- 105 narrower than Beam/Arch/Cable for strictly
        # more content, which is what the clipping fixes recorded through
        # `_build_panel` were all chasing. The width is now the user's.
        self.shell = AppShell(root, panel_width=PANEL_W + 105, status=False)
        self.shell.pack(fill='both', expand=True)
        tb = self.shell.toolbar
        self.toolbar_flow = FlowBar(tb)
        # State only -- no widgets. Run first so `self.advanced` and
        # `self.live_var` exist for the groups below, which now own the
        # controls that read them.
        self._build_learn_toolbar()

        # The groups, in Stereo's order, because Stereo's bar reads as a
        # sentence and this one did not: MAKE it -> RUN it -> FIX it ->
        # LOOK at it -> GET IT OUT, with the drawing tools up front
        # because that is the one thing Truss does that Stereo does not.
        # Stereo's own order is Generate, Analyze, Live, Clear, undo/redo,
        # Display, Export, and every name that means the same thing in
        # both tabs is now spelt the same way (`Display ▾`, not `View ▾`),
        # so a student who learns one bar can already drive the other.
        mark_g = self.toolbar_flow.group()
        tk.Label(mark_g, text='TRUSS', bg='#ebebea', fg='#1a6bbd',
                 font=('Helvetica', 11, 'bold')).pack(side='left',
                                                      padx=(4, 8))

        tools_g = self.toolbar_flow.group()
        self.tool_btns = {}
        for label, val, tip in [
                ('Node', 'node', 'Place joints. Click the canvas; the point snaps to the grid.'),
                ('Rod', 'rod', 'Connect two joints with a member. Click the first, then the second.'),
                ('Support', 'support', 'Hold a joint down. Click it, then choose the support type in the panel.'),
                ('Load', 'load', 'Push or pull a joint. Click it, then set Fx/Fy in the panel.'),
                ('Select', 'select', 'Inspect and edit. Click, shift-click or drag a box; Delete removes.'),
                ('Pan', 'pan', 'Drag the canvas with the left mouse button to move the view. '
                               'The middle button still pans from any tool -- this is here '
                               'because most laptop trackpads do not have one.')]:
            # No fixed `width`: six buttons padded out to seven characters
            # each cost about 150 px of nothing, which was the difference
            # between this bar fitting on one row at 1366 px and not.
            b = tk.Button(tools_g, text=label, relief='flat', bd=0,
                          padx=9, pady=4, font=('Helvetica',11),
                          command=lambda v=val: self._set_tool(v))
            self.tool_btns[val] = b
            self._bind_widget_tooltip(b, tip)

        # MAKE: where a model comes from. Stereo's `Generate ▾` sits in
        # exactly this slot.
        self.toolbar_flow.separator()
        make_g = self.toolbar_flow.group()
        # The library holds nine trusses with a lesson each (the Vierendeel
        # girder among them); the first entry stays the one-click Warren.
        self._menu_button(make_g, 'Examples ▾', [
            ('Warren truss — how triangles carry load', self._load_example),
            ('K-truss bridge — 97 members, 64 m',
             lambda: self._load_library_example('k_truss_bridge')),
            ('sep',),
            ('Browse the library…', self._open_examples),
        ])

        # RUN: the one verb that commits to something, and the switch that
        # makes it automatic. Live was two rows down in the panel; it
        # turns this button on and off, so it belongs beside it.
        self.toolbar_flow.separator()
        run_g = self.toolbar_flow.group()
        # Green, outlined, like Stereo's: the one verb on the bar that
        # commits to something, and the only control with a border.
        self.analyze_btn_bar = tk.Button(
            run_g, text='▶ Analyze', bg='#eaf6ec', fg='#1a7a3a',
            activebackground='#d8eedd', activeforeground='#145c2c',
            font=('Helvetica', 11, 'bold'), relief='solid', bd=1,
            padx=12, pady=3, command=self._run_analysis)
        self._bind_widget_tooltip(self.analyze_btn_bar,
            'Solve the structure. The same button sits at the top of the '
            'panel; it is in both places because it is the one control that '
            'must never need scrolling to reach.')
        live_cb = tk.Checkbutton(run_g, text='Live', variable=self.live_var,
                                 bg='#ebebea', font=('Helvetica', 10),
                                 command=self._on_live_toggle)
        self._bind_widget_tooltip(live_cb,
            'Re-solve a quarter of a second after every edit (models up to '
            '%d rods), so the forces move with the drawing.' % LIVE_MAX_RODS)

        # FIX: undo the last thing, or start again.
        self.toolbar_flow.separator()
        model_g = self.toolbar_flow.group()
        tk.Button(model_g, text='Clear', relief='flat', bd=0, padx=8, pady=4,
                  font=('Helvetica',11),
                  command=self._clear_all)
        self.undo_btn = tk.Button(model_g, text='↶', relief='flat', bd=0,
                                  padx=9, pady=4, font=('Helvetica', 13),
                                  command=self._undo)
        self.redo_btn = tk.Button(model_g, text='↷', relief='flat', bd=0,
                                  padx=9, pady=4, font=('Helvetica', 13),
                                  command=self._redo)
        # Undo has existed here since the arrays landed, with readable
        # labels on every entry, and had no button at all -- only Ctrl+Z.
        # Beginners experiment far more freely when they can see the way
        # back.
        self._bind_widget_tooltip(self.undo_btn, 'Undo the last change  (Ctrl+Z)')
        self._bind_widget_tooltip(self.redo_btn, 'Redo  (Ctrl+Y or Ctrl+Shift+Z)')

        # LOOK: what is drawn on top of the model.
        #
        # The six display switches USED TO LIVE HERE, in a `Display ▾`
        # menu. They are in the Analyse mode's panel now ("What to show"),
        # because that is where you are standing when you want them: you
        # press Analyze, look at the result, and only then ask to see the
        # deformed shape or the joint letters. Reaching back up to a menu
        # on the toolbar to change what the drawing in front of you shows
        # is a trip, and the panel can show all six at once with the
        # deflection scale beside the switch it belongs to.
        #
        # `Advanced tools` stays: it is not about what is DRAWN, it is
        # about which controls exist, and it has to be reachable from
        # every mode including the ones it adds sections to.
        self.toolbar_flow.separator()
        view_g = self.toolbar_flow.group()
        self.show_deform = tk.BooleanVar(value=False)
        self.show_contraflexure = tk.BooleanVar(value=True)
        self.show_node_moments = tk.BooleanVar(value=False)
        self.show_force_labels = tk.BooleanVar(value=True)
        self.letter_joints = tk.BooleanVar(value=True)
        self.show_load_path = tk.BooleanVar(value=False)
        self.def_scale = tk.IntVar(value=50)
        self._menu_button(view_g, 'Display ▾', [
            # Simple shows what a first truss needs; Advanced adds the CAD
            # bar, construction geometry, arrays, plates and rod families.
            ('check', 'Advanced tools', self.advanced, self._apply_mode),
            ('sep',),
            ('What to show on the drawing →  Analyse',
             lambda: self._show_mode('analyse')),
        ])

        # OUT: everything that leaves the app.
        self.toolbar_flow.separator()
        io_g = self.toolbar_flow.group()
        # One Export menu, as Stereo has, instead of a Report menu and an
        # Excel menu competing for the same corner of the bar.
        self._menu_button(io_g, 'Export ▾', [
            ('Node force vectors…', self._show_node_vectors_report),
            ('Show me the working (rod calculations)…',
             self._show_rod_calculations_report),
            ('sep',),
            ('Export PDF report…', self._export_pdf_report),
            ('Report author and course…', self._ask_report_author),
            ('sep',),
            ('Export model and results to Excel…', self._export_excel),
            ('Import model from Excel…', self._import_excel),
        ], fg='#1a6bbd')

        # The camera verbs, right-aligned. They change nothing about the
        # structure, so they sit apart from everything that does.
        cam = tk.Frame(tb, bg='#ebebea')
        cam.pack(side='right', padx=(0, 6))
        tk.Button(cam, text='Reset view', relief='flat', bd=0, padx=8, pady=4,
                  font=('Helvetica', 11), bg='#ebebea',
                  command=self._reset_view).pack(side='right')
        fit_btn = tk.Button(cam, text='Fit', relief='flat', bd=0, padx=8,
                            pady=4, font=('Helvetica', 11), bg='#ebebea',
                            command=self._fit_view)
        fit_btn.pack(side='right')
        self._bind_widget_tooltip(fit_btn,
            'Zoom and centre so the whole model fits on screen. "Reset '
            'view" goes back to the ORIGIN, which stops being the model as '
            'soon as you build away from it.')
        # `cam` is packed to the right and is NOT a flow group, so the
        # wrap arithmetic cannot see it. Tell it, or the last group is
        # placed into space `cam` already holds and the two are drawn on
        # top of one another.
        self.toolbar_flow.reserve = cam

        # ── main area: the shell's work pane ─────────────────────────────────
        main = self.shell.work

        # Right panel FIRST, expanding canvas SECOND. Tk's pack hands each
        # slave a parcel in packing order, so the old order (canvas first,
        # expand=True) left the panel whatever the canvas did not want --
        # which below ~850 px was nothing at all: the entire right panel,
        # Analyze button included, was unmapped with no scrollbar and no
        # warning (measured 2026-09-05: 42 of 61 controls mapped at 1000 px,
        # 17 at 800 px). Cable Web's `_build_ui` carries the same note after
        # hitting this independently. ScrollPanel additionally scrolls
        # horizontally, so rows wider than the panel (the UDL rotation
        # slider, the paired buttons) stay reachable instead of being
        # clipped mid-widget as they were even at 1600 px.
        # Kept under its old name: `_sync()` is called on it from several
        # places that have nothing to do with layout, and the layout tests
        # reach for it by this name.
        self.panel_outer = self.shell.panel

        # truss zoom canvas
        self.zc = ZoomCanvas(main, bg='white', bd=1, relief='solid',
                             highlightthickness=0, cursor='crosshair')
        self.zc._on_zoom_changed = self._draw
        self.zc.pack(side='left', fill='both', expand=True)
        c = self.zc.canvas
        c.configure(width=INIT_CW, height=INIT_CH)
        c.bind('<ButtonPress-1>',   self._on_press)
        c.bind('<B1-Motion>',       self._on_drag_motion)
        c.bind('<ButtonRelease-1>', self._on_release)
        c.bind('<Escape>',     self._cancel_conic_pick)
        root.bind_all('<Escape>', self._guard_shortcut(self._cancel_conic_pick),
                      add='+')
        c.bind('<Delete>',     self._on_delete)
        c.bind('<BackSpace>',  self._on_delete)
        # Bound on the TAB, not just the canvas, so the shortcuts work
        # wherever focus happens to be -- except inside a text field, which
        # _typing_in_a_field excludes.
        #
        # Ctrl+X used to be REDO here. Every other application an
        # architecture student has ever used binds it to Cut, so pressing it
        # expecting to cut silently re-applied an edit they had just undone.
        # Redo is now on the two standard shortcuts and Ctrl+X is left alone.
        for seq, fn in (('<Control-z>', self._undo), ('<Control-Z>', self._undo),
                        ('<Control-y>', self._redo), ('<Control-Y>', self._redo),
                        ('<Control-Shift-Z>', self._redo),
                        ('<Control-c>', self._copy_selection),
                        ('<Control-C>', self._copy_selection),
                        ('<Control-v>', self._paste_clipboard),
                        ('<Control-V>', self._paste_clipboard),
                        ('<Control-s>', self._export_excel),
                        ('<Control-S>', self._export_excel)):
            root.bind_all(seq, self._guard_shortcut(fn), add='+')
        c.bind('<Motion>',     self._on_motion)
        c.bind('<Leave>',      self._on_leave)
        # Space-drag pans from any tool, the CAD convention, for the same
        # reason the Pan tool exists: no middle button on most trackpads.
        c.bind('<KeyPress-space>', self._space_pan_on)
        c.bind('<KeyRelease-space>', self._space_pan_off)
        c.focus_set()

        self._build_panel(self.panel_outer.interior)
        self._sync_guide_fields()
        self._refresh_guide_list()
        # Open at whatever the content needs, once; after that the width
        # belongs to whoever drags the sash.
        self.panel_outer.fit_to_content(max_width=460)
        self.shell.after_idle(
            lambda: self.shell.set_panel_width(self.panel_outer.base_width,
                                               remember=True))

        # ── diagram pane (shown after analysis, in the shell's lower pane) ───
        # It has its own draggable sash now, so a tall diagram band can be
        # dragged back instead of permanently costing the drawing 260 px --
        # on a 768 px laptop that left the model about 240 px tall, which is
        # the wrong way round for a teaching tool.
        self.diag_outer = self.shell.lower
        # Third bar, same FlowBar treatment as the toolbar and the CAD row:
        # below ~900 px the mode radios, the silhouette caption and the zoom
        # hint used to be drawn over one another in this one strip.
        diag_hdr = tk.Frame(self.diag_outer, bg='#f5f5f3')
        diag_hdr.pack(fill='x', pady=(0,2))
        self.diag_flow = FlowBar(diag_hdr, item_pad=1)
        title_g = self.diag_flow.group(bg='#f5f5f3')
        tk.Label(title_g, text='Diagrams', bg='#f5f5f3',
                 font=('Helvetica',9,'bold'), fg='#777')
        modes_g = self.diag_flow.group(bg='#f5f5f3')
        self.diagram_mode = tk.StringVar(value='truss')
        # Switching between modes resets the diagram canvas's zoom/pan
        # rather than reusing _draw_diagrams_only directly: each mode uses
        # a differently-shaped "world" layout (per-rod panel grid vs.
        # auto-fit structure silhouette), so carrying over a zoom/pan
        # tuned for one mode into another would show something oddly
        # scaled/off-screen. reset_view() already redraws afterward (it's
        # wired to diag_zc's _on_zoom_changed below).
        for text, value in (('Truss diagrams', 'truss'),
                            ('Vierendeel diagram', 'vierendeel'),
                            ('Compression/Tension fibers', 'fiber')):
            tk.Radiobutton(modes_g, text=text, variable=self.diagram_mode,
                           value=value, bg='#f5f5f3', font=('Helvetica',9),
                           command=lambda: self.diag_zc.reset_view())
        hint_g = self.diag_flow.group(bg='#f5f5f3')
        # The caption follows the mode. It used to describe the Vierendeel
        # silhouettes and stay on screen in all the other modes too.
        self.diag_hint_var = tk.StringVar(value='')
        tk.Label(hint_g, textvariable=self.diag_hint_var,
                 bg='#f5f5f3', fg='#999', font=('Helvetica',8))
        tk.Label(hint_g, text='🔍 scroll to zoom, middle-drag to pan',
                 bg='#f5f5f3', fg='#aaa', font=('Helvetica',8))
        self.diag_flow.start()
        # paned so diagram area can be resized
        self.diag_zc = ZoomCanvas(self.diag_outer, bg='#fafaf8',
                                  bd=1, relief='solid', highlightthickness=0)
        self.diag_zc._on_zoom_changed = self._draw_diagrams_only
        self.diag_zc.canvas.configure(height=INIT_DH)
        self.diag_zc.pack(fill='both', expand=True)

        # ── CAD precision panel ──────────────────────────────────────────────
        # Same FlowBar treatment as the toolbar: at 900 px this row used to
        # lose Pick ref and both Place node buttons off the right edge.
        # Packed into the work pane ABOVE the drawing, not into the tab, so
        # it sits beside the thing it is a precision aid for. Simple mode
        # hides it; see TrussLearnMixin._apply_mode.
        cad = tk.Frame(main, bg='#dde3ec', bd=1, relief='solid')
        self.cad_bar = cad
        cad.pack(fill='x', pady=(0,2), before=self.zc)
        self.cad_flow = FlowBar(cad, item_pad=1)

        # --- snap options ---
        snap_f = self.cad_flow.group(bg='#dde3ec')
        tk.Label(snap_f, text='SNAP:', bg='#dde3ec',
                 font=('Helvetica',9,'bold')).pack(side='left', padx=(0,4))
        tk.Checkbutton(snap_f, text='Grid', variable=self.snap_grid,
                       bg='#dde3ec', font=('Helvetica',9),
                       command=self._draw).pack(side='left')
        tk.Checkbutton(snap_f, text='Node', variable=self.snap_node,
                       bg='#dde3ec', font=('Helvetica',9),
                       command=self._draw).pack(side='left')
        tk.Checkbutton(snap_f, text='Curve', variable=self.snap_curve,
                       bg='#dde3ec', font=('Helvetica',9),
                       command=self._draw)
        tk.Checkbutton(snap_f, text='Angle', variable=self.snap_angle,
                       bg='#dde3ec', font=('Helvetica',9),
                       command=self._draw).pack(side='left')
        tk.Entry(snap_f, textvariable=self.snap_angle_deg, width=3,
                 font=('Helvetica',9)).pack(side='left', padx=(0,2))
        tk.Label(snap_f, text='°', bg='#dde3ec',
                 font=('Helvetica',9)).pack(side='left', padx=(0,8))

        self.cad_flow.separator(color='#aab')

        # --- coordinate entry ---
        coord_f = self.cad_flow.group(bg='#dde3ec')
        self.unit_label(tk.Label(coord_f, bg='#dde3ec',
                                  font=('Helvetica',9,'bold')),
                        lambda: f'COORD ({self.u("length")}):'
                        ).pack(side='left', padx=(0,4))
        tk.Label(coord_f, text='X', bg='#dde3ec',
                 font=('Helvetica',9)).pack(side='left')
        tk.Entry(coord_f, textvariable=self.cad_x, width=6,
                 font=('Helvetica',9)).pack(side='left', padx=(2,4))
        tk.Label(coord_f, text='Y', bg='#dde3ec',
                 font=('Helvetica',9)).pack(side='left')
        tk.Entry(coord_f, textvariable=self.cad_y, width=6,
                 font=('Helvetica',9)).pack(side='left', padx=(2,4))
        tk.Button(coord_f, text='Place node', relief='flat',
                  bg='#1a6bbd', fg='white', font=('Helvetica',9,'bold'),
                  command=self._cad_place_coord).pack(side='left', padx=(0,4))

        self.cad_flow.separator(color='#aab')

        # --- polar entry (compass) ---
        polar_f = self.cad_flow.group(bg='#dde3ec')
        tk.Label(polar_f, text='POLAR from node:', bg='#dde3ec',
                 font=('Helvetica',9,'bold')).pack(side='left', padx=(0,4))
        self.polar_ref_var = tk.StringVar(value='—')
        tk.Label(polar_f, textvariable=self.polar_ref_var,
                 bg='#dde3ec', fg='#1a6bbd',
                 font=('Helvetica',9,'bold')).pack(side='left', padx=(0,4))
        tk.Button(polar_f, text='Pick ref', relief='flat',
                  bg='#555', fg='white', font=('Helvetica',9),
                  command=self._cad_pick_ref).pack(side='left', padx=(0,4))
        self.unit_label(tk.Label(polar_f, bg='#dde3ec', font=('Helvetica',9)),
                        lambda: f'Dist ({self.u("length")})').pack(side='left')
        tk.Entry(polar_f, textvariable=self.cad_dist, width=6,
                 font=('Helvetica',9)).pack(side='left', padx=(2,4))
        tk.Label(polar_f, text='Angle (°)', bg='#dde3ec',
                 font=('Helvetica',9)).pack(side='left')
        tk.Entry(polar_f, textvariable=self.cad_angle, width=6,
                 font=('Helvetica',9)).pack(side='left', padx=(2,4))
        tk.Button(polar_f, text='Place node', relief='flat',
                  bg='#1a6bbd', fg='white', font=('Helvetica',9,'bold'),
                  command=self._cad_place_polar).pack(side='left', padx=(0,4))

        self.cad_flow.separator(color='#aab')

        # --- ruler toggle ---
        ruler_f = self.cad_flow.group(bg='#dde3ec')
        tk.Checkbutton(ruler_f, text='📏 Ruler', variable=self.ruler_active,
                       bg='#dde3ec', font=('Helvetica',9,'bold'),
                       command=self._ruler_toggle).pack(side='left')
        self.ruler_label = tk.Label(ruler_f, text='', bg='#dde3ec',
                                     fg='#c0392b', font=('Helvetica',9,'bold'))
        self.ruler_label.pack(side='left', padx=4)

        # --- live cursor readout ---
        self.cursor_var = tk.StringVar(value='x=0.00  y=0.00 m')
        cursor_f = self.cad_flow.group(bg='#dde3ec')
        tk.Label(cursor_f, textvariable=self.cursor_var, bg='#dde3ec',
                 font=('Courier',9), fg='#333')

        # polar reference node index
        self._polar_ref_node = None
        self._picking_ref    = False

        # ── status bar ────────────────────────────────────────────────────────
        self.status_var = tk.StringVar(value='Select "Node" and click the canvas to start.')
        self.status_bar = tk.Label(root, textvariable=self.status_var, anchor='w',
                 bg='#ebebea', font=('Helvetica',10),
                 relief='flat', padx=8, pady=3)
        self.status_bar.pack(side='bottom', fill='x', padx=6, pady=(4,6))

        # Start the two flow bars only now that every group exists, and give
        # the right panel its width from the same <Configure> that drives
        # them, so panel width and toolbar wrapping never disagree about how
        # wide the window currently is.
        self.toolbar_flow.start()
        self.cad_flow.start()
        root.bind('<Configure>', self._on_root_configure, add='+')
        root.after_idle(lambda: self._on_root_configure(None))

        self._refresh_tool_buttons()
        self._refresh_undo_buttons()
        # These three pack themselves in a chain anchored on analyze_btn
        # (stability after it, the learn row after that, and so on), so
        # they go into the SAME frame it is in or every `after=` fails.
        analyse = self._mode_frames['analyse']
        self._init_learn(analyse)
        self._init_design(analyse)
        self._init_play(analyse, after=self._design_rows[-1])
        self.rail.select(self.DEFAULT_MODE)
        # The Selection box was BLANK on a fresh tab -- its "click a
        # node/rod" text is written by _show_sel, which until now first
        # ran on the first click, which is the one moment you did not
        # need telling.
        self._show_sel()

    # -- toolbar helpers ------------------------------------------------------
    def _menu_button(self, parent, text, items, fg='#333333'):
        """A toolbar button that drops a short menu.

        `items` entries are ('label', command), ('check', label, var,
        command) or ('sep',).
        """
        mb = tk.Menubutton(parent, text=text, relief='flat', bd=0,
                           padx=8, pady=4, font=('Helvetica', 11),
                           bg='#ebebea', fg=fg, activebackground='#dcdcda')
        menu = tk.Menu(mb, tearoff=0, font=('Helvetica', 10))
        mb.configure(menu=menu)
        for item in items:
            if item[0] == 'sep':
                menu.add_separator()
            elif item[0] == 'check':
                _, label, var, cmd = item
                menu.add_checkbutton(label=label, variable=var, command=cmd)
            else:
                label, cmd = item
                menu.add_command(label=label, command=cmd)
        return mb

    def _refresh_undo_buttons(self):
        """Grey the arrows when there is nothing behind or ahead, and put
        the label of what they would do in their tooltip."""
        for btn, stack, word, keys in (
                (getattr(self, 'undo_btn', None), self._undo_stack, 'Undo', 'Ctrl+Z'),
                (getattr(self, 'redo_btn', None), self._redo_stack, 'Redo',
                 'Ctrl+Y or Ctrl+Shift+Z')):
            if btn is None:
                continue
            try:
                if stack:
                    label = stack[-1][0]
                    btn.configure(state='normal', fg='#333333')
                    self._bind_widget_tooltip(
                        btn, f'{word}: {label}  ({keys})' if label
                        else f'{word}  ({keys})')
                else:
                    btn.configure(state='disabled', fg='#aaaaaa')
                    self._bind_widget_tooltip(btn, f'Nothing to {word.lower()}')
            except Exception:
                pass

    # -- pan and fit ----------------------------------------------------------
    def _space_pan_on(self, _event=None):
        if self._space_pan:
            return
        self._space_pan = True
        try:
            self.zc.canvas.configure(cursor='fleur')
        except Exception:
            pass

    def _space_pan_off(self, _event=None):
        self._space_pan = False
        try:
            self.zc.canvas.configure(
                cursor='fleur' if self.tool.get() == 'pan' else 'crosshair')
        except Exception:
            pass

    def _model_in_view(self, points=None, inset=(0, 0, 0, 0)):
        """True when every joint (or every one of `points`) is on the
        visible canvas, `inset` (left, top, right, bottom) pixels in from
        its edges -- or the canvas has no size yet, which says nothing
        either way."""
        c = self.zc.canvas
        W, H = c.winfo_width(), c.winfo_height()
        pts = self.nodes if points is None else points
        if W < 50 or H < 50 or not pts:
            return True
        l, t, r, b = inset
        for nx, ny in pts:
            sx, sy = self.zc.w2s(nx, ny)
            if not (l <= sx <= W - r and t <= sy <= H - b):
                return False
        return True

    def _deformed_points(self):
        """Where the joints are drawn in the deformed shape, at the
        magnification on screen (the same arithmetic as _draw)."""
        if not self.results or not self.show_deform.get():
            return []
        k = PX_PER_M * self.def_scale.get() / 1000.0
        return [(nx + r['ux'] * k, ny + r['uy'] * k)
                for (nx, ny), r in zip(self.nodes, self.results['node_res'])]

    def _fit_to_results(self):
        """After ▶ Analyze: if the structure or its deformed shape runs
        out of the view, fit the view to both. A long span's deflected
        shape, magnified, hangs well below the structure, and the
        diagram pane opening underneath shrinks the canvas at the same
        moment -- the bridge's sagging chord ended under the legend.
        Nothing moves when everything is already in view."""
        try:
            self.root.update_idletasks()    # the canvas at its new size
        except tk.TclError:
            return False
        pts = list(self.nodes) + self._deformed_points()
        # Clear of the force key along the bottom edge, too.
        if self._model_in_view(pts, inset=(12, 12, 12, 36)):
            return False
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        pad = 1.2 * PX_PER_M
        x0, y0, x1, y1 = min(xs) - pad, min(ys) - pad, max(xs) + pad, \
            max(ys) + pad
        c, z = self.zc.canvas, self.zc.zoom
        W, H = c.winfo_width(), c.winfo_height()
        top, bottom = 12, H - 36
        if (x1 - x0) * z <= W - 24 and (y1 - y0) * z <= bottom - top:
            # It fits at the zoom you chose: bring it into view without
            # zooming. A small truss was zoomed IN to fill the canvas.
            self.zc.pan_x = (W / 2.0) / z - (x0 + x1) / 2.0
            self.zc.pan_y = ((top + bottom) / 2.0) / z - (y0 + y1) / 2.0
        else:
            self.zc.fit_to_bbox(x0, y0, x1, y1, margin=46)
        self._draw()
        return True

    def _fit_view(self):
        """Zoom and centre on everything there is -- structure first, guides
        too when there is no structure yet.

        `reset_view` goes to the ORIGIN at 1:1, which stops being the model
        the moment you array nodes onto a guide at x = 60 m. Without a Fit
        the structure simply leaves the screen, and on a trackpad with no
        middle button there was no pan to bring it back either.
        """
        xs, ys = [], []
        for (nx, ny) in self.nodes:
            xs.append(nx); ys.append(ny)
        if not xs:
            for gd in self.guides:
                for (px, py) in (truss_guides.sample(gd) or []):
                    xs.append(px); ys.append(py)
        if not xs:
            self.zc.reset_view()
            self.status_var.set('Nothing to fit yet — place a joint first.')
            self._draw()
            return
        pad = 1.2 * PX_PER_M
        self.zc.fit_to_bbox(min(xs) - pad, min(ys) - pad,
                            max(xs) + pad, max(ys) + pad, margin=46)
        self._draw()
        self.status_var.set('View fitted to the model.')

    def _on_root_configure(self, _event=None):
        """Let the panel yield on a narrow window until the user drags the
        sash; see AppShell.auto_fit_panel. This used to call
        ScrollPanel.apply_responsive_width on every <Configure>, which is
        the right answer only while nobody can set the width themselves."""
        try:
            self.shell.auto_fit_panel(self.root.winfo_width())
        except Exception:
            pass

    #: The rail down the left edge, in the order the work is done.
    #: Modelled on the Stereo tab (see common.ModeRail): you are always
    #: doing exactly one thing, and only that thing's controls belong on
    #: screen. The alternative -- which this tab had -- is eleven sections
    #: in one scroll, none louder than any other, and Analyze somewhere in
    #: the middle of them.
    MODES = (
        ('build',   '▦', 'Build',   'guides and arrays to build onto'),
        ('support', '△', 'Support', 'where the truss stands'),
        ('load',    '↓', 'Load',    'what it carries'),
        ('section', '▤', 'Section', 'what it is made of, and how it is joined'),
        ('analyse', '◑', 'Analyse', 'solve it, and watch it work'),
        ('results', 'Σ', 'Results', 'what came out'),
    )
    DEFAULT_MODE = 'analyse'

    #: Which mode each tool belongs to, so picking the Load tool takes you
    #: to the load controls rather than leaving you to find them.
    TOOL_MODE = {'node': 'build', 'rod': 'build',
                 'support': 'support', 'load': 'load'}

    def _build_panel(self, panel):
        # ── the mode rail, and one frame per mode ────────────────────────────
        self.rail = ModeRail(self.shell.rail_host, self.MODES,
                             on_change=self._on_mode_change,
                             on_hint=self._on_mode_hint)
        self.rail.pack(side='left', fill='y')
        self.rail.bind_hotkeys(self.root.winfo_toplevel())

        self.mode_title = tk.StringVar(value='')
        tk.Label(panel, textvariable=self.mode_title, bg='#f0f0ee',
                 fg='#8a949c', anchor='w',
                 font=('Helvetica', 8, 'bold')).pack(fill='x', padx=10,
                                                     pady=(6, 0))

        self._mode_frames = {}
        for key, _glyph, _label, _tip in self.MODES:
            fr = tk.Frame(panel, bg='#f0f0ee')
            self._mode_frames[key] = fr
            self.rail.register(key, fr)
        m_build = self._mode_frames['build']
        m_support = self._mode_frames['support']
        m_load = self._mode_frames['load']
        m_section = self._mode_frames['section']
        m_analyse = self._mode_frames['analyse']
        m_results = self._mode_frames['results']

        # ── RUN + RESULTS, pinned at the top ─────────────────────────────────
        # This used to sit below material, selection, connection type, two
        # load editors, construction geometry, arrays, plates with its
        # gusset bolt grid, and rod families -- roughly 900 px of scrolling
        # in a 235 px column to reach the button that runs the analysis, and
        # more scrolling to see what it produced. For the audience this app
        # is for, that is the first thing they need and the last thing they
        # could find. TrussLearnMixin._init_learn packs the stability line
        # directly after it, which is where that belongs too.
        # ── every mode's own tools, always on screen ─────────────────────────
        #
        # WHAT WAS WRONG. The rail's modes held only the per-click editors
        # and the Advanced-only sections, so most of them were EMPTY:
        #
        #       Simple   Advanced
        #   Build   0        2      Node and Rod had no controls at all
        #   Support 0        0      empty in BOTH
        #   Load    0        2
        #   Results 0        0      until something was solved
        #
        # Picking the Node tool took you to a Build pane with nothing in
        # it. Reported 11-10-26 as "the support tools and the rod and node
        # tools do not appear in their respective tabs". A mode that can
        # be empty is a mode that cannot explain itself, so each one now
        # opens with a card naming its tools -- as buttons that pick them
        # -- and saying in one line what to do with them. The per-click
        # editors still appear underneath when a joint is picked.
        self.mode_tool_btns = {}
        self._build_mode_card(
            m_build, 'Draw the truss',
            (('node', 'Node', 'Place a joint. Click the canvas; it snaps '
                              'to the grid.'),
             ('rod', 'Rod', 'Join two joints with a member. Click one, '
                            'then the other.')),
            'Joints first, then members between them. Everything else — '
            'supports, loads, sections — hangs off what you draw here.',
            extra=self._build_card_extra)
        self._build_mode_card(
            m_support, 'Hold it down',
            (('support', 'Support', 'Click a joint, then Apply support.'),),
            'Pick the kind of support here, then click the joints it goes '
            'on. A plane truss needs at least three restraints, or it is '
            'a mechanism.')
        self._build_mode_card(
            m_load, 'What it carries',
            (('load', 'Load', 'Click a joint, then set Fx / Fy.'),),
            'Click a joint to put a force on it. Span loads and point '
            'loads along a member are under Advanced tools.')

        self.analyze_btn = tk.Button(
            m_analyse, text='▶  Analyze structure', bg='#9e9e9e', fg='white',
            activebackground='#15559a', activeforeground='white',
            font=('Helvetica', 11, 'bold'), relief='flat', pady=6,
            command=self._run_analysis)
        self.analyze_btn.pack(fill='x', padx=8, pady=(8, 2))

        self.res_var = tk.StringVar(value='')
        tk.Label(m_analyse, textvariable=self.res_var, bg='#f0f0ee',
                 font=('Helvetica', 10), justify='left',
                 wraplength=PANEL_W - 20).pack(fill='x', padx=12, pady=2)

        # ── what to show on the drawing ──────────────────────────────────────
        # The old `Display ▾` menu, opened out. Six switches you could
        # only see one at a time, three rows away from the result they
        # describe, are six switches in front of the result instead -- and
        # the deflection scale sits beside the switch it magnifies rather
        # than beside a menu that no longer mentions it.
        #
        # `_init_learn` and `_init_design` pack their own two display
        # switches (Hide zero-force rods, Colour by utilisation) in here
        # too, so every "what is drawn" control is in one box.
        self.show_frame = tk.LabelFrame(
            m_analyse, text='What to show', bg='#f0f0ee',
            font=('Helvetica', 10, 'bold'), padx=6, pady=2)
        self.show_frame.pack(fill='x', padx=8, pady=(6, 4))
        for text, var, cmd, tip in (
                ('Force on each member', self.show_force_labels, self._draw,
                 'The axial force N written along every rod.'),
                ('Letter the joints (A, B, C…)', self.letter_joints,
                 self._draw,
                 'Joints get letters and members get numbers, so "2" next '
                 'to "2" stops being two different things.'),
                ('Trace where one load goes', self.show_load_path,
                 self._toggle_load_path,
                 'Pick a loaded joint and watch its own share of the '
                 'structure light up, member by member.'),
                ('○ Inflection points (M = 0)', self.show_contraflexure,
                 self._draw,
                 'Where the bending moment crosses zero on a rigid rod.'),
                ('Moment at rigid joints', self.show_node_moments,
                 self._draw,
                 'The moment each rigid rod hands its joint.')):
            cb = tk.Checkbutton(self.show_frame, text=text, variable=var,
                                bg='#f0f0ee', font=('Helvetica', 9),
                                anchor='w', command=cmd)
            cb.pack(fill='x')
            self._bind_widget_tooltip(cb, tip)
            if var is self.show_load_path:
                self._lp_check = cb
        self._build_load_path_chooser()
        # Deformed shape keeps its magnification next to it: the number is
        # meaningless without the switch and the switch is hard to read
        # without the number.
        self.def_row = tk.Frame(self.show_frame, bg='#f0f0ee')
        self.def_row.pack(fill='x')
        dcb = tk.Checkbutton(self.def_row, text='Deformed shape',
                             variable=self.show_deform, bg='#f0f0ee',
                             font=('Helvetica', 9), command=self._draw)
        dcb.pack(side='left')
        self._bind_widget_tooltip(dcb,
            'The deflected shape, drawn over the model and magnified by '
            'the × factor beside it -- real deflections are millimetres '
            'on a drawing metres across.')
        tk.Label(self.def_row, text='×', bg='#f0f0ee', fg='#777',
                 font=('Helvetica', 10)).pack(side='left', padx=(6, 0))
        tk.Scale(self.def_row, from_=1, to=300, orient='horizontal',
                 variable=self.def_scale, length=86, showvalue=True,
                 bg='#f0f0ee', bd=0, highlightthickness=0, relief='flat',
                 font=('Helvetica', 8),
                 command=lambda _: self._draw()).pack(side='left')

        # Results mode was empty until something was solved, which is
        # exactly when a beginner goes looking for it. The placeholder
        # says what is missing and hides itself once the boxes below have
        # something in them (`_show_results_placeholder`).
        self.res_placeholder = tk.Label(
            m_results, bg='#f0f0ee', fg='#666', font=('Helvetica', 9),
            justify='left', anchor='w', wraplength=PANEL_W - 30,
            text='Nothing solved yet.\n\nPress ▶ Analyze — on the toolbar, '
                 'or at the top of Analyse — and the rod forces, the '
                 'support reactions and the plate check appear here.')
        self.res_placeholder.pack(fill='x', padx=12, pady=(10, 4))

        self.rod_res_frame = tk.LabelFrame(m_results, text='Rod forces', bg='#f0f0ee',
                                           font=('Helvetica',10,'bold'), padx=4, pady=4)
        self.rod_res_text = tk.Text(self.rod_res_frame, width=22, height=7,
                                    relief='flat', bg='#f0f0ee',
                                    font=('Courier',9), state='disabled')
        self.rod_res_text.pack(fill='both')

        self.rxn_frame = tk.LabelFrame(m_results, text='Support reactions', bg='#f0f0ee',
                                       font=('Helvetica',10,'bold'), padx=4, pady=4)
        self.rxn_text  = tk.Text(self.rxn_frame, width=22, height=5,
                                  relief='flat', bg='#f0f0ee',
                                  font=('Courier',9), state='disabled')
        self.rxn_text.pack(fill='both')

        # material
        # TITLE. It said "Assumed material (all rods)" and applied to NO
        # rods: mat_E / mat_A / mat_I are read at rod CREATION only, so
        # picking a section here with rods selected changed nothing while
        # the status bar announced the new A and I. Reported 11-10-26 as
        # "the array does not update properly and the information does not
        # change", and it was exactly that. Everything in this box now
        # reaches the rods -- the selected ones, or all of them -- and the
        # title says which.
        mf = tk.LabelFrame(m_section, text='Material and section', bg='#f0f0ee',
                           font=('Helvetica',10,'bold'), padx=6, pady=4)
        mf.pack(fill='x', padx=8, pady=(8,4))
        # Was a nine-line paragraph; the two facts a student needs fit in two.
        tk.Label(mf, text='E and A only let the solver run: the result is the '
                          'axial force N in each rod. I is used by rigid '
                          '(Vierendeel) rods only.',
                 bg='#f0f0ee', fg='#666', font=('Helvetica',8),
                 justify='left', wraplength=PANEL_W-55).grid(
                     row=0, column=0, columnspan=2, sticky='w', pady=(0,4))
        # Presets, because "E = 200" is not a thing an architecture student
        # knows and "steel" is. The boxes stay editable underneath: the
        # preset fills them, it does not replace them.
        tk.Label(mf, text='Material:', bg='#f0f0ee',
                 font=('Helvetica',10)).grid(row=1, column=0, sticky='w')
        self.mat_preset = tk.StringVar(value='')
        mat_box = ttk.Combobox(mf, textvariable=self.mat_preset, width=15,
                               state='readonly', font=('Helvetica', 9),
                               values=[n for n, _E in self.MATERIAL_PRESETS])
        mat_box.grid(row=1, column=1, sticky='e', padx=4)
        mat_box.bind('<<ComboboxSelected>>', self._apply_material_preset)
        self._bind_widget_tooltip(mat_box,
            'Fills E with a typical stiffness for that material. It changes '
            'how far the truss deflects, never the member forces of a '
            'pin-jointed one.')

        tk.Label(mf, text='Section:', bg='#f0f0ee',
                 font=('Helvetica',10)).grid(row=2, column=0, sticky='w')
        self.sec_preset = tk.StringVar(value='')
        sec_box = ttk.Combobox(mf, textvariable=self.sec_preset, width=15,
                               state='readonly', font=('Helvetica', 9),
                               values=list(self.SECTION_PRESETS))
        sec_box.grid(row=2, column=1, sticky='e', padx=4)
        sec_box.bind('<<ComboboxSelected>>', self._apply_section_preset)
        self._bind_widget_tooltip(sec_box,
            'Fills A and I with the catalogue values for that rolled '
            'section (IPE, strong axis).')

        self.unit_label(tk.Label(mf, bg='#f0f0ee', font=('Helvetica',10)),
                        lambda: f'E ({self.u("modulus")}):'
                        ).grid(row=3,column=0,sticky='w')
        self.mat_E = self.unit_var(tk.DoubleVar(value=200.0), 'modulus')
        tk.Entry(mf, textvariable=self.mat_E, width=8,
                 font=('Helvetica',10)).grid(row=3,column=1,sticky='e',padx=4)
        self.unit_label(tk.Label(mf, bg='#f0f0ee', font=('Helvetica',10)),
                        lambda: f'A ({self.u("area")}):'
                        ).grid(row=4,column=0,sticky='w')
        self.mat_A = self.unit_var(tk.DoubleVar(value=10.0), 'area')
        tk.Entry(mf, textvariable=self.mat_A, width=8,
                 font=('Helvetica',10)).grid(row=4,column=1,sticky='e',padx=4)
        self.unit_label(tk.Label(mf, bg='#f0f0ee', font=('Helvetica',10)),
                        lambda: f'I ({self.u("inertia")}, rigid only):'
                        ).grid(row=5,column=0,sticky='w')
        self.mat_I = self.unit_var(tk.DoubleVar(value=8000.0), 'inertia')
        tk.Entry(mf, textvariable=self.mat_I, width=8,
                 font=('Helvetica',10)).grid(row=5,column=1,sticky='e',padx=4)
        # Hand-typed E, A and I need a way onto the rods that already
        # exist. A button and not a <FocusOut>: clicking into a field and
        # out again must not quietly rewrite whatever happens to be
        # selected at that moment.
        self.mat_apply_btn = tk.Button(
            mf, text='Apply E, A, I to all rods', bg='#1a6bbd', fg='white',
            font=('Helvetica', 9, 'bold'), relief='flat',
            command=self._apply_material_to_rods)
        self.mat_apply_btn.grid(row=6, column=0, columnspan=2, sticky='ew',
                                pady=(6, 2))
        self._bind_widget_tooltip(self.mat_apply_btn,
            'Writes the three boxes above onto the rods -- the selected '
            'ones, or every rod when nothing is selected. They are also '
            'what a NEW rod is drawn with.')
        self.mat_target_hint = tk.Label(
            mf, text='', bg='#f0f0ee', fg='#666', font=('Helvetica', 8),
            justify='left', anchor='w', wraplength=PANEL_W-55)
        self.mat_target_hint.grid(row=7, column=0, columnspan=2, sticky='w')

        # load editor
        self.load_frame = tk.LabelFrame(m_load, text='Load on node —', bg='#f0f0ee',
                                        font=('Helvetica',10,'bold'), padx=6, pady=4)
        self.unit_label(tk.Label(self.load_frame, bg='#f0f0ee', font=('Helvetica',10)),
                        lambda: f'Fx ({self.u("force")}, →+):'
                        ).grid(row=0,column=0,sticky='w')
        self.led_fx = self.unit_var(tk.DoubleVar(value=0.0), 'force')
        tk.Entry(self.load_frame, textvariable=self.led_fx, width=8,
                 font=('Helvetica',10)).grid(row=0,column=1,padx=4)
        self.unit_label(tk.Label(self.load_frame, bg='#f0f0ee', font=('Helvetica',10)),
                        lambda: f'Fy ({self.u("force")}, ↓+):'
                        ).grid(row=1,column=0,sticky='w')
        self.led_fy = self.unit_var(tk.DoubleVar(value=10.0), 'force')
        tk.Entry(self.load_frame, textvariable=self.led_fy, width=8,
                 font=('Helvetica',10)).grid(row=1,column=1,padx=4)
        tk.Button(self.load_frame, text='Apply load', bg='#1a6bbd', fg='white',
                  font=('Helvetica',10,'bold'), relief='flat',
                  command=self._apply_load).grid(row=2,column=0,columnspan=2,
                                                  sticky='ew',pady=(6,2))
        tk.Button(self.load_frame, text='Remove load', relief='flat',
                  font=('Helvetica',10),
                  command=self._remove_load).grid(row=3,column=0,columnspan=2,
                                                   sticky='ew',pady=2)

        # support editor
        self.sup_frame = tk.LabelFrame(m_support, text='Support on node —', bg='#f0f0ee',
                                       font=('Helvetica',10,'bold'), padx=6, pady=4)
        # Four SYMBOLS, not four words. A support type has a universally
        # recognised drawing, the tab already draws all four
        # (`_draw_support`), and a student learns the symbol by picking it.
        # `sup_type` still holds 'pin' / 'rollerX' / ... -- every saved
        # model and workbook uses those keys.
        #
        # The picker sits in the MODE CARD, not in this editor: which kind
        # of support you are placing is a setting of the Support tool, and
        # this editor is `pack_forget`-ed until a joint is clicked -- which
        # is how Support mode came to be empty until you had already
        # guessed what to click.
        self.sup_type = tk.StringVar(value='pin')
        self.sup_btns = {}
        picker = tk.Frame(self._mode_cards['support'], bg='#f0f0ee')
        picker.pack(fill='x', pady=(2, 0))
        for col, key in enumerate(('pin', 'rollerX', 'rollerY', 'fixed')):
            cell = tk.Frame(picker, bg='#f0f0ee', bd=2, relief='flat')
            cell.grid(row=0, column=col, padx=2)
            cv = tk.Canvas(cell, width=46, height=40, bg='#f0f0ee',
                           highlightthickness=0, cursor='hand2')
            cv.pack()
            self._draw_support(cv, 23, 4, key, label=False)
            lb = tk.Label(cell, text=self.support_label(key), bg='#f0f0ee',
                          font=('Helvetica', 7), fg='#555', wraplength=56)
            lb.pack()
            for w in (cv, lb, cell):
                w.bind('<Button-1>', lambda _e, k=key: self._pick_support(k))
            self._bind_widget_tooltip(
                cv, self.support_label(key, short=False))
            self.sup_btns[key] = cell
        self._refresh_support_picker()
        tk.Button(self.sup_frame, text='Apply support', bg='#1a6bbd', fg='white',
                  font=('Helvetica',10,'bold'), relief='flat',
                  command=self._apply_support).grid(row=0,column=0,columnspan=2,
                                                     sticky='ew',pady=(2,2))
        tk.Button(self.sup_frame, text='Remove support', relief='flat',
                  font=('Helvetica',10),
                  command=self._remove_support).grid(row=1,column=0,columnspan=2,
                                                      sticky='ew',pady=2)

        # selection
        self.sel_frame = tk.LabelFrame(panel, text='Selection', bg='#f0f0ee',
                                       font=('Helvetica',10,'bold'), padx=6, pady=4)
        self.sel_frame.pack(side='bottom', fill='x', padx=8, pady=4)
        self.sel_text = tk.Text(self.sel_frame, width=22, height=12, relief='flat',
                                bg='#f0f0ee', font=('Helvetica',9), state='disabled')
        self.sel_text.pack(fill='x')

        # connection type (rigid = Vierendeel-style moment connection, vs
        # pin = classic truss bar) — bulk-applies to selected rods, so you
        # can drag a selection box over many members at once
        self.conn_frame = tk.LabelFrame(m_section, text='Connection type (selected rods)',
                                        bg='#f0f0ee', font=('Helvetica',10,'bold'),
                                        padx=6, pady=4)
        self.conn_frame.pack(fill='x', padx=8, pady=4)
        tk.Label(self.conn_frame,
                 text='Pin = classic truss bar (axial only). Rigid = moment '
                      'connection (N, V, M) — use this for Vierendeel-style '
                      'panels with no diagonals.',
                 bg='#f0f0ee', fg='#666', font=('Helvetica',8),
                 justify='left', wraplength=PANEL_W-55).pack(anchor='w', pady=(0,4))
        connbtn = tk.Frame(self.conn_frame, bg='#f0f0ee'); connbtn.pack(fill='x')
        tk.Button(connbtn, text='Set Rigid', bg='#1a6bbd', fg='white',
                  font=('Helvetica',9,'bold'), relief='flat',
                  command=lambda: self._set_connection_type('rigid')).pack(
                      side='left', fill='x', expand=True, padx=(0,2))
        tk.Button(connbtn, text='Set Pinned', relief='flat', font=('Helvetica',9),
                  command=lambda: self._set_connection_type('pin')).pack(
                      side='left', fill='x', expand=True, padx=(2,0))

        # uniformly distributed load along selected rods --
        # only meaningful on rigid rods, so applying one auto-converts the
        # selected rods to Rigid if they weren't already
        self.dload_frame = tk.LabelFrame(m_load, text='Distributed load (selected rods)',
                                         bg='#f0f0ee', font=('Helvetica',10,'bold'),
                                         padx=6, pady=4)
        self.dload_frame.pack(fill='x', padx=8, pady=4)
        tk.Label(self.dload_frame,
                 text='Positive load follows the orange arrows. '
                      'Requires "Rigid" — applying one auto-sets the '
                      'selected rods to Rigid.',
                 bg='#f0f0ee', fg='#666', font=('Helvetica',8),
                 justify='left', wraplength=PANEL_W-55).pack(anchor='w', pady=(0,4))
        dl_row = tk.Frame(self.dload_frame, bg='#f0f0ee'); dl_row.pack(fill='x')
        self.unit_label(tk.Label(dl_row, bg='#f0f0ee', font=('Helvetica',9)),
                        lambda: f'w ({self.u("line_load")}):').pack(side='left')
        self.udl_var = self.unit_var(tk.DoubleVar(value=10.0), 'line_load')
        tk.Entry(dl_row, textvariable=self.udl_var, width=7,
                 font=('Helvetica',9)).pack(side='left', padx=4)

        self.udl_rotation_var = tk.DoubleVar(value=0.0)
        # Label above, radios below: the three side by side needed ~250 px of
        # a 235 px panel, which is what clipped "Rotated" off the edge.
        tk.Label(self.dload_frame, text='Load direction:', bg='#f0f0ee',
                 font=('Helvetica',9,'bold')).pack(anchor='w', pady=(2,0))
        mode_row = tk.Frame(self.dload_frame, bg='#f0f0ee'); mode_row.pack(fill='x')
        tk.Radiobutton(mode_row, text='Perpendicular', variable=self.udl_rotation_var,
                       value=0.0, bg='#f0f0ee', font=('Helvetica',8),
                       command=self._sync_udl_angle).pack(side='left', padx=(4,0))
        tk.Radiobutton(mode_row, text='Rotated', variable=self.udl_rotation_var,
                       value=90.0, bg='#f0f0ee', font=('Helvetica',8),
                       command=self._sync_udl_angle).pack(side='left', padx=(2,0))

        # The angle control and its legend are on SEPARATE rows on purpose.
        # Together on one line they made this LabelFrame 463 px wide -- twice
        # the panel -- which was what pushed Analyze, Set Pinned, Clear UDL
        # and Clear point loads past the right edge at every window width.
        # ScrollPanel would now let you scroll to them, but needing to scroll
        # sideways to reach Analyze is not a fix.
        angle_row = tk.Frame(self.dload_frame, bg='#f0f0ee'); angle_row.pack(fill='x')
        tk.Label(angle_row, text='Rotation from ⟂ (°):', bg='#f0f0ee',
                 font=('Helvetica',9)).pack(side='left')
        self.udl_angle_entry = tk.Entry(angle_row, textvariable=self.udl_rotation_var, width=6,
                                        font=('Helvetica',9))
        self.udl_angle_entry.pack(side='left', padx=4)
        tk.Scale(self.dload_frame, from_=-180, to=180, resolution=1, orient='horizontal',
                 variable=self.udl_rotation_var, length=105, showvalue=False,
                 bg='#f0f0ee', bd=0, highlightthickness=0,
                 command=lambda _: self._draw()).pack(fill='x', padx=2)
        tk.Label(self.dload_frame, text='0° ⟂   +90° along A→B   -90° opposite',
                 bg='#f0f0ee', fg='#666', font=('Helvetica',7),
                 justify='left', wraplength=PANEL_W-40).pack(anchor='w')
        tk.Label(self.dload_frame,
                 text='Default: perpendicular to every rod. Rotate the load '
                      'direction to apply horizontal, vertical, or any '
                      'diagonal distributed load.',
                 bg='#f0f0ee', fg='#666', font=('Helvetica',8), justify='left',
                 wraplength=PANEL_W-55).pack(anchor='w', pady=(1,0))

        dl_btns = tk.Frame(self.dload_frame, bg='#f0f0ee'); dl_btns.pack(fill='x', pady=(4,0))
        tk.Button(dl_btns, text='Apply UDL', bg='#1a6bbd', fg='white',
                  font=('Helvetica',9,'bold'), relief='flat',
                  command=self._apply_udl).pack(side='left', fill='x', expand=True, padx=(0,2))
        tk.Button(dl_btns, text='Clear UDL', relief='flat', font=('Helvetica',9),
                  command=self._clear_udl).pack(side='left', fill='x', expand=True, padx=(2,0))

        # point load on selected rods
        self.pload_frame = tk.LabelFrame(m_load, text='Point load on selected rods',
                                          bg='#f0f0ee', font=('Helvetica',10,'bold'),
                                          padx=6, pady=4)
        self.pload_frame.pack(fill='x', padx=8, pady=4)
        # One field per row -- P and "% from A" side by side needed ~244 px
        # of a 235 px panel, so the position entry was clipped.
        pl1 = tk.Frame(self.pload_frame, bg='#f0f0ee'); pl1.pack(fill='x')
        self.unit_label(tk.Label(pl1, bg='#f0f0ee', font=('Helvetica',9)),
                        lambda: f'P ({self.u("force")}):').pack(side='left')
        self.pload_var = self.unit_var(tk.DoubleVar(value=10.0), 'force')
        tk.Entry(pl1, textvariable=self.pload_var, width=7,
                 font=('Helvetica',9)).pack(side='left', padx=4)
        pl1b = tk.Frame(self.pload_frame, bg='#f0f0ee'); pl1b.pack(fill='x', pady=(3,0))
        tk.Label(pl1b, text='% from A:', bg='#f0f0ee', font=('Helvetica',9)).pack(side='left')
        self.pload_pos_var = tk.DoubleVar(value=50.0)
        tk.Entry(pl1b, textvariable=self.pload_pos_var, width=6,
                 font=('Helvetica',9)).pack(side='left', padx=4)
        pl2 = tk.Frame(self.pload_frame, bg='#f0f0ee'); pl2.pack(fill='x', pady=(3,0))
        tk.Label(pl2, text='Angle (°):', bg='#f0f0ee', font=('Helvetica',9)).pack(side='left')
        self.pload_angle_var = tk.DoubleVar(value=90.0)
        tk.Entry(pl2, textvariable=self.pload_angle_var, width=7,
                 font=('Helvetica',9)).pack(side='left', padx=4)
        tk.Label(self.pload_frame, text='0° = right, 90° = down', bg='#f0f0ee',
                 fg='#666', font=('Helvetica',8)).pack(anchor='w')
        plbtn = tk.Frame(self.pload_frame, bg='#f0f0ee'); plbtn.pack(fill='x', pady=(4,0))
        tk.Button(plbtn, text='Add point load', bg='#1a6bbd', fg='white',
                  font=('Helvetica',9,'bold'), relief='flat',
                  command=self._apply_point_load).pack(side='left', fill='x', expand=True, padx=(0,2))
        tk.Button(plbtn, text='Clear point loads', relief='flat', font=('Helvetica',9),
                  command=self._clear_point_loads).pack(side='left', fill='x', expand=True, padx=(2,0))

        # construction geometry (guides) — drawing aids, never structure
        self.guide_frame = tk.LabelFrame(m_build, text='Construction geometry',
                                          bg='#f0f0ee', font=('Helvetica',10,'bold'),
                                          padx=6, pady=4)
        self.guide_frame.pack(fill='x', padx=8, pady=4)
        tk.Label(self.guide_frame,
                 text='Guides are drawing aids only: never analysed, never '
                      'members. Build onto them with the arrays below.',
                 bg='#f0f0ee', fg='#666', font=('Helvetica',8),
                 justify='left', wraplength=PANEL_W-55).pack(anchor='w', pady=(0,4))

        # Registry of the per-kind field rows. Declared before any row is
        # built, because the fitted-family rows below register into it too.
        self._guide_rows = {}
        self.guide_kind = tk.StringVar(value='func')
        gk = tk.Frame(self.guide_frame, bg='#f0f0ee'); gk.pack(fill='x')
        for lbl, val in (('y=f(x)','func'), ('Line','line'), ('Arc','circle')):
            tk.Radiobutton(gk, text=lbl, variable=self.guide_kind, value=val,
                           bg='#f0f0ee', font=('Helvetica',8),
                           command=self._sync_guide_fields).pack(side='left')
        gk2 = tk.Frame(self.guide_frame, bg='#f0f0ee'); gk2.pack(fill='x')
        for lbl, val in (('Fitted', 'fit'), ('5-pt conic', 'conic5')):
            tk.Radiobutton(gk2, text=lbl, variable=self.guide_kind, value=val,
                           bg='#f0f0ee', font=('Helvetica',8),
                           command=self._sync_guide_fields).pack(side='left')

        # A FITTED guide is defined by what it must satisfy, not by an
        # equation: through two points, with a rise / radius / length. The
        # constraints are what gets stored, so dragging an end point re-solves
        # the curve and keeps the property that was asked for.
        self.fit_family = tk.StringVar(value='parabola')
        self.fit_by = tk.StringVar(value='rise')
        self.fit_value = tk.DoubleVar(value=4.0)
        ff = tk.Frame(self.guide_frame, bg='#f0f0ee')
        tk.Label(ff, text='curve', bg='#f0f0ee', font=('Helvetica',8),
                 width=11, anchor='w').pack(side='left')
        fam_combo = ttk.Combobox(ff, textvariable=self.fit_family, width=12,
                                  state='readonly', font=('Helvetica',8),
                                  values=list(truss_guides.FIT_FAMILIES))
        fam_combo.pack(side='left')
        fam_combo.bind('<<ComboboxSelected>>', lambda e: self._sync_fit_by())
        self._guide_rows['fit_family'] = ff
        fb = tk.Frame(self.guide_frame, bg='#f0f0ee')
        tk.Label(fb, text='set by', bg='#f0f0ee', font=('Helvetica',8),
                 width=11, anchor='w').pack(side='left')
        self.fit_by_combo = ttk.Combobox(fb, textvariable=self.fit_by, width=8,
                                          state='readonly', font=('Helvetica',8))
        self.fit_by_combo.pack(side='left')
        tk.Entry(fb, textvariable=self.fit_value, width=7,
                 font=('Helvetica',8)).pack(side='left', padx=(3,0))
        self._guide_rows['fit_by'] = fb
        tk.Label(self.guide_frame,
                 text='Two points plus one property. A semi-ellipse is the '
                      'arch form (centre on the chord); a general ellipse or '
                      'hyperbola needs the 5-point conic instead.',
                 bg='#f0f0ee', fg='#666', font=('Helvetica',7),
                 justify='left', wraplength=PANEL_W-55).pack(anchor='w')

        cn = tk.Frame(self.guide_frame, bg='#f0f0ee')
        self.conic_pts = []
        self.conic_status = tk.StringVar(value='0 of 5 points picked')
        tk.Label(cn, textvariable=self.conic_status, bg='#f0f0ee',
                 fg='#1a6bbd', font=('Helvetica',8)).pack(side='left')
        tk.Button(cn, text='Pick 5', relief='flat', font=('Helvetica',8),
                  command=self._start_conic_pick).pack(side='left', padx=4)
        self._guide_rows['conic'] = cn

        self.guide_expr   = tk.StringVar(value='4*f*x*(L-x)/L^2')
        self.guide_params = tk.StringVar(value='L=20, f=4')
        self.guide_x0 = tk.DoubleVar(value=0.0)
        self.guide_y0 = tk.DoubleVar(value=0.0)
        self.guide_x1 = tk.DoubleVar(value=20.0)
        self.guide_y1 = tk.DoubleVar(value=0.0)
        self.guide_r  = tk.DoubleVar(value=5.0)
        self.guide_a0 = tk.DoubleVar(value=0.0)
        self.guide_a1 = tk.DoubleVar(value=180.0)

        gg = tk.Frame(self.guide_frame, bg='#f0f0ee'); gg.pack(fill='x', pady=(3,0))
        def grow(key, label, var, width=13):
            r = tk.Frame(gg, bg='#f0f0ee')
            tk.Label(r, text=label, bg='#f0f0ee', font=('Helvetica',8),
                     width=11, anchor='w').pack(side='left')
            tk.Entry(r, textvariable=var, width=width,
                     font=('Helvetica',8)).pack(side='left')
            self._guide_rows[key] = r
            return r
        grow('expr',   'y =',        self.guide_expr)
        grow('params', 'where',      self.guide_params)
        # Registered as length so the boxes follow the selector; the y=f(x)
        # expression above them does not, since it is a formula the user wrote
        # and re-reading it in another convention would change what it means.
        for key, stem, var in (('x0', 'x₀ / cx', self.guide_x0),
                                ('y0', 'y₀ / cy', self.guide_y0),
                                ('x1', 'x₁', self.guide_x1),
                                ('y1', 'y₁', self.guide_y1),
                                ('r', 'radius', self.guide_r)):
            self.unit_label(
                grow(key, stem, var, 8).winfo_children()[0],
                (lambda t=stem: f'{t} ({self.u("length")})'))
            self.unit_var(var, 'length')
        grow('a0',     'from (°)',    self.guide_a0, 8)
        grow('a1',     'to (°)',      self.guide_a1, 8)

        gb = tk.Frame(self.guide_frame, bg='#f0f0ee'); gb.pack(fill='x', pady=(4,0))
        tk.Button(gb, text='Add guide', bg='#1a6bbd', fg='white',
                  font=('Helvetica',9,'bold'), relief='flat',
                  command=self._add_guide).pack(side='left', fill='x', expand=True, padx=(0,2))
        tk.Button(gb, text='Delete', relief='flat', font=('Helvetica',9),
                  command=self._delete_guide).pack(side='left', fill='x', expand=True, padx=(2,0))
        rb = tk.Button(self.guide_frame, text='Re-array onto moved guide',
                       relief='flat', font=('Helvetica',9),
                       command=self._re_array)
        rb.pack(fill='x', pady=(2,0))
        self._bind_widget_tooltip(rb,
            'Moving a guide never moves structure on its own — nodes already '
            'arrayed onto it stay put. This re-runs that path array on the '
            'guide where it now is, keeping the same node count and spacing '
            'settings. It refuses if the count would change, so nothing is '
            'silently re-wired.')
        self.guide_list = tk.Listbox(self.guide_frame, height=3,
                                      font=('Helvetica',8), exportselection=False)
        self.guide_list.pack(fill='x', pady=(3,0))
        self.guide_list.bind('<<ListboxSelect>>', self._on_guide_list_select)
        self.show_guides = tk.BooleanVar(value=True)
        tk.Checkbutton(self.guide_frame, text='Show guides', variable=self.show_guides,
                       bg='#f0f0ee', font=('Helvetica',8),
                       command=self._draw).pack(anchor='w')

        # arrays
        self.array_frame = tk.LabelFrame(m_build, text='Arrays', bg='#f0f0ee',
                                          font=('Helvetica',10,'bold'),
                                          padx=6, pady=4)
        self.array_frame.pack(fill='x', padx=8, pady=4)

        tk.Label(self.array_frame, text='PATH — along a guide', bg='#f0f0ee',
                 font=('Helvetica',8,'bold')).pack(anchor='w')
        self.path_guide = tk.StringVar(value='')
        self.path_guide_combo = ttk.Combobox(self.array_frame, textvariable=self.path_guide,
                                              state='readonly', width=20,
                                              font=('Helvetica',8))
        self.path_guide_combo.pack(fill='x')
        self.path_mode = tk.StringVar(value='count')
        pm = tk.Frame(self.array_frame, bg='#f0f0ee'); pm.pack(fill='x', pady=(2,0))
        tk.Radiobutton(pm, text='count', variable=self.path_mode, value='count',
                       bg='#f0f0ee', font=('Helvetica',8)).pack(side='left')
        tk.Radiobutton(pm, text='spacing', variable=self.path_mode, value='spacing',
                       bg='#f0f0ee', font=('Helvetica',8)).pack(side='left')
        self.path_n    = tk.IntVar(value=9)
        self.path_step = tk.DoubleVar(value=2.0)
        self.path_s0   = tk.DoubleVar(value=0.0)
        self.path_s1   = tk.DoubleVar(value=0.0)
        self.path_chain = tk.BooleanVar(value=True)
        for lbl, var in (('nodes', self.path_n), ('spacing', self.path_step),
                          ('start s', self.path_s0), ('end s', self.path_s1)):
            r = tk.Frame(self.array_frame, bg='#f0f0ee'); r.pack(fill='x')
            lb = tk.Label(r, bg='#f0f0ee', font=('Helvetica',8),
                          width=11, anchor='w')
            if var is self.path_n:
                lb.config(text=lbl)
            else:
                self.unit_label(lb, (lambda t=lbl: f'{t} ({self.u("length")})'))
                self.unit_var(var, 'length')
            lb.pack(side='left')
            tk.Entry(r, textvariable=var, width=8, font=('Helvetica',8)).pack(side='left')
        tk.Label(self.array_frame, text='end s = 0 means the whole guide. '
                                        'Spacing is measured ALONG the curve.',
                 bg='#f0f0ee', fg='#666', font=('Helvetica',7),
                 justify='left', wraplength=PANEL_W-55).pack(anchor='w')
        tk.Checkbutton(self.array_frame, text='connect with rods',
                       variable=self.path_chain, bg='#f0f0ee',
                       font=('Helvetica',8)).pack(anchor='w')
        tk.Button(self.array_frame, text='Path array', bg='#1a6bbd', fg='white',
                  font=('Helvetica',9,'bold'), relief='flat',
                  command=self._array_path).pack(fill='x', pady=(2,4))

        tk.Label(self.array_frame, text='GRID — from the selection', bg='#f0f0ee',
                 font=('Helvetica',8,'bold')).pack(anchor='w')
        self.grid_nx = tk.IntVar(value=3); self.grid_ny = tk.IntVar(value=1)
        self.grid_dx = tk.DoubleVar(value=4.0); self.grid_dy = tk.DoubleVar(value=3.0)
        gr = tk.Frame(self.array_frame, bg='#f0f0ee'); gr.pack(fill='x')
        for lbl, var in (('nx', self.grid_nx), ('ny', self.grid_ny)):
            tk.Label(gr, text=lbl, bg='#f0f0ee', font=('Helvetica',8)).pack(side='left')
            tk.Entry(gr, textvariable=var, width=4, font=('Helvetica',8)).pack(side='left', padx=(1,5))
        gr2 = tk.Frame(self.array_frame, bg='#f0f0ee'); gr2.pack(fill='x')
        for lbl, var in (('dx', self.grid_dx), ('dy', self.grid_dy)):
            self.unit_label(tk.Label(gr2, bg='#f0f0ee', font=('Helvetica',8)),
                            (lambda t=lbl: f'{t} ({self.u("length")})')).pack(side='left')
            self.unit_var(var, 'length')
            tk.Entry(gr2, textvariable=var, width=6, font=('Helvetica',8)).pack(side='left', padx=(1,5))
        tk.Button(self.array_frame, text='Grid array', relief='flat',
                  font=('Helvetica',9), command=self._array_grid).pack(fill='x', pady=(2,4))

        tk.Label(self.array_frame, text='POLAR — from the selection', bg='#f0f0ee',
                 font=('Helvetica',8,'bold')).pack(anchor='w')
        self.polar_cx = tk.DoubleVar(value=0.0); self.polar_cy = tk.DoubleVar(value=0.0)
        self.polar_n  = tk.IntVar(value=6); self.polar_deg = tk.DoubleVar(value=360.0)
        self.polar_rot = tk.BooleanVar(value=True)
        pr = tk.Frame(self.array_frame, bg='#f0f0ee'); pr.pack(fill='x')
        for lbl, var in (('cx', self.polar_cx), ('cy', self.polar_cy)):
            self.unit_label(tk.Label(pr, bg='#f0f0ee', font=('Helvetica',8)),
                            (lambda t=lbl: f'{t} ({self.u("length")})')).pack(side='left')
            self.unit_var(var, 'length')
            tk.Entry(pr, textvariable=var, width=6, font=('Helvetica',8)).pack(side='left', padx=(1,5))
        pr2 = tk.Frame(self.array_frame, bg='#f0f0ee'); pr2.pack(fill='x')
        for lbl, var, w in (('count', self.polar_n, 4), ('sweep (°)', self.polar_deg, 6)):
            tk.Label(pr2, text=lbl, bg='#f0f0ee', font=('Helvetica',8)).pack(side='left')
            tk.Entry(pr2, textvariable=var, width=w, font=('Helvetica',8)).pack(side='left', padx=(1,5))
        tk.Checkbutton(self.array_frame, text='rotate copies', variable=self.polar_rot,
                       bg='#f0f0ee', font=('Helvetica',8)).pack(anchor='w')
        tk.Button(self.array_frame, text='Polar array', relief='flat',
                  font=('Helvetica',9), command=self._array_polar).pack(fill='x', pady=(2,0))

        # plates — a gusset at a joint, or a shear panel filling a bay
        self.plate_frame = tk.LabelFrame(m_section, text='Plates', bg='#f0f0ee',
                                          font=('Helvetica',10,'bold'),
                                          padx=6, pady=4)
        self.plate_frame.pack(fill='x', padx=8, pady=4)
        tk.Label(self.plate_frame,
                 text='Shear panel = plate filling a bay, welded all round. It '
                      'stiffens the model. Gusset = plate at one joint; it is '
                      'checked but does NOT change any result.',
                 bg='#f0f0ee', fg='#666', font=('Helvetica',8),
                 justify='left', wraplength=PANEL_W-55).pack(anchor='w', pady=(0,4))

        pr1 = tk.Frame(self.plate_frame, bg='#f0f0ee'); pr1.pack(fill='x')
        self.unit_label(tk.Label(pr1, bg='#f0f0ee', font=('Helvetica',9)),
                        lambda: f't ({self.u("detail_length")}):').pack(side='left')
        self.plate_t = self.unit_var(tk.DoubleVar(value=8.0), 'detail_length')
        tk.Entry(pr1, textvariable=self.plate_t, width=6,
                 font=('Helvetica',9)).pack(side='left', padx=4)
        pr2 = tk.Frame(self.plate_frame, bg='#f0f0ee'); pr2.pack(fill='x', pady=(3,0))
        self.unit_label(tk.Label(pr2, bg='#f0f0ee', font=('Helvetica',9)),
                        lambda: f'Fy ({self.u("stress")}):').pack(side='left')
        self.plate_fy = self.unit_var(
            tk.DoubleVar(value=truss_plates.DEFAULT_FY_MPA), 'stress')
        tk.Entry(pr2, textvariable=self.plate_fy, width=6,
                 font=('Helvetica',9)).pack(side='left', padx=4)
        pr3 = tk.Frame(self.plate_frame, bg='#f0f0ee'); pr3.pack(fill='x', pady=(3,0))
        self.unit_label(tk.Label(pr3, bg='#f0f0ee', font=('Helvetica',9)),
                        lambda: f'Fexx ({self.u("stress")}):').pack(side='left')
        self.plate_fexx = self.unit_var(
            tk.DoubleVar(value=truss_plates.DEFAULT_FEXX_MPA), 'stress')
        tk.Entry(pr3, textvariable=self.plate_fexx, width=6,
                 font=('Helvetica',9)).pack(side='left', padx=4)
        pr4 = tk.Frame(self.plate_frame, bg='#f0f0ee'); pr4.pack(fill='x', pady=(3,0))
        self.unit_label(tk.Label(pr4, bg='#f0f0ee', font=('Helvetica',9)),
                        lambda: f'G ({self.u("modulus")}):').pack(side='left')
        self.plate_G = self.unit_var(tk.DoubleVar(value=80.0), 'modulus')
        tk.Entry(pr4, textvariable=self.plate_G, width=6,
                 font=('Helvetica',9)).pack(side='left', padx=4)
        tk.Label(self.plate_frame,
                 text='Defaults: F-24 steel (Fy 235), E70 electrode (Fexx 480).',
                 bg='#f0f0ee', fg='#666', font=('Helvetica',7),
                 justify='left', wraplength=PANEL_W-55).pack(anchor='w', pady=(2,0))


        # Gusset connection detail. Block shear and Thornton buckling cannot
        # be checked without it -- that is exactly why both used to be
        # disclaimed rather than computed. Only the bolt fields below depend
        # on 'bolted'; a welded gusset ignores them.
        cd = tk.LabelFrame(self.plate_frame, text='Gusset connection',
                            bg='#f0f0ee', font=('Helvetica',8,'bold'),
                            padx=4, pady=3)
        cd.pack(fill='x', pady=(4,0))
        self.plate_conn = tk.StringVar(value='welded')
        crow = tk.Frame(cd, bg='#f0f0ee'); crow.pack(fill='x')
        for lbl, val in (('Welded', 'welded'), ('Bolted', 'bolted')):
            tk.Radiobutton(crow, text=lbl, variable=self.plate_conn, value=val,
                           bg='#f0f0ee', font=('Helvetica',8)).pack(side='left')
        SL = 'detail_length'
        self.bolt_d     = self.unit_var(tk.DoubleVar(value=16.0), SL)
        self.bolt_rows  = tk.IntVar(value=2)
        self.bolt_cols  = tk.IntVar(value=2)
        self.bolt_pitch = self.unit_var(tk.DoubleVar(value=60.0), SL)
        self.bolt_gauge = self.unit_var(tk.DoubleVar(value=60.0), SL)
        self.bolt_end   = self.unit_var(tk.DoubleVar(value=40.0), SL)
        self.bolt_edge  = self.unit_var(tk.DoubleVar(value=35.0), SL)
        self.gusset_landing = self.unit_var(tk.DoubleVar(value=300.0), SL)
        grid = tk.Frame(cd, bg='#f0f0ee'); grid.pack(fill='x', pady=(2,0))
        for r, (lbl, var) in enumerate((
                ('bolt d', self.bolt_d),
                ('rows x cols', None),
                ('pitch', self.bolt_pitch),
                ('gauge', self.bolt_gauge),
                ('end', self.bolt_end),
                ('edge', self.bolt_edge),
                ('landing', self.gusset_landing))):
            lb = tk.Label(grid, bg='#f0f0ee', font=('Helvetica',8))
            if var is None:
                lb.config(text=lbl)
            else:
                self.unit_label(lb, (lambda t=lbl: f'{t} ({self.u("detail_length")})'))
            lb.grid(row=r, column=0, sticky='w')
            if var is None:
                rc = tk.Frame(grid, bg='#f0f0ee')
                rc.grid(row=r, column=1, sticky='w', padx=2)
                tk.Entry(rc, textvariable=self.bolt_rows, width=3,
                         font=('Helvetica',8)).pack(side='left')
                tk.Label(rc, text='x', bg='#f0f0ee',
                         font=('Helvetica',8)).pack(side='left')
                tk.Entry(rc, textvariable=self.bolt_cols, width=3,
                         font=('Helvetica',8)).pack(side='left')
            else:
                tk.Entry(grid, textvariable=var, width=6,
                         font=('Helvetica',8)).grid(row=r, column=1,
                                                     sticky='w', padx=2)
        tk.Label(cd, text='Landing = how far the member force is carried into '
                          'the plate. It sets the Whitmore width, the weld '
                          'length and the buckling length.',
                 bg='#f0f0ee', fg='#666', font=('Helvetica',7),
                 justify='left', wraplength=PANEL_W-55).pack(anchor='w', pady=(2,0))

        pbtn = tk.Frame(self.plate_frame, bg='#f0f0ee'); pbtn.pack(fill='x', pady=(4,0))
        add_pan = tk.Button(pbtn, text='Add shear panel', bg='#1a6bbd', fg='white',
                            font=('Helvetica',9,'bold'), relief='flat',
                            command=self._add_panel)
        add_pan.pack(fill='x')
        self._bind_widget_tooltip(add_pan,
            'Select the 3 or 4 rods that close a bay, then click this. The '
            'plate carries that bay’s shear as a membrane (constant shear '
            'flow q = G·t·γ), so the bay stiffens and member moments drop. '
            'It has no rotational stiffness and reports one τ for the whole '
            'panel — there is no stress field. Re-run Analyze afterwards.')
        add_gus = tk.Button(pbtn, text='Add gusset at node', relief='flat',
                            font=('Helvetica',9), command=self._add_gusset)
        add_gus.pack(fill='x', pady=(2,0))
        self._bind_widget_tooltip(add_gus,
            'Select one or more nodes, then click this. A gusset is checked '
            'against the forces AND moments the joint actually carries, but it '
            'never enters the stiffness matrix, so no analysis result changes. '
            'Block shear and gusset buckling are NOT checked — both need a '
            'bolt pattern this tab does not model.')
        tk.Button(pbtn, text='Remove plates on selection', relief='flat',
                  font=('Helvetica',9),
                  command=self._remove_plates).pack(fill='x', pady=(2,0))

        self.plate_res_frame = tk.LabelFrame(m_results, text='Plate checks', bg='#f0f0ee',
                                              font=('Helvetica',10,'bold'),
                                              padx=4, pady=4)
        self.plate_res_text = tk.Text(self.plate_res_frame, width=22, height=8,
                                       relief='flat', bg='#f0f0ee',
                                       font=('Courier',8), state='disabled')
        self.plate_res_text.pack(fill='both')

        # rod family / profile management
        self.family_frame = tk.LabelFrame(m_section, text='Rod family / profile', bg='#f0f0ee',
                                          font=('Helvetica',10,'bold'), padx=6, pady=4)
        self.family_frame.pack(fill='x', padx=8, pady=4)
        tk.Label(self.family_frame, text='Profile:', bg='#f0f0ee',
                 font=('Helvetica',10)).grid(row=0,column=0,sticky='w')
        self.family_combo = ttk.Combobox(self.family_frame, textvariable=self.active_profile,
                                         width=11, state='readonly', font=('Helvetica',10))
        self.family_combo.grid(row=0,column=1,padx=4)
        tk.Button(self.family_frame, text='Apply to selected rods', bg='#1a6bbd', fg='white',
                  font=('Helvetica',9,'bold'), relief='flat',
                  command=self._assign_profile_to_selection).grid(
                      row=1,column=0,columnspan=2,sticky='ew',pady=(6,2))
        tk.Button(self.family_frame, text='Select same family', relief='flat',
                  font=('Helvetica',9),
                  command=self._select_same_family).grid(
                      row=2,column=0,columnspan=2,sticky='ew',pady=2)
        tk.Button(self.family_frame, text='Manage profiles…', relief='flat',
                  font=('Helvetica',9),
                  command=self._open_profile_manager).grid(
                      row=3,column=0,columnspan=2,sticky='ew',pady=2)
        self._refresh_profile_combo()

        # legend
        lf = tk.Frame(panel, bg='#f0f0ee')
        lf.pack(side='bottom', fill='x', padx=8, pady=4)
        for col, lbl in [(CT,'Tension'),(CC,'Compression'),(CZ,'Zero/unanalysed'),
                          (CD,'Deformed'),(CR,'Reaction'),(CV,'Shear V'),(CM,'Moment M')]:
            row = tk.Frame(lf, bg='#f0f0ee')
            row.pack(anchor='w', pady=1)
            tk.Canvas(row, width=22, height=4, bg=col, bd=0,
                      highlightthickness=0).pack(side='left', padx=(0,4))
            tk.Label(row, text=lbl, bg='#f0f0ee',
                     font=('Helvetica',9)).pack(side='left')




    # ══════════════════════════════════════════════════════════════════════════
    #  Construction geometry (guides) and node arrays
    # ══════════════════════════════════════════════════════════════════════════
    #
    # A GUIDE is a drawing aid, never structure: it is not analysed, never
    # becomes a rod, and contributes nothing to the stiffness matrix. Lay a
    # parabola down, array nodes along it, connect them -- the guide stays as
    # a reference line you can leave on or switch off.
    #
    # Note the name. This tab already calls something else "ghost"
    # (`_compute_ghost`, the marker showing where the next node will land),
    # so these are GUIDES throughout, in the code and in the UI, to keep the
    # two from being confused.
    #
    # The geometry itself lives in truss_guides.py with no Tkinter in it, and
    # is verified there against closed forms (a line's length, R*theta for an
    # arc, and the analytic integral for a parabola). What is here is only the
    # UI and the model bookkeeping.

    def _guide_from_fields(self):
        """Build a guide record from the panel fields, or (None, reason)."""
        kind = self.guide_kind.get()
        try:
            if kind == 'func':
                params = {}
                raw = self.guide_params.get().strip()
                if raw:
                    for part in raw.replace(';', ',').split(','):
                        if not part.strip():
                            continue
                        k, v = part.split('=')
                        params[k.strip()] = float(v)
                gd = {'kind': 'func', 'expr': self.guide_expr.get(),
                      'x0': self.unit_value(self.guide_x0),
                      'x1': self.unit_value(self.guide_x1),
                      'params': params}
            elif kind == 'line':
                gd = {'kind': 'line',
                      'p0': (self.unit_value(self.guide_x0), self.unit_value(self.guide_y0)),
                      'p1': (self.unit_value(self.guide_x1), self.unit_value(self.guide_y1))}
            elif kind == 'fit':
                gd = {'kind': 'fit', 'family': self.fit_family.get(),
                      'p0': (self.unit_value(self.guide_x0), self.unit_value(self.guide_y0)),
                      'p1': (self.unit_value(self.guide_x1), self.unit_value(self.guide_y1)),
                      'by': self.fit_by.get(),
                      'value': float(self.fit_value.get()), 'flip': False}
            elif kind == 'conic5':
                if len(self.conic_pts) != 5:
                    return None, ('Pick five points first (%d so far).'
                                  % len(self.conic_pts))
                gd = {'kind': 'conic5', 'pts': list(self.conic_pts), 'branch': 0}
            else:
                gd = {'kind': 'circle',
                      'c': (self.unit_value(self.guide_x0), self.unit_value(self.guide_y0)),
                      'r': self.unit_value(self.guide_r),
                      'a0': float(self.guide_a0.get()),
                      'a1': float(self.guide_a1.get())}
        except (tk.TclError, ValueError) as ex:
            return None, 'Check the numbers: %s' % ex
        err = truss_guides.guide_error(gd)
        if err:
            return None, err
        return gd, None

    def _sync_guide_fields(self):
        """Show only the fields the chosen guide kind actually uses. All nine
        rows exist at all times; packing and unpacking them is what keeps the
        panel from listing radius and angles for a straight line."""
        wanted = {
            'func':   ('expr', 'params', 'x0', 'x1'),
            'line':   ('x0', 'y0', 'x1', 'y1'),
            'circle': ('x0', 'y0', 'r', 'a0', 'a1'),
            'fit':    ('fit_family', 'fit_by', 'x0', 'y0', 'x1', 'y1'),
            'conic5': ('conic',),
        }[self.guide_kind.get()]
        if self.guide_kind.get() == 'fit':
            self._sync_fit_by()
        for key, row in self._guide_rows.items():
            row.pack_forget()
        for key in wanted:
            self._guide_rows[key].pack(fill='x')
        if hasattr(self, 'panel_outer'):
            self.panel_outer._sync()

    def _add_guide(self):
        gd, why = self._guide_from_fields()
        if gd is None:
            messagebox.showwarning('Construction geometry', why)
            self.status_var.set(why)
            return
        self._push_undo('add guide')
        self.guides.append(gd)
        self._refresh_guide_list()
        self._draw()
        self.status_var.set('Guide added (%s), length %.3f m. It is a drawing '
                            'aid only — never analysed.'
                            % (gd['kind'], truss_guides.total_length(gd)))

    def _sync_fit_by(self):
        """Offer only the properties that actually pin down the chosen family.
        A parabola through two points is fixed by its rise; asking for its
        radius is not a harder question, it is a meaningless one."""
        allowed = truss_guides.FIT_BY.get(self.fit_family.get(), ('rise',))
        self.fit_by_combo['values'] = list(allowed)
        if self.fit_by.get() not in allowed:
            self.fit_by.set(allowed[0])

    def _start_conic_pick(self):
        """Enter the five-point pick. Clicks land on the canvas with the usual
        snaps, so a conic can be hung off existing nodes and grid points."""
        self.conic_pts = []
        self._picking_conic = True
        self.conic_status.set('0 of 5 points picked')
        self.status_var.set('Click five points for the conic. Esc cancels.')
        self._draw()

    def _conic_pick_click(self, wx, wy):
        """Consume one click of the five-point pick. Returns True while the
        pick is active, so the caller knows not to treat it as a normal
        click."""
        if not getattr(self, '_picking_conic', False):
            return False
        gx, gy = self._compute_ghost(wx, wy)
        self.conic_pts.append(self._world_to_metres(gx, gy))
        n = len(self.conic_pts)
        self.conic_status.set('%d of 5 points picked' % n)
        if n >= 5:
            self._picking_conic = False
            probe = {'kind': 'conic5', 'pts': list(self.conic_pts), 'branch': 0}
            why = truss_guides.guide_error(probe)
            if why:
                self.conic_pts = []
                self.conic_status.set('0 of 5 points picked')
                messagebox.showwarning('5-point conic', why)
                self.status_var.set(why)
            else:
                self.guide_kind.set('conic5')
                self._sync_guide_fields()
                self._add_guide()
                self.conic_pts = []
                self.conic_status.set('0 of 5 points picked')
        self._draw()
        return True

    def _cancel_conic_pick(self, _event=None):
        if getattr(self, '_picking_conic', False):
            self._picking_conic = False
            self.conic_pts = []
            self.conic_status.set('0 of 5 points picked')
            self.status_var.set('Five-point pick cancelled.')
            self._draw()

    def _on_guide_list_select(self, _event=None):
        """Picking a guide in the list selects it on the canvas too, so its
        handles appear where you can actually grab them."""
        sel = self.guide_list.curselection()
        self.sel_guide = sel[0] if sel else None
        self._draw()

    def _delete_guide(self):
        i = self.guide_list.curselection()
        if not i:
            self.status_var.set('Select a guide in the list first.')
            return
        self._push_undo('delete guide')
        gi = i[0]
        del self.guides[gi]
        # Guide indices shift down past the deleted one, exactly as node
        # indices do on _on_delete, so the array history has to be remapped
        # or a later Re-array would rewrite nodes from the wrong curve.
        self._array_history.pop(gi, None)
        self._array_history = {(k - 1 if k > gi else k): v
                                for k, v in self._array_history.items()}
        if self.sel_guide == gi:
            self.sel_guide = None
        elif self.sel_guide is not None and self.sel_guide > gi:
            self.sel_guide -= 1
        self._refresh_guide_list()
        self._draw()

    def _guide_label(self, i, gd):
        if gd['kind'] == 'func':
            return '%d  y=%s' % (i, gd.get('expr', '')[:18])
        if gd['kind'] == 'line':
            return '%d  line (%.1f,%.1f)-(%.1f,%.1f)' % (
                i, gd['p0'][0], gd['p0'][1], gd['p1'][0], gd['p1'][1])
        if gd['kind'] == 'fit':
            return '%d  %s %s=%g  (%.1f,%.1f)-(%.1f,%.1f)' % (
                i, gd.get('family', '?'), gd.get('by', '?'),
                gd.get('value', 0.0),
                gd['p0'][0], gd['p0'][1], gd['p1'][0], gd['p1'][1])
        if gd['kind'] == 'conic5':
            return '%d  conic: %s' % (i, truss_guides.conic_describe(gd))
        if gd['kind'] == 'ellipse':
            return '%d  ellipse a=%.2f b=%.2f @(%.1f,%.1f)' % (
                i, gd.get('a', 0.0), gd.get('b', 0.0), gd['c'][0], gd['c'][1])
        return '%d  arc r=%.2f @(%.1f,%.1f)' % (
            i, gd.get('r', 0.0), gd['c'][0], gd['c'][1])

    def _refresh_guide_list(self):
        self.guide_list.delete(0, 'end')
        for i, gd in enumerate(self.guides):
            self.guide_list.insert('end', self._guide_label(i, gd))
        vals = [self._guide_label(i, gd) for i, gd in enumerate(self.guides)]
        self.path_guide_combo['values'] = vals
        if vals and self.path_guide.get() not in vals:
            self.path_guide.set(vals[0])
        elif not vals:
            self.path_guide.set('')

    def _selected_guide(self):
        """The guide chosen in the path-array combobox, or None."""
        want = self.path_guide.get()
        for i, gd in enumerate(self.guides):
            if self._guide_label(i, gd) == want:
                return gd
        return self.guides[0] if self.guides else None

    def _draw_guides(self, c, w2s, z):
        """Guides, under everything structural. Drawn in a distinct dashed
        blue-grey so they never read as members: a guide that looks like a rod
        in a screenshot is worse than no guide."""
        if not self.show_guides.get():
            return
        for gd in self.guides:
            pts = truss_guides.sample(gd, 240)
            flat = []
            for p in pts:
                if p is None:
                    continue
                wx, wy = self._metres_to_world(p[0], p[1])
                sx, sy = w2s(wx, wy)
                flat += [sx, sy]
            if len(flat) >= 4:
                sel = (self.guides.index(gd) == self.sel_guide
                        if gd in self.guides else False)
                c.create_line(*flat,
                              fill='#e08a1e' if sel else '#8fa6c4',
                              width=2.0 if sel else 1.4, dash=(7, 4))
                c.create_text(flat[0], flat[1] - 8,
                               text=gd['kind'], fill='#8fa6c4',
                               font=('Helvetica', max(6, int(7 * z))),
                               anchor='sw')


    # ── selecting, moving and reshaping a guide ──────────────────────────────
    #
    # A guide is grabbed by the points that DEFINE it -- the two ends a fitted
    # arch springs from, the five points a conic passes through -- so dragging
    # one changes the thing that point actually means. Dragging the curve
    # itself, away from any handle, translates the whole guide.
    #
    # Nothing here moves structure. Nodes already arrayed onto a guide stay
    # exactly where they are when the guide moves; "Re-array" re-runs the
    # array deliberately. A construction line quietly dragging real geometry
    # with it is the kind of surprise that makes a model untrustworthy.

    HANDLE_PX = 5           # on-screen half-size of a handle square

    def _guide_hit_at(self, wx, wy):
        """(guide index, handle index or None) under the cursor, or (None, None).
        Handles win over the curve body, so a click near an end grabs that end
        rather than translating the whole guide."""
        if not self.show_guides.get() or not self.guides:
            return None, None
        mx, my = self._world_to_metres(wx, wy)
        tol_m = (14 / max(self.zc.zoom, 1e-6)) / PX_PER_M

        order = ([self.sel_guide] if self.sel_guide is not None else []) + \
                [i for i in range(len(self.guides)) if i != self.sel_guide]
        for gi in order:
            if not (0 <= gi < len(self.guides)):
                continue
            for hi, (_role, (hx, hy)) in enumerate(
                    truss_guides.guide_handles(self.guides[gi])):
                if math.hypot(hx - mx, hy - my) <= tol_m:
                    return gi, hi
        for gi in order:
            if 0 <= gi < len(self.guides) and truss_guides.guide_hit(
                    self.guides[gi], mx, my, tol_m):
                return gi, None
        return None, None

    def _begin_guide_drag(self, gi, hi, wx, wy):
        self.sel_guide = gi
        self._guide_drag = {'guide': gi, 'handle': hi,
                             'from': self._world_to_metres(wx, wy),
                             'orig': copy.deepcopy(self.guides[gi])}
        what = ('handle %d' % (hi + 1)) if hi is not None else 'the whole guide'
        self.status_var.set('Moving %s — release to drop, Ctrl+Z undoes.' % what)

    def _drag_guide_to(self, wx, wy):
        d = self._guide_drag
        if not d:
            return
        gx, gy = self._compute_ghost(wx, wy)
        mx, my = self._world_to_metres(gx, gy)
        if d['handle'] is None:
            dx = mx - d['from'][0]
            dy = my - d['from'][1]
            self.guides[d['guide']] = truss_guides.move_guide(d['orig'], dx, dy)
        else:
            self.guides[d['guide']] = truss_guides.set_handle(
                d['orig'], d['handle'], mx, my)
        self._draw()

    def _end_guide_drag(self):
        d = self._guide_drag
        self._guide_drag = None
        if not d:
            return
        moved = self.guides[d['guide']]
        if moved == d['orig']:
            self._draw()
            return
        # Push the BEFORE state and re-apply, so one Ctrl+Z returns the guide
        # to where the drag started rather than to a mid-drag position.
        self.guides[d['guide']] = d['orig']
        self._push_undo('move guide')
        self.guides[d['guide']] = moved
        self._refresh_guide_list()
        self._draw()
        n = self._nodes_arrayed_from(d['guide'])
        extra = ('  %d node(s) were arrayed from this guide and have NOT '
                 'moved — use Re-array if you want them to.' % n) if n else ''
        self.status_var.set('Guide moved.%s' % extra)

    def _nodes_arrayed_from(self, gi):
        rec = self._array_history.get(gi)
        return len(rec['nodes']) if rec else 0

    def _draw_guide_handles(self, c, w2s, z):
        """Handles on the selected guide only. Showing them on every guide at
        once turns a drawing full of references into a drawing full of dots."""
        # points picked so far in a five-point conic pick
        for k, (mx, my) in enumerate(getattr(self, 'conic_pts', []) or []):
            wx, wy = self._metres_to_world(mx, my)
            sx, sy = w2s(wx, wy)
            c.create_oval(sx - 5, sy - 5, sx + 5, sy + 5,
                          outline='#1a6bbd', fill='white', width=1.6)
            c.create_text(sx, sy - 11, text=str(k + 1), fill='#1a6bbd',
                          font=('Helvetica', 8, 'bold'))

        gi = self.sel_guide
        if gi is None or not (0 <= gi < len(self.guides)):
            return
        if not self.show_guides.get():
            return
        r = self.HANDLE_PX
        for role, (hx, hy) in truss_guides.guide_handles(self.guides[gi]):
            wx, wy = self._metres_to_world(hx, hy)
            sx, sy = w2s(wx, wy)
            fill = {'end': '#1a6bbd', 'shape': '#e08a1e'}.get(role, '#6a9b52')
            c.create_rectangle(sx - r, sy - r, sx + r, sy + r,
                               fill=fill, outline='white', width=1.2)

    # ── re-array ─────────────────────────────────────────────────────────────

    def _re_array(self):
        """Re-run the last path array made from the selected guide, replacing
        the nodes it produced. This is the deliberate counterpart to guides
        never dragging structure around on their own."""
        gi = self.sel_guide
        if gi is None:
            gi = self._guide_index_from_combo()
        rec = self._array_history.get(gi)
        if not rec:
            self.status_var.set('No path array has been made from that guide yet.')
            return
        gd = self.guides[gi] if 0 <= gi < len(self.guides) else None
        if gd is None:
            return
        pts = truss_guides.path_array(gd, **rec['kw'])
        if not pts:
            messagebox.showwarning('Re-array',
                'The guide has changed so that those settings give no nodes.')
            return
        if len(pts) != len(rec['nodes']):
            messagebox.showwarning('Re-array',
                'That array made %d node(s) and would now make %d. Delete the '
                'old ones and array again, so nothing is silently re-wired.'
                % (len(rec['nodes']), len(pts)))
            return
        self._push_undo('re-array')
        for ni, (mx, my) in zip(rec['nodes'], pts):
            if 0 <= ni < len(self.nodes):
                self.nodes[ni] = self._metres_to_world(mx, my)
        self._invalidate_results()
        self._show_sel(); self._draw(); self._draw_diagrams_only()
        self.status_var.set('Re-arrayed %d node(s) onto the moved guide.'
                            % len(rec['nodes']))

    def _guide_index_from_combo(self):
        want = self.path_guide.get()
        for i, gd in enumerate(self.guides):
            if self._guide_label(i, gd) == want:
                return i
        return None

    # ── arrays ───────────────────────────────────────────────────────────────

    def _selection_points_m(self):
        """The selected nodes as metre coordinates, plus the rods between
        them remapped to indices into that list."""
        ids = sorted(i for i in self.selected_nodes if 0 <= i < len(self.nodes))
        pts = [self._world_to_metres(*self.nodes[i]) for i in ids]
        remap = {old: new for new, old in enumerate(ids)}
        keep = set(ids)
        rods = []
        for r in self.rods:
            if r['a'] in keep and r['b'] in keep:
                nr = copy.deepcopy(r)
                nr['a'] = remap[r['a']]; nr['b'] = remap[r['b']]
                rods.append(nr)
        return ids, pts, rods

    def _append_copies(self, copies, rods, skip_first):
        """Add arrayed copies to the model. `skip_first` drops copy 0, which
        is the originals -- every array here includes them so the geometry is
        easy to reason about, but adding them again would duplicate every
        selected node on top of itself."""
        added_n = added_r = 0
        for k, pts in enumerate(copies):
            if skip_first and k == 0:
                continue
            offset = len(self.nodes)
            for (mx, my) in pts:
                self.nodes.append(self._metres_to_world(mx, my))
                added_n += 1
            for r in rods:
                nr = copy.deepcopy(r)
                nr['a'] = r['a'] + offset
                nr['b'] = r['b'] + offset
                self.rods.append(nr)
                added_r += 1
        return added_n, added_r

    def _array_path(self):
        gd = self._selected_guide()
        if gd is None:
            messagebox.showwarning('Path array',
                'Add a construction guide first, then array along it.')
            return
        L = truss_guides.total_length(gd)
        try:
            s0 = self.unit_value(self.path_s0)
            s1 = self.unit_value(self.path_s1)
        except (tk.TclError, ValueError):
            messagebox.showwarning('Path array', 'Start and end must be numbers.')
            return
        if s1 <= 0:
            s1 = L
        kw = {}
        if self.path_mode.get() == 'count':
            try:
                kw['count'] = int(self.path_n.get())
            except (tk.TclError, ValueError):
                messagebox.showwarning('Path array', 'Node count must be a whole number.')
                return
        else:
            try:
                kw['spacing'] = self.unit_value(self.path_step)
            except (tk.TclError, ValueError):
                messagebox.showwarning('Path array', 'Spacing must be a number.')
                return
        pts = truss_guides.path_array(gd, s_start=s0, s_end=s1, **kw)
        if not pts:
            messagebox.showwarning('Path array',
                'That gives no nodes. Check the count/spacing and the '
                'start/end stations (the guide is %.3f m long).' % L)
            return

        self._push_undo('path array')
        first = len(self.nodes)
        for (mx, my) in pts:
            self.nodes.append(self._metres_to_world(mx, my))
        n_rods = 0
        if self.path_chain.get():
            for k in range(first, len(self.nodes) - 1):
                self.rods.append(self._new_rod(k, k + 1))
                n_rods += 1
        self.selected_nodes = set(range(first, len(self.nodes)))
        self.selected_rods = set()
        gi = self._guide_index_from_combo()
        if gi is not None:
            self._array_history[gi] = {
                'kw': dict(kw, s_start=s0, s_end=s1),
                'nodes': list(range(first, len(self.nodes)))}
        self._after_array('Path array: %d node(s)%s along %.3f m of guide.'
                          % (len(pts),
                             ' and %d rod(s)' % n_rods if n_rods else '',
                             abs(s1 - s0)))

    def _array_grid(self):
        ids, pts, rods = self._selection_points_m()
        if not pts:
            self.status_var.set('Select the nodes to array first.')
            return
        try:
            nx, ny = int(self.grid_nx.get()), int(self.grid_ny.get())
            dx = self.unit_value(self.grid_dx)
            dy = self.unit_value(self.grid_dy)
        except (tk.TclError, ValueError):
            messagebox.showwarning('Grid array', 'Counts and spacings must be numbers.')
            return
        if nx < 1 or ny < 1:
            messagebox.showwarning('Grid array', 'Counts must be at least 1.')
            return
        copies = truss_guides.grid_array(pts, nx, ny, dx, dy)
        self._push_undo('grid array')
        n, r = self._append_copies(copies, rods, skip_first=True)
        self._after_array('Grid array %d x %d: added %d node(s), %d rod(s).'
                          % (nx, ny, n, r))

    def _array_polar(self):
        ids, pts, rods = self._selection_points_m()
        if not pts:
            self.status_var.set('Select the nodes to array first.')
            return
        try:
            cx = self.unit_value(self.polar_cx)
            cy = self.unit_value(self.polar_cy)
            count = int(self.polar_n.get())
            sweep = float(self.polar_deg.get())
        except (tk.TclError, ValueError):
            messagebox.showwarning('Polar array', 'Centre, count and angle must be numbers.')
            return
        if count < 1:
            messagebox.showwarning('Polar array', 'Count must be at least 1.')
            return
        copies = truss_guides.polar_array(pts, (cx, cy), count, sweep,
                                           rotate_items=bool(self.polar_rot.get()))
        self._push_undo('polar array')
        n, r = self._append_copies(copies, rods, skip_first=True)
        self._after_array('Polar array %d about (%.2f, %.2f) over %.1f°: '
                          'added %d node(s), %d rod(s).'
                          % (count, cx, cy, sweep, n, r))

    def _new_rod(self, a, b):
        return {'a': a, 'b': b,
                'E': self.unit_value(self.mat_E), 'A': self.unit_value(self.mat_A),
                'I': self.unit_value(self.mat_I), 'conn': 'pin', 'udl': 0.0,
                'udl_rotation_deg': 0.0, 'point_loads': [],
                'profile': self.active_profile.get()}

    def _after_array(self, msg):
        self._invalidate_results()
        self._show_sel(); self._draw(); self._draw_diagrams_only()
        self.status_var.set(msg + '  Ctrl+Z undoes.')

    # ══════════════════════════════════════════════════════════════════════════
    #  Undo / redo
    # ══════════════════════════════════════════════════════════════════════════
    #
    # Ctrl+Z undo, Ctrl+X redo (the user's choice of key, not a typo -- there
    # is deliberately no "cut": the clipboard is Ctrl+C / Ctrl+V only).
    #
    # Snapshot-based rather than command-based. The model is a few plain lists
    # of small dicts, so a deep copy costs microseconds and is impossible to
    # get subtly wrong; a command log would have to describe the inverse of
    # every operation, and node identity here is the LIST INDEX, so an inverse
    # that renumbers is exactly the class of bug that has already bitten this
    # tab twice. Snapshots sidestep the whole question.
    #
    # `results`/`diagrams`/`plate_checks` are NOT snapshotted: they are derived
    # from the model, and restoring a stale analysis alongside an older model
    # would show numbers that do not belong to what is on screen. Undo clears
    # them and the Analyze button goes grey again, which is the honest state.

    UNDO_LIMIT = 120

    def _model_snapshot(self):
        return {
            'nodes':    copy.deepcopy(self.nodes),
            'rods':     copy.deepcopy(self.rods),
            'loads':    copy.deepcopy(self.loads),
            'supports': copy.deepcopy(self.supports),
            'plates':   copy.deepcopy(self.plates),
            'profiles': copy.deepcopy(self.profiles),
            'guides':   copy.deepcopy(getattr(self, 'guides', [])),
        }

    def _restore_snapshot(self, snap):
        self.nodes    = copy.deepcopy(snap['nodes'])
        self.rods     = copy.deepcopy(snap['rods'])
        self.loads    = copy.deepcopy(snap['loads'])
        self.supports = copy.deepcopy(snap['supports'])
        self.plates   = copy.deepcopy(snap['plates'])
        self.profiles = copy.deepcopy(snap['profiles'])
        self.guides   = copy.deepcopy(snap.get('guides', []))
        # Any selection may name indices that no longer exist.
        self.selected_nodes = set()
        self.selected_rods = set()
        self.pending_load = set()
        self.pending_sup = set()
        self.rod_start = None
        self._invalidate_results()

    def _push_undo(self, label=''):
        """Record the state BEFORE a change. Call at the top of every method
        that mutates the model -- `test_truss_editing.py` walks the mutators
        and asserts each one grows the history, so a new one that forgets this
        fails the suite rather than silently becoming un-undoable."""
        self._undo_stack.append((label, self._model_snapshot()))
        if len(self._undo_stack) > self.UNDO_LIMIT:
            self._undo_stack.pop(0)
        # Any new edit invalidates the redo branch, exactly as every editor
        # does: you cannot redo forward into a future you have just diverged
        # from.
        self._redo_stack.clear()
        self._refresh_undo_buttons()

    def _undo(self, _event=None):
        if not self._undo_stack:
            self.status_var.set('Nothing to undo.')
            return 'break'
        label, snap = self._undo_stack.pop()
        self._redo_stack.append((label, self._model_snapshot()))
        self._restore_snapshot(snap)
        self._refresh_profile_combo()
        self._show_sel(); self._draw(); self._draw_diagrams_only()
        self.status_var.set('Undo%s.  (Ctrl+Y redoes)'
                            % (': ' + label if label else ''))
        self._refresh_undo_buttons()
        return 'break'

    def _redo(self, _event=None):
        if not self._redo_stack:
            self.status_var.set('Nothing to redo.')
            return 'break'
        label, snap = self._redo_stack.pop()
        self._undo_stack.append((label, self._model_snapshot()))
        self._restore_snapshot(snap)
        self._refresh_profile_combo()
        self._show_sel(); self._draw(); self._draw_diagrams_only()
        self.status_var.set('Redo%s.' % (': ' + label if label else ''))
        self._refresh_undo_buttons()
        return 'break'

    def _typing_in_a_field(self):
        """True when the keyboard focus is in a text entry. Ctrl+Z there
        belongs to the field, not to the model -- undoing the whole structure
        because someone mistyped a number in a box would be startling."""
        try:
            w = self.root.focus_get()
        except Exception:
            return False
        return w is not None and w.winfo_class() in ('Entry', 'TEntry', 'Text',
                                                      'TCombobox', 'Spinbox')


    def _guard_shortcut(self, fn):
        """Wrap a Ctrl-shortcut so it fires only when this tab is the visible
        one and the keyboard is not in a text field.

        `bind_all` is needed because the shortcut has to work wherever focus
        sits in the tab, but bind_all is application-wide -- in a six-tab
        notebook it would otherwise fire while the user is on the Beam tab.
        The winfo_ismapped() check is what keeps this tab's Ctrl+Z from
        undoing while someone is looking at Cable Web."""
        def handler(event=None):
            try:
                if not self.zc.canvas.winfo_ismapped():
                    return None
            except Exception:
                return None
            if self._typing_in_a_field():
                return None
            return fn(event)
        return handler

    # ══════════════════════════════════════════════════════════════════════════
    #  Clipboard — copy / paste about a reference point
    # ══════════════════════════════════════════════════════════════════════════
    #
    # Ctrl+C stores the selected geometry together with a BASE POINT; Ctrl+V
    # drops it again offset by (destination - base). The base point is what
    # makes this a drafting tool rather than a rough duplicate: copy a bay
    # with its bottom-left node as the base, paste onto the next node along,
    # and the copy lands exactly, not approximately.
    #
    # WHAT TRAVELS: nodes, the rods BETWEEN selected nodes, and each rod's own
    # properties (profile, E/A/I, connection type, UDL, its own point loads).
    # Supports, nodal loads and plates deliberately do NOT travel -- those are
    # placed per location, and silently duplicating a support or a load would
    # change the structure's behaviour in a way that is easy to miss and hard
    # to notice later.

    def _selection_base_point(self):
        """Where a copy is measured from: the snapped cursor if it is over a
        node or a grid point, else the lower-left corner of the selection's
        bounding box. Uses the same snap the drawing tools use, so 'a node or
        a grid point' means the same thing here as everywhere else."""
        if self._ghost_wx is not None:
            return self._ghost_wx, self._ghost_wy
        pts = [self.nodes[i] for i in self.selected_nodes
               if 0 <= i < len(self.nodes)]
        if not pts:
            return None
        return min(p[0] for p in pts), max(p[1] for p in pts)

    def _copy_selection(self, _event=None):
        ids = sorted(i for i in self.selected_nodes if 0 <= i < len(self.nodes))
        if not ids:
            self.status_var.set('Select nodes first, then Ctrl+C.')
            return 'break'
        base = self._selection_base_point()
        if base is None:
            return 'break'
        remap = {old: new for new, old in enumerate(ids)}
        nodes = [tuple(self.nodes[i]) for i in ids]
        keep = set(ids)
        rods = []
        for r in self.rods:
            if r['a'] in keep and r['b'] in keep:
                nr = copy.deepcopy(r)
                nr['a'] = remap[r['a']]
                nr['b'] = remap[r['b']]
                rods.append(nr)
        self._clipboard = {'nodes': nodes, 'rods': rods, 'base': base}
        bx, by = self._world_to_metres(*base)
        self.status_var.set(
            'Copied %d node(s) and %d rod(s), base point (%.3f, %.3f) m. '
            'Ctrl+V pastes at the cursor.' % (len(nodes), len(rods), bx, by))
        return 'break'

    def _paste_clipboard(self, _event=None):
        cb = self._clipboard
        if not cb:
            self.status_var.set('Nothing copied yet. Select nodes and press Ctrl+C.')
            return 'break'
        dest = (self._ghost_wx, self._ghost_wy)
        if dest[0] is None:
            dest = (self._mouse_wx, self._mouse_wy)
        dx = dest[0] - cb['base'][0]
        dy = dest[1] - cb['base'][1]

        self._push_undo('paste')
        offset = len(self.nodes)
        for (nx, ny) in cb['nodes']:
            self.nodes.append((nx + dx, ny + dy))
        for r in cb['rods']:
            nr = copy.deepcopy(r)
            nr['a'] = r['a'] + offset
            nr['b'] = r['b'] + offset
            self.rods.append(nr)

        self.selected_nodes = set(range(offset, len(self.nodes)))
        self.selected_rods = set(range(len(self.rods) - len(cb['rods']),
                                        len(self.rods)))
        self._invalidate_results()
        self._show_sel(); self._draw(); self._draw_diagrams_only()
        mx, my = self._world_to_metres(*dest)
        self.status_var.set(
            'Pasted %d node(s), %d rod(s) at (%.3f, %.3f) m. '
            'Ctrl+Z undoes.' % (len(cb['nodes']), len(cb['rods']), mx, my))
        return 'break'

    # ══════════════════════════════════════════════════════════════════════════
    #  Plates — gusset (P-1, annotation) and shear panel (P-2, member)
    # ══════════════════════════════════════════════════════════════════════════

    @staticmethod
    def _plate_node_ids(plate):
        """Every node index a plate record refers to, whichever kind it is."""
        if plate.get('kind') == 'gusset':
            return {int(plate.get('node', -1))}
        return set(int(n) for n in plate.get('nodes', []))

    def _plate_still_bounded(self, plate):
        """True while a plate's supporting geometry still exists. A gusset
        needs its node; a panel needs a rod along every one of its edges."""
        ids = self._plate_node_ids(plate)
        if any(i < 0 or i >= len(self.nodes) for i in ids):
            return False
        if plate.get('kind') == 'gusset':
            return True
        loop = list(plate.get('nodes', []))
        have = {frozenset((r['a'], r['b'])) for r in self.rods}
        return all(frozenset((loop[i], loop[(i + 1) % len(loop)])) in have
                   for i in range(len(loop)))

    def _invalidate_results(self):
        # The trace is a reading of a solve that no longer exists.
        if getattr(self, '_lp', None) is not None:
            self._stop_load_path()

        self.results = None
        self.diagrams = None
        self.plate_checks = []

    def _add_panel(self):
        """Create a shear panel from the selected rods."""
        self._push_undo('add shear panel')
        loop, why = truss_plates.closed_loop_from_rods(self.rods, self.selected_rods)
        if loop is None:
            messagebox.showwarning('Shear panel', why)
            self.status_var.set(why)
            return
        probe = {'kind': 'panel', 'nodes': loop}
        if plate_node_loop(self.nodes, probe) is None:
            msg = ('Those rods close a loop, but its corners cross over '
                   '(or it has no area), so it is not a usable panel.')
            messagebox.showwarning('Shear panel', msg)
            self.status_var.set(msg)
            return
        if any(pl.get('kind') == 'panel' and set(pl['nodes']) == set(loop)
               for pl in self.plates):
            self.status_var.set('That bay already has a shear panel.')
            return
        self.plates.append({
            'kind': 'panel', 'nodes': loop,
            'thickness_mm': self.unit_value(self.plate_t),
            'G_GPa': self.unit_value(self.plate_G),
            'E_GPa': 200.0, 'nu': 0.3,
            'Fy': self.unit_value(self.plate_fy),
            'Fexx': self.unit_value(self.plate_fexx),
            'weld_lines': 2,
        })
        self._invalidate_results()
        self._draw(); self._draw_diagrams_only(); self._show_sel()
        self.status_var.set('Shear panel added on nodes %s — re-run Analyze.'
                            % ', '.join(str(n) for n in loop))

    def _add_gusset(self):
        """Create a gusset plate at each selected node."""
        self._push_undo('add gusset')
        if not self.selected_nodes:
            self.status_var.set('Select one or more nodes, then Add gusset.')
            return
        added = 0
        for ni in sorted(self.selected_nodes):
            if any(pl.get('kind') == 'gusset' and pl.get('node') == ni
                   for pl in self.plates):
                continue
            self.plates.append({
                'kind': 'gusset', 'node': ni,
                'thickness_mm': self.unit_value(self.plate_t),
                'Fy': self.unit_value(self.plate_fy),
                'Fu': truss_plates.DEFAULT_FU_MPA,
                'Fexx': self.unit_value(self.plate_fexx),
                'weld_lines': 2,
                'landing_m': max(self.unit_value(self.gusset_landing), 1.0) / 1000.0,
                'conn_type': self.plate_conn.get(),
                'bolt_d_mm': self.unit_value(self.bolt_d),
                'bolt_rows': int(self.bolt_rows.get()),
                'bolt_cols': int(self.bolt_cols.get()),
                'pitch_mm': self.unit_value(self.bolt_pitch),
                'gauge_mm': self.unit_value(self.bolt_gauge),
                'end_mm': self.unit_value(self.bolt_end),
                'edge_mm': self.unit_value(self.bolt_edge),
            })
            added += 1
        if not added:
            self.status_var.set('Those nodes already have a gusset.')
            return
        # A gusset is an annotation: it never enters the stiffness matrix, so
        # existing results stay valid. Only its own check has to be (re)run.
        if self.results:
            self.plate_checks = truss_plates.check_all(
                self.nodes, self.rods, self.plates, self.results)
        self._draw(); self._show_sel()
        self.status_var.set('Added %d gusset plate(s). Results unchanged — a '
                            'gusset does not stiffen the model.' % added)

    def _remove_plates(self):
        """Remove every plate touching the current selection."""
        self._push_undo('remove plates')
        sel = set(self.selected_nodes)
        for ri in self.selected_rods:
            if 0 <= ri < len(self.rods):
                sel |= {self.rods[ri]['a'], self.rods[ri]['b']}
        if not sel:
            self.status_var.set('Select the nodes or rods whose plates to remove.')
            return
        before = len(self.plates)
        kept = []
        had_panel = False
        for pl in self.plates:
            if self._plate_node_ids(pl) & sel:
                had_panel |= (pl.get('kind') == 'panel')
                continue
            kept.append(pl)
        self.plates = kept
        n = before - len(self.plates)
        if had_panel:
            self._invalidate_results()
            self._draw_diagrams_only()
        self._draw(); self._show_sel()
        self.status_var.set('Removed %d plate(s).%s'
                            % (n, ' Re-run Analyze.' if had_panel else ''))

    def _plate_fill_for(self, check):
        """Utilisation-graded fill. A panel whose buckling check governs is
        drawn in a distinct colour, because a comfortable-looking tau on an
        already-buckled plate is the worst thing this feature could show."""
        if not check or not check.get('valid', True):
            return '#d9d9d9', '#999999'
        u = check.get('util', 0.0)
        if check.get('buckling_governs') and u > 1.0:
            return '#f3c9d6', '#c0392b'
        if u > 1.0:
            return '#f6c9c9', '#c0392b'
        if u > 0.75:
            return '#fbe6c4', '#c98a1e'
        return '#d8e8f6', '#5a8fbe'

    # ══════════════════════════════════════════════════════════════════════════
    #  CAD precision helpers
    # ══════════════════════════════════════════════════════════════════════════

    def _world_to_metres(self, wx, wy):
        """Canvas world coords → metres (origin top-left, y flipped)."""
        return wx / PX_PER_M, -wy / PX_PER_M

    def _metres_to_world(self, mx, my):
        return mx * PX_PER_M, -my * PX_PER_M

    def _finest_grid_step_world(self):
        """The finest currently-VISIBLE grid unit, in world units (the same
        SNAP-scaled coordinate system as self.nodes) -- mirrors exactly the
        major/minor/micro step computation used by _draw_adaptive_grid, so
        grid-snap placement always lands on a grid point you can actually
        see on screen at the current zoom, instead of always the fixed 1m
        base unit."""
        z = self.zc.zoom
        step, mult = _nice_grid_step(SNAP, z, target_px=55)
        for _ in range(2):
            sub = _grid_subdiv_of(mult)
            next_step = step / sub
            if next_step * z < 10:
                break
            step, mult = next_step, mult / sub
        return step

    def _compute_ghost(self, wx, wy):
        """
        Given raw world cursor position, apply active snaps and return
        the snapped world position that will be used for node placement.
        """
        # 1. node snap: if close to an existing node, lock to it
        if self.snap_node.get():
            ni = near_node(self.nodes, wx, wy, thr=18/self.zc.zoom)
            if ni >= 0:
                return self.nodes[ni]

        # 1b. curve snap: pull onto the nearest construction guide. It sits
        # AFTER the node snap (an existing node still wins -- you almost never
        # want a new node a millimetre off one you already have) and BEFORE
        # grid and angle, because landing exactly on the guide is the whole
        # reason the guide was drawn. Grid snap would drag the point back off
        # the curve, so a curve hit returns immediately.
        if self.snap_curve.get() and self.guides:
            thr_w = 18 / max(self.zc.zoom, 1e-6)
            mx, my = self._world_to_metres(wx, wy)
            thr_m = thr_w / PX_PER_M
            best, bd = None, float('inf')
            for gd in self.guides:
                p, d = truss_guides.closest_point(gd, mx, my)
                if p is not None and d < bd:
                    best, bd = p, d
            if best is not None and bd <= thr_m:
                return self._metres_to_world(best[0], best[1])

        # 2. angle snap: if a rod is being drawn, constrain direction from rod_start
        if self.snap_angle.get() and self.rod_start is not None:
            ref = self.nodes[self.rod_start]
            dx, dy = wx - ref[0], wy - ref[1]
            dist = math.hypot(dx, dy)
            if dist > 0.5:
                deg = self.snap_angle_deg.get()
                raw_angle = math.degrees(math.atan2(-dy, dx))  # y flipped
                snapped   = round(raw_angle / deg) * deg
                rad       = math.radians(snapped)
                wx = ref[0] + dist * math.cos(rad)
                wy = ref[1] - dist * math.sin(rad)  # re-flip y

        # 3. grid snap -- to whatever grid unit is currently visible (scales
        # with the adaptive LOD grid, so zooming in lets you snap to finer
        # subdivisions, just like the grid you actually see)
        if self.snap_grid.get():
            unit = self._finest_grid_step_world()
            wx = round(wx / unit) * unit
            wy = round(wy / unit) * unit

        return wx, wy

    def _cad_place_coord(self):
        """Place a node at the typed absolute coordinates (metres)."""
        try:
            mx = self.unit_value(self.cad_x)
            my = self.unit_value(self.cad_y)
        except (tk.TclError, ValueError):
            messagebox.showwarning('Place node',
                'Enter valid numbers for X and Y before placing a node.')
            return
        wx, wy = self._metres_to_world(mx, my)
        self._push_undo('place node')
        self.nodes.append((wx, wy))
        self.results = None; self.diagrams = None
        self._draw_diagrams_only()
        self._draw()
        self.status_var.set(
            f'Node {len(self.nodes)-1} placed at ({mx:.3f}, {my:.3f}) m')

    def _cad_pick_ref(self):
        """Switch canvas into "pick reference node" mode for polar entry."""
        self._picking_ref = True
        self.polar_ref_var.set('click node…')
        self.status_var.set(
            'POLAR REF: click a node on the canvas to use as origin')

    def _cad_place_polar(self):
        """Place a node at distance + angle from the reference node."""
        if self._polar_ref_node is None:
            messagebox.showwarning('Polar', 'Pick a reference node first.')
            return
        ref  = self.nodes[self._polar_ref_node]
        try:
            dist = self.unit_value(self.cad_dist)   # metres, whatever was typed
            ang  = math.radians(self.cad_angle.get())  # 0°=right, CCW positive
        except (tk.TclError, ValueError):
            messagebox.showwarning('Place node',
                'Enter a valid distance and angle before placing a node.')
            return
        dx_m =  dist * math.cos(ang)
        dy_m =  dist * math.sin(ang)
        wx   = ref[0] + dx_m * PX_PER_M
        wy   = ref[1] - dy_m * PX_PER_M  # y flipped in canvas
        self._push_undo('place node')
        self.nodes.append((wx, wy))
        self.results = None; self.diagrams = None
        self._draw_diagrams_only()
        self._draw()
        mx, my = self._world_to_metres(wx, wy)
        self.status_var.set(
            f'Node {len(self.nodes)-1} placed at ({mx:.3f}, {my:.3f}) m  '
            f'[dist={dist:.3f} m, angle={self.cad_angle.get():.1f}°]')

    def _ruler_toggle(self):
        """Reset ruler state when toggled."""
        self.ruler_start = None
        self.ruler_label.configure(text='')
        self._draw()

    # ══════════════════════════════════════════════════════════════════════════
    #  Tooltip
    # ══════════════════════════════════════════════════════════════════════════
    def _show_tooltip(self, sx, sy, text):
        self._hide_tooltip()
        rx = self.zc.canvas.winfo_rootx() + sx + 14
        ry = self.zc.canvas.winfo_rooty() + sy - 10
        tw = tk.Toplevel(self.root)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f'+{rx}+{ry}')
        fr = tk.Frame(tw, bg='#fffde7', bd=1, relief='solid')
        fr.pack()
        tk.Label(fr, text=text, bg='#fffde7', fg='#333',
                 font=('Helvetica',9), justify='left', padx=6, pady=4).pack()
        self._tip_win = tw

    def _hide_tooltip(self):
        if self._tip_after:
            self.root.after_cancel(self._tip_after); self._tip_after = None
        if self._tip_win:
            try: self._tip_win.destroy()
            except: pass
            self._tip_win = None

    def _bind_widget_tooltip(self, widget, text):
        """Small standalone hover tooltip for a plain toolbar widget (as
        opposed to `_show_tooltip`, which is positioned from canvas-space
        coordinates for hovering over model elements)."""
        state = {'win': None}
        def show(_e=None):
            hide()
            rx = widget.winfo_rootx() + 4
            ry = widget.winfo_rooty() + widget.winfo_height() + 4
            tw = tk.Toplevel(self.root)
            tw.wm_overrideredirect(True)
            tw.wm_geometry(f'+{rx}+{ry}')
            fr = tk.Frame(tw, bg='#fffde7', bd=1, relief='solid')
            fr.pack()
            tk.Label(fr, text=text, bg='#fffde7', fg='#333', wraplength=260,
                     font=('Helvetica',9), justify='left', padx=6, pady=4).pack()
            state['win'] = tw
        def hide(_e=None):
            if state['win'] is not None:
                try: state['win'].destroy()
                except: pass
                state['win'] = None
        widget.bind('<Enter>', show)
        widget.bind('<Leave>', hide)

    def _on_motion(self, event):
        sx, sy = event.x, event.y
        wx, wy = self.zc.s2w(sx, sy)
        self._mouse_wx, self._mouse_wy = wx, wy

        # live cursor readout in metres
        mx, my = self._world_to_metres(wx, wy)
        self.cursor_var.set(f'x={mx:.2f}  y={my:.2f} m')

        # compute ghost (snapped) position and trigger redraw for preview
        gx, gy = self._compute_ghost(wx, wy)
        self._ghost_wx, self._ghost_wy = gx, gy

        # ruler live measurement
        if self.ruler_active.get() and self.ruler_start is not None:
            rx, ry = self.ruler_start
            dm = math.hypot((gx-rx)/PX_PER_M, (gy-ry)/PX_PER_M)
            ang = math.degrees(math.atan2(-(gy-ry), gx-rx))
            self.ruler_label.configure(
                text=f'd={dm:.3f} m  α={ang:.1f}°')

        # if angle snap is on and drawing a rod, update ghost constantly
        needs_redraw = (self.snap_angle.get() and self.rod_start is not None
                        or self.ruler_active.get()
                        or self.tool.get() in ('node', 'rod'))
        if needs_redraw:
            self._draw()

        self._hide_tooltip()

        ni = near_node(self.nodes, wx, wy, thr=14/self.zc.zoom)
        if ni >= 0:
            n   = self.nodes[ni]
            sup = next((s for s in self.supports if s['node']==ni), None)
            ld  = next((l for l in self.loads    if l['node']==ni), None)
            res = self.results['node_res'][ni] if self.results else None
            rxn = self.results['reactions'].get(ni) if self.results else None
            nm_x, nm_y = self._world_to_metres(n[0], n[1])
            lines = [f'{self.joint_text(ni)}  ({nm_x:.3f}, {nm_y:.3f}) m']
            F = self.u('force')
            if sup: lines.append(f'Support: {self.support_label(sup["type"])}')
            if ld:  lines.append(f'Load  Fx={self.show("force", ld["fx"]):g}  '
                                 f'Fy={self.show("force", ld["fy"]):g} {F}')
            if rxn: lines.append(f'Rx={self.show("force", rxn.get("rx",0)):.2f}  '
                                 f'Ry={self.show("force", rxn.get("ry",0)):.2f} {F}')
            if res: lines.append(f'ux={res["ux"]:.3f}  uy={res["uy"]:.3f} mm')
            self._tip_after = self.root.after(
                280, lambda t='\n'.join(lines),x=sx,y=sy: self._show_tooltip(x,y,t))
            return

        ri = near_rod(self.nodes, self.rods, wx, wy, thr=7/self.zc.zoom)
        if ri >= 0:
            rod = self.rods[ri]
            na, nb = self.nodes[rod['a']], self.nodes[rod['b']]
            L   = math.hypot(nb[0]-na[0], nb[1]-na[1]) / PX_PER_M
            res = self.results['rod_res'][ri] if self.results else None
            lines = [f'Rod {ri}  ({rod["a"]} → {rod["b"]})',
                     f'L={self.fmt("length", L)}   E={self.fmt("modulus", rod["E"])}'
                     f'   A={self.fmt("area", rod["A"])}']
            if res:
                f    = res['force']
                kind = 'Tension' if f>0.01 else ('Compression' if f<-0.01 else 'Zero')
                lines += [f'N = {self.fmt("force", f, sign=True)}  [{kind}]']
            self._tip_after = self.root.after(
                280, lambda t='\n'.join(lines),x=sx,y=sy: self._show_tooltip(x,y,t))
            return

        for ld in self.loads:
            n = self.nodes[ld['node']]
            ns, _ = self.zc.w2s(n[0], n[1])
            if math.hypot(ns-sx, _-sy) < 55:
                mag = math.hypot(ld['fx'], ld['fy'])
                F = self.u('force')
                lines = [f'Load on node {ld["node"]}',
                         f'Fx={self.show("force", ld["fx"]):g}  '
                         f'Fy={self.show("force", ld["fy"]):g} {F}',
                         f'|F|={self.show("force", mag):.2f} {F}']
                self._tip_after = self.root.after(
                    280, lambda t='\n'.join(lines),x=sx,y=sy: self._show_tooltip(x,y,t))
                return

        for s in self.supports:
            n = self.nodes[s['node']]
            ns, ms = self.zc.w2s(n[0], n[1])
            if math.hypot(ns-sx, ms-sy) < 30:
                rxn  = self.results['reactions'].get(s['node']) if self.results else None
                lines = [f'Support on node {s["node"]}', f'Type: {s["type"]}']
                if rxn: lines.append(
                    f'Rx={self.show("force", rxn.get("rx",0)):.2f}  '
                    f'Ry={self.show("force", rxn.get("ry",0)):.2f} '
                    f'{self.u("force")}')
                self._tip_after = self.root.after(
                    280, lambda t='\n'.join(lines),x=sx,y=sy: self._show_tooltip(x,y,t))
                return

    def _on_leave(self, event):
        self._hide_tooltip()

    # ══════════════════════════════════════════════════════════════════════════
    #  Tool management
    # ══════════════════════════════════════════════════════════════════════════
    def _set_tool(self, t):
        self.tool.set(t); self.rod_start = None
        msgs = {
            'node':    'Click canvas to place joints (snaps to grid)',
            'rod':     'Click first node then second to connect with a rod',
            'support': 'Click a node, configure support in the panel',
            'load':    'Click a node, set Fx/Fy in the panel, click Apply',
            'select':  'Click nodes/rods to inspect. Delete key removes.',
            'pan':     'Drag the canvas to move the view. Nothing is edited '
                       'while Pan is active.',
        }
        self.status_var.set(msgs[t])
        try:
            self.zc.canvas.configure(
                cursor='fleur' if t == 'pan' else 'crosshair')
        except Exception:
            pass
        self.load_frame.pack_forget(); self.sup_frame.pack_forget()
        # Picking a tool takes you to its controls rather than leaving you
        # to find them -- the whole point of the rail.
        mode = self.TOOL_MODE.get(t)
        if mode:
            self._show_mode(mode)
        self._refresh_tool_buttons(); self._draw()

    #: What each support type is called on screen. The stored keys stay as
    #: they are -- every saved model and every workbook uses them -- but
    #: "rollerX" is not a word, and an architecture student reading it has
    #: to guess whether X is the direction it slides or the direction it
    #: holds. It is the direction it slides.
    SUPPORT_LABELS = {
        'pin':     'Pin — held both ways, free to rotate',
        'rollerX': 'Roller — slides horizontally',
        'rollerY': 'Roller — slides vertically',
        'fixed':   'Fixed — held both ways, cannot rotate',
    }
    SUPPORT_SHORT = {
        'pin': 'Pin', 'rollerX': 'Roller (slides ↔)',
        'rollerY': 'Roller (slides ↕)', 'fixed': 'Fixed',
    }

    def support_label(self, stype, short=True):
        table = self.SUPPORT_SHORT if short else self.SUPPORT_LABELS
        return table.get(stype, stype)

    #: Typical Young's modulus, in the GPa this tab stores `modulus` in.
    #: Round working values, not design minima -- they set how far the
    #: truss deflects, and for a PIN-JOINTED truss they do not affect the
    #: member forces at all, which is the thing worth noticing.
    MATERIAL_PRESETS = (
        ('Steel (any grade)', 200.0),
        ('Stainless steel', 193.0),
        ('Aluminium 6061-T6', 70.0),
        ('Reinforced concrete', 30.0),
        ('Glulam GL24h (along)', 11.5),
        ('Softwood C24 (along)', 11.0),
    )

    #: A few rolled IPE sections, by NAME ONLY. A short list on purpose:
    #: it is here so a student can see what a real section is worth, not
    #: to be a steel catalogue -- the whole 101-section catalogue is behind
    #: "Manage profiles… -> Steel section…".
    #:
    #: These used to carry their own A and I, copied from a handbook, and
    #: that second table disagreed with apps/stereo/stereo_profiles by 3-5 %
    #: (the catalogue computes from the plate geometry and has no root
    #: fillets). Two numbers for one section is one too many, and the
    #: handbook A paired with the catalogue's own r_gyr in a check would be
    #: incoherent -- so the names are the whole table now and every property
    #: comes from the catalogue, which is also what the CIRSOC check reads.
    SECTION_PRESETS = ('IPE 160', 'IPE 200', 'IPE 240', 'IPE 300', 'IPE 400')

    #: The steel grade a quick-picked section is given. The other grade
    #: (F36 / A992) is offered in the full section picker.
    PRESET_STEEL = 'F24 (CIRSOC) / A36'

    @staticmethod
    def joint_letter(i):
        """0 -> A, 25 -> Z, 26 -> AA. The classic drawing convention."""
        i = int(i)
        out = ''
        while True:
            out = chr(ord('A') + i % 26) + out
            i = i // 26 - 1
            if i < 0:
                return out

    def joint_label(self, i):
        """What the DRAWING calls a joint.

        On the canvas a joint number and a member number sit a few pixels
        apart and look identical -- "2" next to "2" is one of them, and
        nothing says which. Lettering the joints is how every structures
        textbook separates them, and it costs nothing: the index is
        unchanged underneath, and every text surface still says "Node 2"
        so the drawing and the tables can still be matched up.
        """
        if getattr(self, 'letter_joints', None) is None or self.letter_joints.get():
            return self.joint_letter(i)
        return str(i)

    def joint_text(self, i):
        """What a SENTENCE calls a joint: 'Node 2 · joint C' while
        lettering is on, so the reader can map the two without having to
        count round the drawing."""
        if getattr(self, 'letter_joints', None) is not None and self.letter_joints.get():
            return 'Node %d \u00b7 joint %s' % (i, self.joint_letter(i))
        return 'Node %d' % i

    # ══════════════════════════════════════════════════════════════════════
    #  Where does this load go?
    # ══════════════════════════════════════════════════════════════════════
    #
    # The one reading the numbers do not hand you. apps/truss/truss_loadpath
    # does it by SUPERPOSITION -- the same model solved with this load and
    # nothing else -- so the shares it reports are the reactions of that
    # solve and cannot disagree with statics. See that module for why the
    # obvious joint-walking version was thrown away.

    def _toggle_load_path(self):
        if not self.show_load_path.get():
            self._stop_load_path()
            self._show_load_path_chooser(False)
            self._draw()
            return
        self._compute_load_path()
        self._draw()

    # ── which load: the chooser ───────────────────────────────────────────
    #
    # Asked for on 12-10-26: "i would like to be able to select the force
    # that it is describing the path of". The trace used to pick for you
    # -- the selected joint if it was loaded, else the biggest load -- and
    # only at the moment it was switched on. Now there is a list of every
    # load right under the switch, ‹ › to step through them, and clicking
    # a loaded joint on the drawing picks that one. One load per joint is
    # how the Load tool stores them, so a joint names a load.

    #: Screen-direction arrows, 45° apart, starting at "right" and turning
    #: clockwise as y grows downward on the canvas.
    LP_ARROWS = '→↘↓↙←↖↑↗'

    def _build_load_path_chooser(self):
        bg = '#f0f0ee'
        row = tk.Frame(self.show_frame, bg=bg)
        self.lp_row = row
        tk.Label(row, text='   Load:', bg=bg, fg='#0F8A7E',
                 font=('Helvetica', 9, 'bold')).pack(side='left')
        # Tied to this window: a variable with no master binds to Tk's
        # default root, which is a different (or destroyed) interpreter
        # whenever more than one window has been made in the process.
        self.lp_choice = tk.StringVar(master=row, value='')
        box = ttk.Combobox(row, textvariable=self.lp_choice, width=18,
                           state='readonly', font=('Helvetica', 9))
        box.pack(side='left', padx=(4, 2))
        box.bind('<<ComboboxSelected>>', self._on_load_path_choice)
        self.lp_box = box
        for text, step in (('‹', -1), ('›', 1)):
            b = tk.Button(row, text=text, width=2, relief='flat', bd=0,
                          bg='#e2e6e4', font=('Helvetica', 10, 'bold'),
                          command=lambda d=step: self._step_load_path(d))
            b.pack(side='left', padx=1)
        self._bind_widget_tooltip(
            box, 'The load whose path is drawn. Or click a loaded joint '
            'on the drawing.')
        self.lp_hint = tk.Label(self.show_frame, text='      or click a '
                                'loaded joint on the drawing', bg=bg,
                                fg='#777', font=('Helvetica', 8),
                                anchor='w')

    def _show_load_path_chooser(self, on):
        if not hasattr(self, 'lp_row'):
            return
        if on:
            if not self.lp_row.winfo_ismapped():
                self.lp_row.pack(fill='x', after=self._lp_check)
                self.lp_hint.pack(fill='x', after=self.lp_row)
        else:
            self.lp_row.pack_forget()
            self.lp_hint.pack_forget()

    def _traceable_loads(self):
        """{joint: (fx, fy)} for every non-zero load, in joint order."""
        out = {}
        for l in self.loads:
            fx, fy = l.get('fx', 0.0), l.get('fy', 0.0)
            if math.hypot(fx, fy) > 1e-9:
                out[l['node']] = (fx, fy)
        return dict(sorted(out.items()))

    def _load_path_label(self, ni, fx, fy):
        ang = math.atan2(fy, fx)            # screen: y down, so clockwise
        arrow = self.LP_ARROWS[int(round(ang / (math.pi / 4))) % 8]
        return '%s  %s  %s' % (self.joint_label(ni), arrow,
                               self.fmt('force', math.hypot(fx, fy)))

    def _refresh_load_path_chooser(self, current):
        if not hasattr(self, 'lp_box'):
            return
        loads = self._traceable_loads()
        self._lp_choices = list(loads)
        self.lp_box['values'] = [self._load_path_label(n, *f)
                                 for n, f in loads.items()]
        if current in loads:
            self.lp_box.current(self._lp_choices.index(current))
        else:
            self.lp_choice.set('')
        self._show_load_path_chooser(True)

    def _on_load_path_choice(self, _event=None):
        i = self.lp_box.current()
        if 0 <= i < len(getattr(self, '_lp_choices', [])):
            self._trace_load_at(self._lp_choices[i])

    def _step_load_path(self, step):
        nodes = list(self._traceable_loads())
        if not nodes:
            return
        cur = self._lp['start'] if self._lp else self._lp_node
        i = nodes.index(cur) if cur in nodes else -step
        self._trace_load_at(nodes[(i + step) % len(nodes)])

    def _trace_load_at(self, ni):
        """Trace the load at joint `ni` -- from the list, ‹ ›, or a click."""
        self._lp_node = ni
        if not self.show_load_path.get():
            self.show_load_path.set(True)
        self._compute_load_path()
        self._draw()

    def _loaded_node_to_trace(self):
        """The joint to trace: the one picked in the chooser (or clicked)
        while it still carries a load; else the selected joint if it
        carries one; else the biggest load in the model, so the feature
        does something useful the first time it is switched on."""
        loaded = {n: math.hypot(*f)
                  for n, f in self._traceable_loads().items()}
        if not loaded:
            return None
        if self._lp_node in loaded:
            return self._lp_node
        for ni in self.selected_nodes:
            if ni in loaded:
                return ni
        return max(loaded, key=lambda n: loaded[n])

    def _compute_load_path(self, announce=True):
        self._lp = None
        self._refresh_load_path_chooser(None)
        if not self.results:
            if announce:
                self.status_var.set('Run ▶ Analyze first, then trace a load.')
            return
        ni = self._loaded_node_to_trace()
        if ni is None:
            if announce:
                self.status_var.set('There is no load to trace yet — add '
                                    'one with the Load tool.')
            return
        self._lp_node = ni
        self._refresh_load_path_chooser(ni)
        self._lp = truss_loadpath.trace(
            self.nodes, self.rods, self.supports, self.plates,
            self.loads, ni, analyze)
        if announce:
            self.status_var.set(truss_loadpath.summary(
                self._lp, joint_name=self.joint_label,
                force_fmt=lambda v: self.fmt('force', v, sign=True)))
        self._start_load_path_anim()

    def _start_load_path_anim(self):
        if self._lp_job is not None:
            return
        self._lp_step()

    def _stop_load_path(self):
        if self._lp_job is not None:
            try:
                self.root.after_cancel(self._lp_job)
            except Exception:
                pass
            self._lp_job = None
        self._lp = None

    def _lp_step(self):
        """One frame of travel. Only the phase moves -- the trace itself is
        solved once, not per frame."""
        if not self.show_load_path.get() or self._lp is None:
            self._lp_job = None
            return
        self._lp_phase = (self._lp_phase + 0.06) % 1.0
        self._draw()
        try:
            self._lp_job = self.root.after(60, self._lp_step)
        except Exception:
            self._lp_job = None

    def _draw_load_path(self, c, w2s, z):
        """Chevrons running away from the traced load, along every member
        that carries a measurable part of it, sized by its share."""
        lp = self._lp
        if not lp or not lp.get('share'):
            return
        LP = '#0F8A7E'
        start = lp['start']
        for ri, share in lp['share'].items():
            if ri >= len(self.rods):
                continue
            rod = self.rods[ri]
            a, b = self.nodes[rod['a']], self.nodes[rod['b']]
            ux, uy = truss_loadpath.flow_direction(
                self.nodes, self.rods, ri, lp['forces'], start)
            # flow_direction works in world coords, where y grows DOWNWARD
            # on this canvas exactly as it does in the model, so no flip.
            sx0, sy0 = w2s(a[0], a[1])
            sx1, sy1 = w2s(b[0], b[1])
            if (ux * (b[0] - a[0]) + uy * (b[1] - a[1])) < 0:
                sx0, sy0, sx1, sy1 = sx1, sy1, sx0, sy0
            dx, dy = sx1 - sx0, sy1 - sy0
            L = math.hypot(dx, dy)
            if L < 1:
                continue
            dx, dy = dx / L, dy / L
            px, py = -dy, dx
            size = 4 + 7 * share
            n = max(2, int(L // 34))
            for k in range(n):
                t = ((k + self._lp_phase) / n) * L
                if t < 10 or t > L - 10:
                    continue
                cx, cy = sx0 + dx * t, sy0 + dy * t
                c.create_line(cx - dx*size + px*size, cy - dy*size + py*size,
                              cx, cy,
                              cx - dx*size - px*size, cy - dy*size - py*size,
                              fill=LP, width=max(1.5, 1.0 + 2.0 * share),
                              capstyle='round', joinstyle='round')
        # mark where it lands
        for node, frac in lp.get('supports', {}).items():
            if node >= len(self.nodes):
                continue
            nx, ny = self.nodes[node]
            sx, sy = w2s(nx, ny)
            c.create_oval(sx-16, sy-16, sx+16, sy+16, outline=LP, width=2)
            # Beside the joint, not under it: the support glyph and its
            # hatching occupy everything directly below. The halo is
            # because the reaction arrow and its label land here too, and
            # the share is the one number this mode exists to show.
            pct = '%.0f%%' % (frac * 100)
            for ddx, ddy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                c.create_text(sx+21+ddx, sy+2+ddy, text=pct, fill='white',
                              anchor='w', font=('Helvetica', 10, 'bold'))
            c.create_text(sx+21, sy+2, text=pct,
                          fill=LP, anchor='w', font=('Helvetica', 10, 'bold'))
        n0 = lp['start']
        if n0 < len(self.nodes):
            sx, sy = w2s(*self.nodes[n0][:2])
            # Beside the arrow's shaft, not on it: the traced arrow itself
            # is drawn over this, haloed (see _draw_load).
            for ddx, ddy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                c.create_text(sx + 12 + ddx, sy - 24 + ddy, anchor='w',
                              text='traced', fill='white',
                              font=('Helvetica', 8, 'bold'))
            c.create_text(sx + 12, sy - 24, anchor='w', text='traced',
                          fill=LP, font=('Helvetica', 8, 'bold'),
                          tags=('load_traced_label',))

    # ── the mode rail ────────────────────────────────────────────────────
    def _on_mode_change(self, key):
        """Retitle the panel and re-measure it: each mode is a different
        height, and the scrolled panel has to be told."""
        self.mode_title.set(self.rail.label_of(key).upper())
        try:
            self.panel_outer.interior.update_idletasks()
            self.panel_outer._sync()
        except Exception:
            pass

    def _on_mode_hint(self, text):
        """The rail's hover text goes to the status bar, which is where
        this tab already explains itself."""
        if text:
            self._status_before_hint = self.status_var.get()
            self.status_var.set(text)
        elif getattr(self, '_status_before_hint', None) is not None:
            self.status_var.set(self._status_before_hint)
            self._status_before_hint = None

    def _show_mode(self, key):
        """Switch the rail from code -- when a tool is picked, or when a
        result arrives that the student should be looking at."""
        rail = getattr(self, 'rail', None)
        if rail is not None and rail.active() != key:
            rail.select(key)

    def _pick_support(self, key):
        self.sup_type.set(key)
        self._refresh_support_picker()

    def _refresh_support_picker(self):
        """Ring the chosen symbol. A radio dot beside a drawing would say
        the same thing twice; the frame itself is the indicator."""
        for key, cell in getattr(self, 'sup_btns', {}).items():
            chosen = key == self.sup_type.get()
            try:
                cell.configure(relief='solid' if chosen else 'flat',
                               bg='#dce9f7' if chosen else '#f0f0ee',
                               highlightbackground='#1a6bbd')
                for child in cell.winfo_children():
                    child.configure(bg='#dce9f7' if chosen else '#f0f0ee')
            except Exception:
                pass

    # ── material and section, onto the rods ───────────────────────────────
    #
    # THE BUG THIS REPLACES. mat_E / mat_A / mat_I are read in exactly two
    # places, both of them rod CREATION, so this whole box applied to no
    # existing rod. Selecting rods and picking "IPE 240" filled the boxes,
    # printed "IPE 240 -- A = 39.10 cm2, I = 3892.00 cm4" in the status
    # bar, left every rod exactly as it was, and left the solved results
    # standing so not one number on screen moved. Reported 11-10-26.
    #
    # WHO IS THE TARGET. The selected rods when there are any, every rod
    # when there are none. That is the rule for the whole box, it is
    # written on the button, and `_material_target` is the single place it
    # is decided so the button, the hint and the action cannot disagree.

    def _material_target(self):
        """(rod indices, phrase) -- what this box would act on right now."""
        if self.selected_rods:
            n = len(self.selected_rods)
            return (sorted(self.selected_rods),
                    '%d selected rod%s' % (n, '' if n == 1 else 's'))
        return list(range(len(self.rods))), 'all rods'

    def _refresh_material_target(self):
        """Keep the button honest about what it is about to change."""
        _rods, phrase = self._material_target()
        try:
            self.mat_apply_btn.configure(text='Apply E, A, I to %s' % phrase)
            self.mat_target_hint.configure(
                text='Picking a material or a section above changes %s at '
                     'once. Nothing selected means every rod.' % phrase)
        except Exception:
            pass

    def _after_section_change(self, message):
        """One tail for every change in this box: the old results describe
        a truss that no longer exists, so they go, and the panel, the
        drawing and the diagrams are all re-made.

        Re-solving rather than only clearing, when the truss was already
        solved: the complaint was that "the information does not change",
        and a cleared result panel is still not the new numbers."""
        was_solved = self.results is not None
        self.results = None
        self.diagrams = None
        self.rod_checks = None
        if was_solved and self.rods:
            self._run_analysis(quiet=True)
        else:
            self._draw()
            self._draw_diagrams_only()
        self._show_sel()
        self._refresh_material_target()
        self.status_var.set(message)

    def _apply_material_to_rods(self):
        """The three boxes, written onto the target rods."""
        rods, phrase = self._material_target()
        if not rods:
            self.status_var.set('There are no rods to apply a material to.')
            return
        self._push_undo('material')
        E = self.unit_value(self.mat_E)
        A = self.unit_value(self.mat_A)
        I = self.unit_value(self.mat_I)
        over = sorted({self.rods[ri].get('profile', 'Default') for ri in rods
                       if self.profiles.get(
                           self.rods[ri].get('profile', 'Default'),
                           {}).get('catalog')})
        for ri in rods:
            self.rods[ri].update(E=E, A=A, I=I)
        note = ''
        if over:
            # Said, not prevented. Typing an area over a catalogue section
            # is a reasonable thing to try; finding out later that the
            # check was still using the catalogue's radius of gyration is
            # not.
            note = (' This overrides the section of %s — the check still '
                    'uses that section\'s Fy and radius of gyration.'
                    % ', '.join('"%s"' % f for f in over))
        self._after_section_change(
            'E = %s, A = %s, I = %s on %s.%s'
            % (self.fmt('modulus', E), self.fmt('area', A),
               self.fmt('inertia', I), phrase, note))

    def _apply_material_preset(self, _event=None):
        """Fill E from the chosen material, and put it on the rods.

        The box stays editable: a preset is a starting point, not a lock.
        E is the one property a non-steel material shares with this box --
        there is no timber or aluminium catalogue here -- so this writes E
        and leaves A and I alone."""
        for name, E in self.MATERIAL_PRESETS:
            if name != self.mat_preset.get():
                continue
            self.mat_E.set(self.show('modulus', E))
            rods, phrase = self._material_target()
            if not rods:
                self.status_var.set(
                    '%s — E = %s. It is what the next rod will be drawn '
                    'with.' % (name, self.fmt('modulus', E)))
                return
            self._push_undo('material preset')
            for ri in rods:
                self.rods[ri]['E'] = E
            self._after_section_change(
                '%s — E = %s on %s. For a pin-jointed truss this changes '
                'the deflection, not the member forces.'
                % (name, self.fmt('modulus', E), phrase))
            return

    def _apply_section_preset(self, _event=None):
        """Fill A and I from the chosen rolled section, and put the whole
        section on the rods.

        The WHOLE section, not just A and I: a rod is only checked once it
        has Fy and a radius of gyration, and those live on its family
        (truss_design.member_for). Writing A and I alone would move the
        forces and still leave every utilisation reading "no steel
        section", which is its own kind of silent failure."""
        name = self.sec_preset.get()
        if name not in self.SECTION_PRESETS:
            return
        A, I = self._section_AI(name)
        if A is not None:
            # Rounded for the BOX only. The catalogue computes A and I from
            # the plate geometry, so they arrive as 37.184800000000003, and
            # an entry field full of digits nobody typed reads as noise.
            # The rods get the full value below, not this.
            self.mat_A.set(round(self.show('area', A), 2))
            self.mat_I.set(round(self.show('inertia', I), 1))
        rods, phrase = self._material_target()
        if not rods:
            self.status_var.set(
                '%s — A = %s, I = %s (strong axis). It is what the next '
                'rod will be drawn with; select rods to put it on them.'
                % (name, self.fmt('area', A), self.fmt('inertia', I)))
            return
        self._apply_section_to_rods(name, self.PRESET_STEEL, rods, phrase)

    def _section_AI(self, name):
        """(A, I) of a catalogue section, in this tab's cm2 / cm4."""
        try:
            from apps.stereo import stereo_profiles as sp
            props = sp.section_to_props(sp.CATALOG[name],
                                        sp.MATERIALS[self.PRESET_STEEL])
            return props['A'], props['I']
        except Exception:
            return None, None

    def _apply_section_to_rods(self, section_name, material_name, rods,
                               phrase=None):
        """Give `rods` a catalogue section, families and all.

        WHY THIS IS NOT A ONE-LINER. A section lives on a FAMILY in this
        tab, not on a rod: the rod carries E, A and I, and the family
        carries Fy, Fu and the radius of gyration the check needs. So
        putting a section on three of the seven rods of the "Default"
        family cannot just write it onto "Default" -- that would silently
        re-section the other four as well.

          * the selection IS a whole family  -> that family takes it, and
            no new family appears for nothing;
          * the selection is part of one      -> the selected rods move
            into a family of their own, named after the section.
        """
        from apps.stereo import stereo_profiles as sp
        if not rods:
            return
        if phrase is None:
            _r, phrase = self._material_target()
        self._push_undo('steel section')
        chosen = set(rods)
        families = {self.rods[ri].get('profile', 'Default') for ri in chosen}
        whole = len(families) == 1 and not any(
            i not in chosen
            for i, r in enumerate(self.rods)
            if r.get('profile', 'Default') in families)
        if whole:
            family = next(iter(families))
            moved = ''
        else:
            family = self._free_family_name(section_name)
            for ri in chosen:
                self.rods[ri]['profile'] = family
            moved = ' in a new family "%s"' % family
        props = sp.section_to_props(sp.CATALOG[section_name],
                                    sp.MATERIALS[material_name])
        prof = self.profiles.setdefault(family, {})
        prof.update({k: props[k] for k in ('E', 'A', 'I', 'Fy', 'Fu',
                                           'r_gyr', 'c_cm')})
        prof.update(catalog=section_name, material=material_name)
        for ri in chosen:
            self.rods[ri].update(E=prof['E'], A=prof['A'], I=prof['I'])
        self._refresh_profile_combo()
        self.active_profile.set(family)
        self._after_section_change(
            '%s, %s on %s%s — A = %s, I = %s.'
            % (section_name, material_name, phrase, moved,
               self.fmt('area', prof['A']), self.fmt('inertia', prof['I'])))

    def _rod_section_name(self, ri):
        """What a rod is made of, in one phrase for the Selection box."""
        try:
            rod = self.rods[ri]
        except (IndexError, TypeError):
            return '—'
        prof = self.profiles.get(rod.get('profile', 'Default'), {})
        cat = prof.get('catalog')
        if cat:
            # A rod carries its own E, A and I; its FAMILY carries the
            # section. Hand-typing an area over a catalogue section leaves
            # the two disagreeing, and the check would then pair that area
            # with the catalogue's radius of gyration. The app allows it --
            # overriding one number of a section is a legitimate thing to
            # try -- so the Selection box says it out loud instead.
            pa = prof.get('A')
            if pa and abs(rod.get('A', pa) - pa) > 1e-6 * max(abs(pa), 1.0):
                return '%s (A overridden)' % cat
            return cat
        # No catalogue section is not a detail: it is the reason that rod
        # has no utilisation, so the Selection box says it rather than
        # leaving a blank the reader has to interpret.
        return 'none (A and I only — not checked)'

    def _free_family_name(self, base):
        """`base`, or "base (2)", "base (3)"... -- never an existing one."""
        if base not in self.profiles:
            return base
        n = 2
        while '%s (%d)' % (base, n) in self.profiles:
            n += 1
        return '%s (%d)' % (base, n)

    def _show_results_placeholder(self):
        """"Nothing solved yet" shows only while that is true."""
        boxes = (getattr(self, 'rod_res_frame', None),
                 getattr(self, 'rxn_frame', None),
                 getattr(self, 'plate_res_frame', None))
        has = any(b is not None and b.winfo_manager() for b in boxes)
        ph = getattr(self, 'res_placeholder', None)
        if ph is None:
            return
        try:
            if has:
                ph.pack_forget()
            elif not ph.winfo_manager():
                ph.pack(fill='x', padx=12, pady=(10, 4),
                        before=self.rod_res_frame)
        except Exception:
            pass

    # ── the mode cards ────────────────────────────────────────────────────
    def _build_mode_card(self, parent, title, tools, hint, extra=None):
        """The box at the top of a mode: its tools, and what to do.

        The tool buttons are the SAME tools as the toolbar's -- they set
        `self.tool` and light up with it -- not a second set that could
        disagree. They are repeated here because the toolbar says what
        the tab can do and the panel says what THIS mode is for, and a
        beginner reads the panel.
        """
        card = tk.LabelFrame(parent, text=title, bg='#f0f0ee',
                             font=('Helvetica', 10, 'bold'), padx=6, pady=4)
        card.pack(fill='x', padx=8, pady=(8, 4))
        if not hasattr(self, '_mode_cards'):
            self._mode_cards = {}
        row = tk.Frame(card, bg='#f0f0ee')
        row.pack(fill='x')
        for key, label, tip in tools:
            b = tk.Button(row, text=label, relief='flat', bd=0, padx=10,
                          pady=5, font=('Helvetica', 10, 'bold'),
                          command=lambda v=key: self._set_tool(v))
            b.pack(side='left', padx=(0, 4))
            self.mode_tool_btns[key] = b
            self._bind_widget_tooltip(b, tip)
        tk.Label(card, text=hint, bg='#f0f0ee', fg='#666',
                 font=('Helvetica', 8), justify='left', anchor='w',
                 wraplength=PANEL_W - 55).pack(fill='x', pady=(4, 0))
        # Keyed by the FIRST tool, which is the mode's own: the support
        # picker is packed into this card after the fact.
        self._mode_cards[tools[0][0] if tools else title] = card
        if extra is not None:
            extra(card)
        return card

    def _build_card_extra(self, card):
        """Build mode's card also carries the two things you reach for
        straight after drawing: the grid step you are snapping to, and a
        way to undo a wrong joint without hunting for the key."""
        row = tk.Frame(card, bg='#f0f0ee')
        row.pack(fill='x', pady=(6, 0))
        tk.Button(row, text='Delete selected', relief='flat',
                  font=('Helvetica', 9),
                  command=self._on_delete).pack(side='left')
        tk.Button(row, text='Clear all', relief='flat',
                  font=('Helvetica', 9),
                  command=self._clear_all).pack(side='left', padx=(4, 0))
        tk.Label(card, text='The grid is 1 m. Advanced tools adds the CAD '
                            'bar above the drawing: exact coordinates, '
                            'polar entry, construction geometry and arrays.',
                 bg='#f0f0ee', fg='#666', font=('Helvetica', 8),
                 justify='left', anchor='w',
                 wraplength=PANEL_W - 55).pack(fill='x', pady=(4, 0))

    def _refresh_tool_buttons(self):
        act = self.tool.get()
        for k, b in self.tool_btns.items():
            b.configure(bg='#1a6bbd' if k==act else '#ebebea',
                        fg='white'   if k==act else '#333333')
        # The panel's copies of the same tools, lit the same way.
        for k, b in getattr(self, 'mode_tool_btns', {}).items():
            b.configure(bg='#1a6bbd' if k == act else '#dfe3e6',
                        fg='white' if k == act else '#333333')

    def _reset_view(self):
        self.zc.reset_view()
        self.diag_zc.reset_view()
        self._draw()
        if self.diagrams: self._draw_diagrams_only()

    # ══════════════════════════════════════════════════════════════════════════
    #  Canvas interaction  (clicks in screen space → convert to world)
    # ══════════════════════════════════════════════════════════════════════════
    def _on_press(self, event):
        sx, sy = event.x, event.y
        wx, wy = self.zc.s2w(sx, sy)
        self._press_sx, self._press_sy = sx, sy
        self._press_wx, self._press_wy = wx, wy
        self._dragging_box = False
        self._box_cur = None
        t = self.tool.get()

        # ── pan ───────────────────────────────────────────────────────────
        # The Pan tool, or space held down from any tool. ZoomCanvas has
        # always panned on the MIDDLE button, which most laptop trackpads
        # and plenty of mice do not have at all -- on those, the view simply
        # could not be moved. Both routes reuse ZoomCanvas's own pan so
        # there is one implementation of it.
        if t == 'pan' or self._space_pan:
            self.zc._pan_start(event)
            return

        # ── polar ref pick mode ───────────────────────────────────────────
        if self._picking_ref:
            ni = near_node(self.nodes, wx, wy, thr=18/self.zc.zoom)
            if ni >= 0:
                self._polar_ref_node = ni
                nm_x, nm_y = self._world_to_metres(
                    self.nodes[ni][0], self.nodes[ni][1])
                self.polar_ref_var.set(f'N{ni} ({nm_x:.2f},{nm_y:.2f})')
                self.status_var.set(
                    f'Polar reference set to node {ni}. '
                    f'Enter distance + angle then click "Place node".')
            else:
                self.status_var.set('No node found — click closer to a node.')
            self._picking_ref = False
            return

        # ── ruler click ───────────────────────────────────────────────────
        if self._conic_pick_click(wx, wy):
            return

        # A guide or one of its handles takes the click before anything
        # else, so a reference line can be grabbed even where it crosses the
        # structure. Nodes still win when the cursor is on one, because the
        # node hit-test below runs first for the drawing tools.
        if self.tool.get() == 'select' and not self._picking_ref                 and not self.ruler_active.get():
            gi, hi = self._guide_hit_at(wx, wy)
            if gi is not None and near_node(
                    self.nodes, wx, wy, thr=14 / max(self.zc.zoom, 1e-6)) < 0:
                self._begin_guide_drag(gi, hi, wx, wy)
                self._draw()
                return

        # Pressing on an already-selected node drags the whole selection.
        # Anywhere else still starts a box, so the two never compete: you can
        # only move what you have already chosen to move.
        if (self.tool.get() == 'select' and self.selected_nodes
                and not self._picking_ref and not self.ruler_active.get()):
            hit = near_node(self.nodes, wx, wy, thr=14 / max(self.zc.zoom, 1e-6))
            if hit in self.selected_nodes:
                self._moving_sel = True
                self._move_from = (wx, wy)
                self._move_orig = {i: tuple(self.nodes[i])
                                    for i in self.selected_nodes
                                    if 0 <= i < len(self.nodes)}
                self.status_var.set('Moving %d node(s) — release to drop, '
                                    'Ctrl+Z undoes.' % len(self._move_orig))
                return

        if self.ruler_active.get():
            gx, gy = self._compute_ghost(wx, wy)
            if self.ruler_start is None:
                self.ruler_start = (gx, gy)
                mx, my = self._world_to_metres(gx, gy)
                self.ruler_label.configure(text='measuring…')
                self.status_var.set(
                    f'Ruler start: ({mx:.3f}, {my:.3f}) m — click end point')
            else:
                rx, ry = self.ruler_start
                dm  = math.hypot((gx-rx)/PX_PER_M, (gy-ry)/PX_PER_M)
                ang = math.degrees(math.atan2(-(gy-ry), gx-rx))
                mx0,my0 = self._world_to_metres(rx, ry)
                mx1,my1 = self._world_to_metres(gx, gy)
                self.ruler_label.configure(
                    text=f'd={dm:.4f} m  α={ang:.2f}°')
                self.status_var.set(
                    f'Ruler: ({mx0:.3f},{my0:.3f}) → ({mx1:.3f},{my1:.3f})'
                    f'  dist={dm:.4f} m  angle={ang:.2f}°')
                self.ruler_start = None   # reset for next measurement
            self._draw()
            return

        # 'node' and 'rod' tools act immediately on press — a drag doesn't
        # make sense for either, so their behaviour is unchanged.
        if t == 'node':
            self.results = None; self.diagrams = None
            self._draw_diagrams_only()
            gx, gy = self._compute_ghost(wx, wy)
            self._push_undo('place node')
            self.nodes.append((gx, gy))
            mx, my = self._world_to_metres(gx, gy)
            self._draw()
            self.status_var.set(
                f'Node {len(self.nodes)-1} placed at ({mx:.3f}, {my:.3f}) m')
            return

        if t == 'rod':
            self.results = None; self.diagrams = None
            self._draw_diagrams_only()
            ni = near_node(self.nodes, wx, wy, 14/self.zc.zoom)
            if ni < 0:
                self.status_var.set('Click on an existing node'); return
            if self.rod_start is None:
                self.rod_start = ni; self._draw()
                nm_x,nm_y = self._world_to_metres(
                    self.nodes[ni][0], self.nodes[ni][1])
                self.status_var.set(
                    f'Rod from node {ni} ({nm_x:.3f},{nm_y:.3f}) m — click second node')
                return
            if self.rod_start == ni:
                self.rod_start = None; self._draw(); return
            dup = any((r['a']==self.rod_start and r['b']==ni) or
                      (r['a']==ni and r['b']==self.rod_start) for r in self.rods)
            if not dup:
                self._push_undo('draw rod')
                self.rods.append({'a':self.rod_start,'b':ni,
                                  'E':self.unit_value(self.mat_E),
                                  'A':self.unit_value(self.mat_A),
                                  'I':self.unit_value(self.mat_I),'conn':'pin','udl':0.0,
                                  'udl_rotation_deg':0.0,
                                  'point_loads':[],
                                  'profile':'Default'})
                na = self.nodes[self.rod_start]; nb = self.nodes[ni]
                L_m = math.hypot(nb[0]-na[0],nb[1]-na[1])/PX_PER_M
                ang = math.degrees(math.atan2(-(nb[1]-na[1]),nb[0]-na[0]))
                self.status_var.set(
                    f'Rod {len(self.rods)-1} added: L={L_m:.4f} m  α={ang:.2f}°')
            self.rod_start = None; self._draw()
            if dup: self.status_var.set('Rod already exists.')
            return

        # 'select', 'load', 'support' → decided in _on_release (click vs box-drag)

    def _on_drag_motion(self, event):
        if self.tool.get() == 'pan' or self._space_pan:
            self.zc._pan_move(event)
            return
        if self._guide_drag:
            wx, wy = self.zc.s2w(event.x, event.y)
            self._drag_guide_to(wx, wy)
            return
        if self._moving_sel and self._move_orig is not None:
            wx, wy = self.zc.s2w(event.x, event.y)
            # Snap the CURSOR, then apply that offset to every selected node,
            # so the whole selection keeps its shape and one node lands
            # exactly on the grid/node the cursor snapped to. Snapping each
            # node independently would distort the selection.
            gx, gy = self._compute_ghost(wx, wy)
            dx = gx - self._move_from[0]
            dy = gy - self._move_from[1]
            for i, (ox, oy) in self._move_orig.items():
                self.nodes[i] = (ox + dx, oy + dy)
            self._draw()
            return
        if self.tool.get() not in ('select','load','support'):
            return
        if self._press_sx is None:
            return
        dx = event.x - self._press_sx; dy = event.y - self._press_sy
        if math.hypot(dx, dy) > 4:
            self._dragging_box = True
        self._box_cur = self.zc.s2w(event.x, event.y)
        self._draw()

    def _on_release(self, event):
        if self.tool.get() == 'pan' or self._space_pan:
            self.zc._pan_end(event)
            try:
                self.zc.canvas.configure(
                    cursor='fleur' if (self.tool.get() == 'pan'
                                       or self._space_pan) else 'crosshair')
            except Exception:
                pass
            return
        if self._guide_drag:
            self._end_guide_drag()
            return
        if self._moving_sel:
            moved = self._move_orig or {}
            dx = dy = 0.0
            if moved:
                i0 = next(iter(moved))
                dx = self.nodes[i0][0] - moved[i0][0]
                dy = self.nodes[i0][1] - moved[i0][1]
            self._moving_sel = False
            self._move_from = None
            orig, self._move_orig = moved, None
            if abs(dx) < 1e-9 and abs(dy) < 1e-9:
                self._draw()
                return
            # Push the BEFORE state, then re-apply the move on top of it, so
            # one Ctrl+Z returns the selection to where it started rather
            # than to some intermediate position from the drag.
            for i, xy in orig.items():
                self.nodes[i] = xy
            self._push_undo('move selection')
            for i, (ox, oy) in orig.items():
                self.nodes[i] = (ox + dx, oy + dy)
            self._invalidate_results()
            self._show_sel(); self._draw(); self._draw_diagrams_only()
            self.status_var.set('Moved %d node(s) by (%.3f, %.3f) m.'
                                % (len(orig), dx / PX_PER_M, -dy / PX_PER_M))
            return
        t = self.tool.get()
        if t not in ('select','load','support'):
            self._press_sx = self._press_sy = None
            return
        if self._press_wx is None:
            return
        shift = bool(event.state & 0x0001)   # Shift held → "piece" accumulate

        if self._dragging_box and self._box_cur is not None:
            wx0, wy0 = self._press_wx, self._press_wy
            wx1, wy1 = self._box_cur
            node_ids = set(self._nodes_in_box(wx0, wy0, wx1, wy1))
            if t == 'select':
                rod_ids = set(self._rods_in_box(wx0, wy0, wx1, wy1))
                if shift:
                    self.selected_nodes |= node_ids
                    self.selected_rods  |= rod_ids
                else:
                    self.selected_nodes = node_ids
                    self.selected_rods  = rod_ids
                self.status_var.set(
                    f'Box-selected {len(node_ids)} node(s), {len(rod_ids)} rod(s) '
                    f'[{len(self.selected_nodes)} / {len(self.selected_rods)} total].')
                self._show_sel()
            elif t == 'load':
                self.pending_load = (self.pending_load | node_ids) if shift else node_ids
                self.load_frame['text'] = f'Load on {len(self.pending_load)} node(s)'
                self.sup_frame.pack_forget()
                self.load_frame.pack(fill='x', padx=8, pady=4)
                self.status_var.set(f'{len(self.pending_load)} node(s) selected for load →')
            elif t == 'support':
                self.pending_sup = (self.pending_sup | node_ids) if shift else node_ids
                self.sup_frame['text'] = f'Support on {len(self.pending_sup)} node(s)'
                self.load_frame.pack_forget()
                self.sup_frame.pack(fill='x', padx=8, pady=4)
                self.status_var.set(f'{len(self.pending_sup)} node(s) selected for support →')
            self.zc.canvas.focus_set()
        else:
            wx, wy = self._press_wx, self._press_wy
            if t == 'select':
                ni = near_node(self.nodes, wx, wy, 16/self.zc.zoom)
                if ni >= 0:
                    if shift:
                        if ni in self.selected_nodes: self.selected_nodes.discard(ni)
                        else: self.selected_nodes.add(ni)
                    else:
                        self.selected_nodes = {ni}; self.selected_rods = set()
                    self.zc.canvas.focus_set(); self._show_sel()
                    if (not shift and self.show_load_path.get()
                            and ni in self._traceable_loads()):
                        self._trace_load_at(ni)    # draws
                    else:
                        self._draw()
                    self._press_sx=self._press_sy=None; self._dragging_box=False
                    return
                ri = near_rod(self.nodes, self.rods, wx, wy, 7/self.zc.zoom)
                if ri >= 0:
                    if shift:
                        if ri in self.selected_rods: self.selected_rods.discard(ri)
                        else: self.selected_rods.add(ri)
                    else:
                        self.selected_rods = {ri}; self.selected_nodes = set()
                elif not shift:
                    self.selected_nodes = set(); self.selected_rods = set()
                self.zc.canvas.focus_set(); self._show_sel()

            elif t == 'support':
                ni = near_node(self.nodes, wx, wy, 14/self.zc.zoom)
                if ni < 0:
                    self.status_var.set('Click on a node (or drag a box) to assign support')
                else:
                    self.pending_sup = (self.pending_sup | {ni}) if shift else {ni}
                    self.sup_frame['text'] = f'Support on {len(self.pending_sup)} node(s)'
                    if len(self.pending_sup) == 1:
                        ex = next((s for s in self.supports if s['node']==ni), None)
                        if ex:
                            self.sup_type.set(ex['type'])
                            # the symbol picker is the control now, so it
                            # has to show what this node already has
                            self._refresh_support_picker()
                    self.load_frame.pack_forget()
                    self.sup_frame.pack(fill='x', padx=8, pady=4)
                    self.status_var.set(f'Configure support for {len(self.pending_sup)} node(s) →')

            elif t == 'load':
                ni = near_node(self.nodes, wx, wy, 14/self.zc.zoom)
                if ni < 0:
                    self.status_var.set('Click on a node (or drag a box) to assign load')
                else:
                    self.pending_load = (self.pending_load | {ni}) if shift else {ni}
                    self.load_frame['text'] = f'Load on {len(self.pending_load)} node(s)'
                    if len(self.pending_load) == 1:
                        ex = next((l for l in self.loads if l['node']==ni), None)
                        # Seeded from the MODEL, which is in kN, so it goes
                        # in through set_unit_value or the box would read kN
                        # under a label saying kip.
                        self.set_unit_value(self.led_fx, ex['fx'] if ex else 0.0)
                        self.set_unit_value(self.led_fy, ex['fy'] if ex else 10.0)
                    self.sup_frame.pack_forget()
                    self.load_frame.pack(fill='x', padx=8, pady=4)
                    self.status_var.set(f'Set load for {len(self.pending_load)} node(s) →')

        self._press_sx = self._press_sy = None
        self._dragging_box = False
        self._box_cur = None
        self._draw()

    def _nodes_in_box(self, wx0, wy0, wx1, wy1):
        xlo, xhi = sorted((wx0, wx1)); ylo, yhi = sorted((wy0, wy1))
        return [i for i,(nx,ny) in enumerate(self.nodes)
                if xlo <= nx <= xhi and ylo <= ny <= yhi]

    def _rods_in_box(self, wx0, wy0, wx1, wy1):
        xlo, xhi = sorted((wx0, wx1)); ylo, yhi = sorted((wy0, wy1))
        ids = []
        for i, rod in enumerate(self.rods):
            na, nb = self.nodes[rod['a']], self.nodes[rod['b']]
            if (xlo<=na[0]<=xhi and ylo<=na[1]<=yhi and
                xlo<=nb[0]<=xhi and ylo<=nb[1]<=yhi):
                ids.append(i)
        return ids

    def _on_delete(self, event):
        self._push_undo('delete')
        if not self.selected_nodes and not self.selected_rods: return

        # delete explicitly-selected rods first (by value, not stale index)
        rods_to_remove = [self.rods[ri] for ri in self.selected_rods
                           if 0 <= ri < len(self.rods)]
        for r in rods_to_remove:
            if r in self.rods: self.rods.remove(r)

        # delete nodes, highest index first so remaining indices stay valid
        for ni in sorted(self.selected_nodes, reverse=True):
            # Plates FIRST, while `ni` still means what it meant when the
            # plate was created. Node identity in this tab is the list index
            # (Cable Web moved to stable ids precisely to avoid this -- see
            # MANIFESTO sec 1.3 -- but the Truss tab did not), so every index
            # above a deleted node shifts down by one and a plate that is not
            # remapped here goes on referring to the same NUMBERS while those
            # numbers now mean different nodes. That is silent corruption, not
            # a crash, which is why it gets its own test.
            self.plates = [pl for pl in self.plates
                            if ni not in self._plate_node_ids(pl)]
            for pl in self.plates:
                if pl.get('kind') == 'gusset':
                    if pl['node'] > ni: pl['node'] -= 1
                else:
                    pl['nodes'] = [n-1 if n > ni else n for n in pl['nodes']]
            self.rods = [r for r in self.rods if r['a']!=ni and r['b']!=ni]
            self.rods = [{**r,'a':r['a']-1 if r['a']>ni else r['a'],
                              'b':r['b']-1 if r['b']>ni else r['b']} for r in self.rods]
            self.loads = [l for l in self.loads if l['node']!=ni]
            self.loads = [{**l,'node':l['node']-1 if l['node']>ni else l['node']}
                          for l in self.loads]
            self.supports = [s for s in self.supports if s['node']!=ni]
            self.supports = [{**s,'node':s['node']-1 if s['node']>ni else s['node']}
                             for s in self.supports]
            self.nodes.pop(ni)

        # A panel whose bay no longer has all four rods is no longer that
        # panel; drop it rather than leave a plate spanning open air.
        self.plates = [pl for pl in self.plates if self._plate_still_bounded(pl)]

        n_nodes, n_rods = len(self.selected_nodes), len(self.selected_rods)
        self.selected_nodes = set(); self.selected_rods = set()
        # Any node indices staged in the Load/Support panels are now stale
        # (deletion shifts every index above a removed node down by one, and
        # a staged node may have been removed outright) -- carrying them
        # forward could silently apply a load/support to the wrong node, or
        # reference a node index that no longer exists. Safest fix: drop the
        # staged selection and let the user re-pick, which is one click.
        if self.pending_load or self.pending_sup:
            self.pending_load = set(); self.pending_sup = set()
            self.load_frame['text'] = 'Load on 0 node(s)'
            self.sup_frame['text']  = 'Support on 0 node(s)'
            self.load_frame.pack_forget(); self.sup_frame.pack_forget()
        self.results=None; self.diagrams=None
        self._draw_diagrams_only()
        self._show_sel(); self._draw()
        self.status_var.set(f'Deleted {n_nodes} node(s), {n_rods} rod(s).')

    # ══════════════════════════════════════════════════════════════════════════
    #  Load / support panel actions
    # ══════════════════════════════════════════════════════════════════════════
    def _apply_load(self):
        ids = self.pending_load
        if not ids:
            self.status_var.set('Pick a node with the Load tool first.')
            return
        self._push_undo('apply load')
        fx = self.unit_value(self.led_fx)
        fy = self.unit_value(self.led_fy)
        for ni in ids:
            idx = next((i for i,l in enumerate(self.loads) if l['node']==ni), -1)
            if idx >= 0: self.loads[idx] = {'node':ni,'fx':fx,'fy':fy}
            else:        self.loads.append({'node':ni,'fx':fx,'fy':fy})
        self.results=None; self.diagrams=None; self._draw(); self._draw_diagrams_only()
        self.status_var.set(
            f'Load applied to {len(ids)} node(s): '
            f'Fx={self.show("force", fx):g} Fy={self.show("force", fy):g} '
            f'{self.u("force")}')

    def _remove_load(self):
        ids = self.pending_load
        if not ids:
            self.status_var.set('Pick a node with the Load tool first.')
            return
        self._push_undo('remove load')
        self.loads=[l for l in self.loads if l['node'] not in ids]
        self.results=None; self.diagrams=None; self.load_frame.pack_forget(); self._draw(); self._draw_diagrams_only()

    def _apply_support(self):
        ids = self.pending_sup
        if not ids:
            self.status_var.set('Pick a node with the Support tool first.')
            return
        self._push_undo('apply support')
        stype=self.sup_type.get()
        for ni in ids:
            idx=next((i for i,s in enumerate(self.supports) if s['node']==ni),-1)
            if idx>=0: self.supports[idx]={'node':ni,'type':stype}
            else:      self.supports.append({'node':ni,'type':stype})
        self.results=None; self.diagrams=None; self._draw(); self._draw_diagrams_only()
        self.status_var.set(f'Support "{stype}" applied to {len(ids)} node(s)')

    def _remove_support(self):
        ids = self.pending_sup
        if not ids:
            self.status_var.set('Pick a node with the Support tool first.')
            return
        self._push_undo('remove support')
        self.supports=[s for s in self.supports if s['node'] not in ids]
        self.results=None; self.diagrams=None; self.sup_frame.pack_forget(); self._draw(); self._draw_diagrams_only()

    # ══════════════════════════════════════════════════════════════════════════
    #  Rod family / profile management
    # ══════════════════════════════════════════════════════════════════════════
    def _refresh_profile_combo(self):
        names = sorted(self.profiles.keys())
        if hasattr(self, 'family_combo'):
            self.family_combo['values'] = names
        if self.active_profile.get() not in names and names:
            self.active_profile.set(names[0])

    def _assign_profile_to_selection(self):
        self._push_undo('assign profile')
        if not self.selected_rods:
            messagebox.showinfo('Rod family',
                'Select one or more rods first (click, shift-click, or box-select '
                'with the Select tool), then apply a profile.')
            return
        name = self.active_profile.get()
        prof = self.profiles.get(name)
        if not prof:
            messagebox.showwarning('Rod family', f'Profile "{name}" not found.'); return
        for ri in self.selected_rods:
            self.rods[ri]['profile'] = name
            self.rods[ri]['E'] = prof['E']
            self.rods[ri]['A'] = prof['A']
            self.rods[ri]['I'] = prof.get('I', 8000.0)
        self.results = None; self.diagrams = None
        self._draw_diagrams_only()
        self._draw(); self._show_sel()
        self.status_var.set(f'Assigned family "{name}" to {len(self.selected_rods)} rod(s).')

    def _set_connection_type(self, conn):
        self._push_undo('connection type')
        if not self.selected_rods:
            messagebox.showinfo('Connection type',
                'Select one or more rods first (click, shift-click, or drag a '
                'selection box), then set Rigid or Pinned.')
            return
        for ri in self.selected_rods:
            self.rods[ri]['conn'] = conn
        self.results = None; self.diagrams = None
        self._draw_diagrams_only()
        self._draw(); self._show_sel()
        label = 'Rigid (moment connection)' if conn == 'rigid' else 'Pinned (axial only)'
        self.status_var.set(f'Set {len(self.selected_rods)} rod(s) to {label}.')

    def _sync_udl_angle(self):
        # Radio buttons are shortcuts; the numeric field/slider remains the
        # authoritative angle so arbitrary rotations can be entered.
        self._draw()

    def _apply_udl(self):
        self._push_undo('apply UDL')
        if not self.selected_rods:
            messagebox.showinfo('Distributed load',
                'Select one or more rods first (click, shift-click, or drag a '
                'selection box), then apply a UDL.')
            return
        w = self.unit_value(self.udl_var)
        angle = float(self.udl_rotation_var.get())
        n_converted = 0
        for ri in self.selected_rods:
            if self.rods[ri].get('conn') != 'rigid':
                self.rods[ri]['conn'] = 'rigid'
                n_converted += 1
            self.rods[ri]['udl'] = w
            self.rods[ri]['udl_rotation_deg'] = angle
        self.results = None; self.diagrams = None
        self._draw_diagrams_only()
        self._draw(); self._show_sel()
        direction = 'perpendicular to rod' if abs(angle) < 1e-12 else f'rotated {angle:g}° from perpendicular'
        msg = (f'Applied {self.fmt("line_load", w)} ({direction}) to '
               f'{len(self.selected_rods)} rod(s).')
        if n_converted:
            msg += f' ({n_converted} auto-set to Rigid.)'
        self.status_var.set(msg)

    def _clear_udl(self):
        self._push_undo('clear UDL')
        if not self.selected_rods:
            messagebox.showinfo('Distributed load', 'Select one or more rods first.')
            return
        for ri in self.selected_rods:
            self.rods[ri]['udl'] = 0.0
            self.rods[ri]['udl_rotation_deg'] = 0.0
        self.results = None; self.diagrams = None
        self._draw_diagrams_only()
        self._draw(); self._show_sel()
        self.status_var.set(f'Cleared UDL on {len(self.selected_rods)} rod(s).')

    def _apply_point_load(self):
        self._push_undo('add point load')
        if not self.selected_rods:
            messagebox.showinfo('Point load',
                'Select one or more rods first, then add a point load.')
            return
        P = self.unit_value(self.pload_var)
        pos = self.pload_pos_var.get()
        angle = self.pload_angle_var.get()
        if not (0.0 <= pos <= 100.0):
            messagebox.showerror('Point load', 'Position must be between 0% and 100% from end A.')
            return
        n_converted = 0
        for ri in self.selected_rods:
            if self.rods[ri].get('conn') != 'rigid':
                self.rods[ri]['conn'] = 'rigid'
                n_converted += 1
            self.rods[ri].setdefault('point_loads', []).append({
                'P': P, 't': pos/100.0, 'angle_deg': angle
            })
        self.results = None; self.diagrams = None
        self._draw_diagrams_only()
        self._draw(); self._show_sel()
        msg = f'Added {P:g} kN point load at {pos:g}% from A ({angle:g}°) to {len(self.selected_rods)} rod(s).'
        if n_converted:
            msg += f' ({n_converted} auto-set to Rigid.)'
        self.status_var.set(msg)

    def _clear_point_loads(self):
        self._push_undo('clear point loads')
        if not self.selected_rods:
            messagebox.showinfo('Point load', 'Select one or more rods first.')
            return
        for ri in self.selected_rods:
            self.rods[ri]['point_loads'] = []
        self.results = None; self.diagrams = None
        self._draw_diagrams_only()
        self._draw(); self._show_sel()
        self.status_var.set(f'Cleared point loads on {len(self.selected_rods)} rod(s).')

    def _select_same_family(self):
        if len(self.selected_rods) != 1:
            messagebox.showinfo('Rod family',
                'Select exactly one rod first, then use this to grab the rest of its family.')
            return
        ri = next(iter(self.selected_rods))
        name = self.rods[ri].get('profile', 'Default')
        self.selected_rods = {i for i,r in enumerate(self.rods)
                              if r.get('profile','Default') == name}
        self.selected_nodes = set()
        self._show_sel(); self._draw()
        self.status_var.set(f'Selected {len(self.selected_rods)} rod(s) in family "{name}".')

    def _open_profile_manager(self):
        win = tk.Toplevel(self.root)
        win.title('Profile / Family Manager')
        win.geometry('400x500')
        win.configure(bg='#f5f5f3')
        tk.Label(win, text='Profile / Family Manager', bg='#f5f5f3',
                 font=('Helvetica',12,'bold'), fg='#1a6bbd').pack(pady=(10,4))
        tk.Label(win,
                 text='A "family" is just a named profile (E, A, I) shared by\n'
                      'every rod tagged with it. Editing a profile here updates\n'
                      'every rod currently assigned to it, all at once. I only\n'
                      'matters for rods set to "Rigid".',
                 bg='#f5f5f3', fg='#555', font=('Helvetica',9),
                 justify='center').pack(pady=(0,8))

        listfr = tk.Frame(win, bg='#f5f5f3'); listfr.pack(fill='both', expand=True, padx=10)
        lb = tk.Listbox(listfr, font=('Helvetica',10), height=10)
        lb.pack(side='left', fill='both', expand=True)
        sb = tk.Scrollbar(listfr, orient='vertical', command=lb.yview)
        sb.pack(side='right', fill='y')
        lb.configure(yscrollcommand=sb.set)

        def refresh_list():
            lb.delete(0, 'end')
            for name in sorted(self.profiles.keys()):
                p = self.profiles[name]
                n_members = sum(1 for r in self.rods if r.get('profile','Default')==name)
                sec = (f'{p["catalog"]}, ' if p.get('catalog') else '')
                lb.insert('end',
                          f'{name}   ({sec}E={self.fmt("modulus", p["E"])}, '
                          f'A={self.fmt("area", p["A"])}, '
                          f'I={self.fmt("inertia", p.get("I", 8000.0))}, '
                          f'{n_members} rod(s))')
        refresh_list()

        editfr = tk.Frame(win, bg='#f5f5f3'); editfr.pack(fill='x', padx=10, pady=8)
        tk.Label(editfr, text='Name:', bg='#f5f5f3', font=('Helvetica',9)).grid(row=0,column=0,sticky='w')
        name_var = tk.StringVar(value='Default')
        tk.Entry(editfr, textvariable=name_var, width=16, font=('Helvetica',9)).grid(row=0,column=1,padx=4)
        tk.Label(editfr, text=f'E ({self.u("modulus")}):', bg='#f5f5f3',
                 font=('Helvetica',9)).grid(row=1,column=0,sticky='w')
        e_var = tk.DoubleVar(value=self.show('modulus', 200.0))
        tk.Entry(editfr, textvariable=e_var, width=10, font=('Helvetica',9)).grid(row=1,column=1,padx=4)
        tk.Label(editfr, text=f'A ({self.u("area")}):', bg='#f5f5f3',
                 font=('Helvetica',9)).grid(row=2,column=0,sticky='w')
        a_var = tk.DoubleVar(value=self.show('area', 10.0))
        tk.Entry(editfr, textvariable=a_var, width=10, font=('Helvetica',9)).grid(row=2,column=1,padx=4)
        tk.Label(editfr, text=f'I ({self.u("inertia")}, rigid only):', bg='#f5f5f3',
                 font=('Helvetica',9)).grid(row=3,column=0,sticky='w')
        i_var = tk.DoubleVar(value=self.show('inertia', 8000.0))
        tk.Entry(editfr, textvariable=i_var, width=10, font=('Helvetica',9)).grid(row=3,column=1,padx=4)

        def on_select(_e=None):
            sel = lb.curselection()
            if not sel: return
            name = sorted(self.profiles.keys())[sel[0]]
            name_var.set(name)
            e_var.set(self.profiles[name]['E'])
            a_var.set(self.profiles[name]['A'])
            i_var.set(self.profiles[name].get('I', 8000.0))
        lb.bind('<<ListboxSelect>>', on_select)

        def save_profile():
            name = name_var.get().strip()
            if not name:
                messagebox.showwarning('Rod family', 'Name cannot be empty.'); return
            old = self.profiles.get(name) or {}
            new = {'E': e_var.get(), 'A': a_var.get(), 'I': i_var.get()}
            # The steel grade is the material, kept whatever the size; the
            # catalogue section (r, depth, name) only while A and I are still
            # its own -- a radius of gyration left beside a new A would make
            # the buckling check unsafe.
            for k in ('Fy', 'Fu', 'material'):
                if k in old:
                    new[k] = old[k]
            same = (abs(old.get('A', -1) - new['A']) < 1e-9 and
                    abs(old.get('I', -1) - new['I']) < 1e-9)
            if same:
                for k in ('r_gyr', 'c_cm', 'catalog'):
                    if k in old:
                        new[k] = old[k]
            self.profiles[name] = new
            for r in self.rods:
                if r.get('profile','Default') == name:
                    r['E'] = e_var.get(); r['A'] = a_var.get(); r['I'] = i_var.get()
            self._refresh_profile_combo(); refresh_list()
            self.results = None; self.diagrams = None; self._draw(); self._draw_diagrams_only()
            n = sum(1 for r in self.rods if r.get('profile','Default')==name)
            self.status_var.set(f'Profile "{name}" saved ({n} rod(s) updated).')

        def delete_profile():
            name = name_var.get().strip()
            if name == 'Default':
                messagebox.showwarning('Rod family', 'Cannot delete the Default profile.'); return
            in_use = sum(1 for r in self.rods if r.get('profile','Default')==name)
            if in_use and not messagebox.askyesno('Rod family',
                    f'{in_use} rod(s) use "{name}". Reassign them to Default and delete?'):
                return
            for r in self.rods:
                if r.get('profile','Default') == name:
                    r['profile'] = 'Default'
                    r['E'] = self.profiles['Default']['E']
                    r['A'] = self.profiles['Default']['A']
                    r['I'] = self.profiles['Default'].get('I', 8000.0)
            self.profiles.pop(name, None)
            self._refresh_profile_combo(); refresh_list()
            self.results = None; self.diagrams = None; self._draw(); self._draw_diagrams_only()

        btnfr = tk.Frame(win, bg='#f5f5f3'); btnfr.pack(fill='x', padx=10, pady=4)
        tk.Button(btnfr, text='New / Save profile', bg='#1a6bbd', fg='white',
                  font=('Helvetica',9,'bold'), relief='flat',
                  command=save_profile).pack(side='left', padx=2)
        tk.Button(btnfr, text='Steel section…', relief='flat',
                  font=('Helvetica',9),
                  command=lambda: self._pick_steel_section(
                      name_var.get().strip() or 'Default',
                      on_done=refresh_list)).pack(side='left', padx=2)
        tk.Button(btnfr, text='Delete profile', relief='flat',
                  font=('Helvetica',9), command=delete_profile).pack(side='left', padx=2)
        tk.Button(win, text='Close', relief='flat', bg='#1a6bbd', fg='white',
                  font=('Helvetica',10,'bold'), command=win.destroy).pack(pady=(4,10))

    # ══════════════════════════════════════════════════════════════════════════
    #  Units
    # ══════════════════════════════════════════════════════════════════════════
    def _on_units_changed(self):
        """Repaint everything that writes a number or names a unit.

        The canvases are redrawn rather than edited in place: rod labels, load
        arrows and the Vierendeel diagrams all carry numbers, and hunting down
        each text item would be more fragile than drawing the picture again.
        """
        try:
            self._draw()
            self._draw_diagrams_only()
            if self.results:
                self._show_analysis_text()
                self._show_diagrams()
                self._show_plate_checks()
            if self.selected_nodes or self.selected_rods:
                self._show_sel()
        except Exception:
            # A repaint must never take the selector down with it; a stale
            # panel is recoverable, a dead callback chain is not.
            pass

    # ══════════════════════════════════════════════════════════════════════════
    #  Analysis
    # ══════════════════════════════════════════════════════════════════════════
    def _run_analysis(self, quiet=False):
        """Solve and show the results. `quiet` is the Live / sandbox path:
        no dialog boxes and no animation, only the status line."""
        warn = (lambda *a: None) if quiet else messagebox.showwarning
        if len(self.nodes)<2:
            warn('Truss','Need ≥ 2 nodes.'); return
        if len(self.rods)<1:
            warn('Truss','Need ≥ 1 rod.'); return
        supports = self._active_supports()
        if len(supports)<1:
            warn('Truss', 'Need ≥ 1 support.' if not self.supports else
                 'Every support is switched off -- right-click one to bring '
                 'it back.')
            return

        self._stop_mechanism()
        loads = self._design_loads()          # + self-weight, x Load %
        rods = self._design_rods()            # span loads x Load %
        res, err = analyze(self.nodes, rods, loads, supports,
                            self.plates)
        if err:
            why = None
            if err.startswith('Singular'):
                # Say WHERE it is a mechanism, and draw it moving.
                why = self._show_mechanism(quiet=quiet)
            if not quiet:
                messagebox.showerror('Analysis failed',
                                     err + ('\n\n' + why if why else ''))
            self.res_var.set(f'Failed: {err}')
            self.status_var.set('Analysis failed — ' + (why or err))
            return

        self.results  = res
        self.diagrams = compute_diagrams(self.nodes, rods, loads, res)
        self._compute_design(res)
        self.plate_checks = truss_plates.check_all(self.nodes, self.rods,
                                                    self.plates, res)

        self._show_analysis_text()
        design_note = self._design_summary()
        self._score_summary()
        self._show_plate_checks()

        self.show_deform.set(True)
        self._draw()
        self._show_diagrams()
        if not quiet:
            # Not on a Live re-solve: that runs on every edit, and a view
            # that jumps while you work is worse than one that needs Fit.
            self._fit_to_results()
        rr = res['rod_res']
        n_t=sum(1 for r in rr if r['force']>0.01)
        n_c=sum(1 for r in rr if r['force']<-0.01)
        n_z=len(rr)-n_t-n_c
        loaded = bool(self.loads) or self.self_weight.get() or any(
            r.get('udl') or r.get('point_loads') for r in self.rods)
        if not loaded:
            self.status_var.set(
                'Done — but no loads are applied, so every rod force is zero. '
                'Add one with the Load tool, then ▶ Analyze again.')
        else:
            zero = (f', {n_z} carry no force (dashed)' if n_z else '')
            off = (f' {len(self.disabled_supports)} support(s) switched off.'
                   if self.disabled_supports else '')
            self.status_var.set(
                f'{"Live: " if quiet else "Done — "}{n_t} tension, '
                f'{n_c} compression{zero}{self._load_note()}.{off}{design_note} '
                f'Reactions and diagrams shown. Scroll/zoom both canvases freely.')
        if self.selected_nodes or self.selected_rods: self._show_sel()
        if self.show_load_path.get():
            # An edit dropped the old trace (_invalidate_results); the
            # switch is still on, so trace the same load in the new solve.
            self._compute_load_path(announce=False)
            self._draw()

    def _show_analysis_text(self):
        """The three result panels, written in the selected convention.

        Split out of `_run_analysis` so a change of units repaints them from
        the results already in hand, without re-solving.
        """
        res = self.results
        if not res:
            return
        nr, rr, rxns = res['node_res'], res['rod_res'], res['reactions']
        max_t = max((r['force'] for r in rr), default=0)
        max_c = min((r['force'] for r in rr), default=0)
        max_d = max(math.hypot(r['ux'], r['uy']) for r in nr) if nr else 0

        F, MOM, D = self.u('force'), self.u('moment'), self.u('deflection')
        f_ = lambda v: self.show('force', v)
        m_ = lambda v: self.show('moment', v)

        self.res_var.set(
            f'Max tension:      {f_(max_t):.2f} {F}\n'
            f'Max compression:  {f_(abs(max_c)):.2f} {F}\n'
            f'Max displacement: {self.show("deflection", max_d):.3f} {D}')

        # rod table
        self.rod_res_text.configure(state='normal')
        self.rod_res_text.delete('1.0', 'end')
        for i, r in enumerate(rr):
            f = r['force']
            k = 'T' if f > 0.01 else ('C' if f < -0.01 else '0')
            if r.get('conn') == 'rigid':
                self.rod_res_text.insert('end',
                    f'Rod {i:2d} [rigid]: N={f_(f):+7.2f} [{k}]  V={f_(r["V"]):+7.2f}  '
                    f'Ma={m_(r["Ma"]):+7.2f}  Mb={m_(r["Mb"]):+7.2f} {MOM}'
                    f'{self._util_tag(i)}\n')
            else:
                self.rod_res_text.insert('end',
                                          f'Rod {i:2d}: {f_(f):+8.2f} {F} [{k}]'
                                          f'{self._util_tag(i)}\n')
        self.rod_res_text.configure(state='disabled')
        self.rod_res_frame.pack(fill='x', padx=8, pady=4)

        # reaction table
        self.rxn_text.configure(state='normal')
        self.rxn_text.delete('1.0', 'end')
        for ni, rxn in rxns.items():
            rx = f_(rxn.get('rx', 0)); ry = f_(rxn.get('ry', 0))
            if rxn.get('type') == 'fixed':
                self.rxn_text.insert('end',
                    f'Node {ni:2d} (fixed  ): '
                    f'Rx={rx:+7.2f}  Ry={ry:+7.2f}  '
                    f'M={m_(rxn.get("m", 0)):+7.2f} {MOM}\n')
            else:
                self.rxn_text.insert('end',
                    f'Node {ni:2d} ({rxn["type"]:7s}): '
                    f'Rx={rx:+7.2f}  Ry={ry:+7.2f} {F}\n')
        self.rxn_text.configure(state='disabled')
        self.rxn_frame.pack(fill='x', padx=8, pady=4)
        self._show_results_placeholder()

    # ══════════════════════════════════════════════════════════════════════════
    #  Selection panel
    # ══════════════════════════════════════════════════════════════════════════
    def _show_sel(self):
        # The Material-and-section box acts on the selection, so its button
        # has to be relabelled whenever the selection moves -- this is the
        # one function every selection change already passes through.
        self._refresh_material_target()
        t=self.sel_text
        t.configure(state='normal'); t.delete('1.0','end')
        n_sel_nodes = len(self.selected_nodes)
        n_sel_rods  = len(self.selected_rods)

        if n_sel_nodes==0 and n_sel_rods==0:
            t.insert('end','Click a node/rod. Shift-click to\n'
                           'add one at a time ("piece"), or\n'
                           'drag a box to multi-select.')
        elif n_sel_nodes==1 and n_sel_rods==0:
            ni=next(iter(self.selected_nodes)); n=self.nodes[ni]
            sup=next((s for s in self.supports if s['node']==ni),None)
            ld =next((l for l in self.loads    if l['node']==ni),None)
            res=self.results['node_res'][ni] if self.results else None
            rxn=self.results['reactions'].get(ni) if self.results else None
            F, MOM = self.u('force'), self.u('moment')
            f_ = lambda v: self.show('force', v)
            l_ = lambda v: self.show('length', v)
            d_ = lambda v: self.show('deflection', v)
            t.insert('end', f'{self.joint_text(ni)}  ({l_(n[0]//SNAP):.2f}, '
                            f'{l_(-n[1]//SNAP):.2f}) {self.u("length")}\n')
            if sup: t.insert('end',f'Support: {sup["type"]}\n')
            if ld:  t.insert('end', f'Load Fx={f_(ld["fx"]):g} '
                                    f'Fy={f_(ld["fy"]):g} {F}\n')
            if rxn:
                if rxn.get('type') == 'fixed':
                    t.insert('end', f'Rx={f_(rxn.get("rx",0)):.2f}  '
                                    f'Ry={f_(rxn.get("ry",0)):.2f}  '
                                    f'M={self.show("moment", rxn.get("m",0)):.2f} {MOM}\n')
                else:
                    t.insert('end', f'Rx={f_(rxn.get("rx",0)):.2f}  '
                                    f'Ry={f_(rxn.get("ry",0)):.2f} {F}\n')
            if res: t.insert('end',
                f'\nux={d_(res["ux"]):.3f} {self.u("deflection")}'
                f'\nuy={d_(res["uy"]):.3f} {self.u("deflection")}')
            vecs = self.results['node_vectors'].get(ni) if self.results else None
            if vecs:
                t.insert('end', '\n\nRod forces on this node:\n')
                for v in vecs:
                    t.insert('end',
                        f'  Rod {v["rod"]:>2d} [{v["kind"]}]  '
                        f'|F|={self.show("force", v["magnitude"]):.2f} {F}  '
                        f'θ={v["angle_deg"]:.1f}°\n'
                        f'     Fx={self.show("force", v["Fx"]):+.2f}  '
                        f'Fy={self.show("force", v["Fy"]):+.2f} {F}\n')
            t.insert('end','\n[Delete] to remove')
        elif n_sel_rods==1 and n_sel_nodes==0:
            ri=next(iter(self.selected_rods)); rod=self.rods[ri]
            na,nb=self.nodes[rod['a']],self.nodes[rod['b']]
            L=math.hypot(nb[0]-na[0],nb[1]-na[1])/PX_PER_M
            res=self.results['rod_res'][ri] if self.results else None
            conn = rod.get('conn','pin')
            t.insert('end',f'Rod {ri}  ({rod["a"]} → {rod["b"]})\n')
            t.insert('end', f'L={self.show("length", L):.2f} {self.u("length")}  '
                            f'family="{rod.get("profile","Default")}"\n')
            t.insert('end', f'Section: {self._rod_section_name(ri)}\n')
            t.insert('end',f'Connection: {"Rigid (moment)" if conn=="rigid" else "Pinned (axial)"}\n')
            if conn == 'rigid':
                t.insert('end', f'(E={self.fmt("modulus", rod["E"])} '
                                f'A={self.fmt("area", rod["A"])} '
                                f'I={self.fmt("inertia", rod.get("I",8000.0))})\n')
                if rod.get('udl', 0.0):
                    rot = rod.get('udl_rotation_deg', 0.0)
                    q = self.fmt('line_load', rod['udl'])
                    if abs(rot) < 1e-12:
                        t.insert('end', f'UDL = {q} (⊥ rod)\n')
                    else:
                        t.insert('end', f'UDL = {q} (rot. {rot:g}° from ⊥)\n')
                for pi, pl in enumerate(rod.get('point_loads', []), 1):
                    t.insert('end', f'Point load {pi}: {self.fmt("force", pl.get("P",0))} '
                                    f'@ {pl.get("t",0.5)*100:g}% / {pl.get("angle_deg",90):g}°\n')
            else:
                t.insert('end', f'(E={self.fmt("modulus", rod["E"])} '
                                f'A={self.fmt("area", rod["A"])} assumed)\n')
            if res:
                f=res['force']
                kind='Tension' if f>0.01 else('Compression' if f<-0.01 else 'Zero')
                t.insert('end', f'\nAxial force N = '
                                f'{self.fmt("force", f, sign=True)} [{kind}]')
                if conn == 'rigid':
                    t.insert('end', f'\nShear V = {self.fmt("force", res["V"], sign=True)}'
                                    f'\nMoment Ma = {self.fmt("moment", res["Ma"], sign=True)}'
                                    f'\nMoment Mb = {self.fmt("moment", res["Mb"], sign=True)}')
            t.insert('end','\n\n[Delete] to remove')
        else:
            t.insert('end', f'{n_sel_nodes} node(s), {n_sel_rods} rod(s) selected.\n')
            if n_sel_rods:
                fams = {self.rods[ri].get('profile','Default') for ri in self.selected_rods}
                t.insert('end', f'Families: {", ".join(sorted(fams))}\n')
                # The sections, not only the families. Changing them is
                # the whole point of selecting several rods, and without
                # this line the panel looked identical before and after.
                secs = {self._rod_section_name(ri) for ri in self.selected_rods}
                t.insert('end', f'Sections: {", ".join(sorted(secs))}\n')
                areas = {round(self.show('area', self.rods[ri]['A']), 2)
                         for ri in self.selected_rods}
                t.insert('end', 'A = %s %s\n'
                                % (', '.join('%g' % a for a in sorted(areas)),
                                   self.u('area')))
                conns = {self.rods[ri].get('conn','pin') for ri in self.selected_rods}
                t.insert('end', f'Connections: {", ".join(sorted(conns))}\n')
                t.insert('end', '\nUse "Material and section" or\n'
                                '"Connection type" to change all\n'
                                'of these at once.')
            t.insert('end', '\n\n[Delete] to remove all selected')
        t.configure(state='disabled')

    # ══════════════════════════════════════════════════════════════════════════
    #  Drawing — truss canvas  (everything in WORLD coords → w2s before draw)
    # ══════════════════════════════════════════════════════════════════════════
    def _draw_adaptive_grid(self, c, w2s, z, W, H):
        """Adaptive / level-of-detail grid:
          - MAJOR lines at a "nice" (1-2-5-10-20-50-...) world spacing,
            re-chosen every redraw so their on-screen spacing stays close to
            a fixed target regardless of zoom (no clutter when zoomed out,
            no overly-sparse grid when zoomed in).
          - Below that, one or two recursively finer levels of grid POINTS
            (not full lines, to avoid visual clutter) fade in once their
            on-screen spacing would actually be legible -- so as you zoom
            in, smaller subdivisions of the grid unit progressively appear.
        """
        base_px = SNAP   # 1 world metre, in px at zoom=1
        sx0, sy0 = w2s(0, 0)

        major_step, major_mult = _nice_grid_step(base_px, z, target_px=55)

        # ── major grid lines ──
        step_px = major_step * z
        ox = sx0 % step_px
        if ox < 0: ox += step_px
        x = ox
        while x < W:
            c.create_line(x, 0, x, H, fill=CG, width=0.5)
            x += step_px
        oy = sy0 % step_px
        if oy < 0: oy += step_px
        y = oy
        while y < H:
            c.create_line(0, y, W, y, fill=CG, width=0.5)
            y += step_px

        # ── recursively finer grid POINTS (dots), fading in level by level ──
        level_style = [(CG_MINOR, 1.1), (CG_MICRO, 0.8)]
        cur_step, cur_mult = major_step, major_mult
        for color, r in level_style:
            sub = _grid_subdiv_of(cur_mult)
            next_step = cur_step / sub
            next_px = next_step * z
            if next_px < 10:
                break   # not legible yet at this zoom -- stop subdividing
            n_est = (W / next_px + 2) * (H / next_px + 2)
            if n_est > 20000:
                break   # defensive cap, shouldn't normally trigger
            oxp = sx0 % next_px
            if oxp < 0: oxp += next_px
            oyp = sy0 % next_px
            if oyp < 0: oyp += next_px
            xp = oxp
            while xp < W:
                yp = oyp
                while yp < H:
                    c.create_oval(xp - r, yp - r, xp + r, yp + r, fill=color, outline='')
                    yp += next_px
                xp += next_px
            cur_step, cur_mult = next_step, next_step / base_px

    def _draw(self):
        for _n in ('analyze_btn_bar',):
            _b = getattr(self, _n, None)
            if _b is not None:
                _b.configure(bg='#1a6bbd' if self.results is not None else '#9e9e9e')
        if hasattr(self, 'analyze_btn'):
            self.analyze_btn.configure(
                bg='#1a6bbd' if self.results is not None else '#9e9e9e',
                state='normal')   # always clickable — grey just means "not solved yet"
        c  = self.zc.canvas
        w2s = self.zc.w2s
        z  = self.zc.zoom
        c.delete('all')
        W  = c.winfo_width()  or INIT_CW
        H  = c.winfo_height() or INIT_CH
        # (priority, x, y, text, colour, tag): placed last, so no two
        # numbers are ever drawn over one another (see _place_labels).
        label_queue = []

        # adaptive / level-of-detail grid: "nice" (1-2-5) major spacing that
        # re-normalizes to stay legible at any zoom, plus recursively finer
        # grid-point subdivisions that fade in as you zoom in
        self._draw_adaptive_grid(c, w2s, z, W, H)

        # Guides first of all: they are references, and must never sit on
        # top of the structure they are guiding.
        self._draw_guides(c, w2s, z)

        # Plates go down BEFORE the rods and nodes, so a filled bay never
        # hides the members that bound it.
        self._draw_plates(c, w2s, z)

        show_def  = self.show_deform.get() and self.results is not None
        def_scale = self.def_scale.get()

        if show_def:
            nr = self.results['node_res']
            rod_res = self.results['rod_res']
            curves = deformed_shape_points(self.nodes, self.rods, nr, rod_res, def_scale)
            for pts in curves:
                flat = []
                for (px, py) in pts:
                    sx, sy = w2s(px, py)
                    flat.extend([sx, sy])
                if len(pts) > 2:
                    c.create_line(*flat, fill=CD, width=2.5, smooth=True)
                else:
                    c.create_line(*flat, fill=CD, width=2.5, dash=(6,4))

            # Points of contraflexure (M=0): drawn on the true deformed
            # curve, from the same M(x) the diagram pane already computed,
            # so a marker here always matches the sign-change point shown
            # in the moment diagram.
            if self.show_contraflexure.get() and self.diagrams:
                for i, rod in enumerate(self.rods):
                    if rod.get('conn') != 'rigid' or i >= len(self.diagrams):
                        continue
                    diag = self.diagrams[i]
                    Lm = diag.get('Lm', 0.0)
                    if Lm <= 0:
                        continue
                    xs_cross = find_zero_crossings(diag['xs'], diag['M'])
                    na, nb = self.nodes[rod['a']], self.nodes[rod['b']]
                    ra, rb = nr[rod['a']], nr[rod['b']]
                    rr = rod_res[i] if i < len(rod_res) else None
                    for xc in xs_cross:
                        t = max(0.0, min(1.0, xc / Lm))
                        # Skip the very ends -- a crossing at t=0 or t=1
                        # means the moment is zero AT the joint (e.g. a
                        # pinned-looking end of a cantilever), not a true
                        # reversal of curvature along the span.
                        if t < 0.02 or t > 0.98:
                            continue
                        wx, wy = deformed_point_at(na, nb, ra, rb, rr, def_scale, t)
                        sx, sy = w2s(wx, wy)
                        c.create_oval(sx-4, sy-4, sx+4, sy+4,
                                     fill='white', outline=CD, width=2)

            for i,(nx,ny) in enumerate(self.nodes):
                r=nr[i]
                dx=r['ux']/1000*PX_PER_M*def_scale
                dy=r['uy']/1000*PX_PER_M*def_scale
                if math.hypot(dx,dy)>0.3:
                    sx0,sy0=w2s(nx,ny); sx1,sy1=w2s(nx+dx,ny+dy)
                    c.create_line(sx0,sy0,sx1,sy1,fill=CD,width=1,dash=(2,2))
                    c.create_oval(sx1-4,sy1-4,sx1+4,sy1+4,fill=CD,outline='')

        # rods
        for i, rod in enumerate(self.rods):
            na,nb = self.nodes[rod['a']],self.nodes[rod['b']]
            res   = self.results['rod_res'][i] if self.results else None
            color = CZ; lw = 2.5
            zero = False
            if res:
                f=res['force']
                if   f> 0.01: color=CT; lw=2+min(5,abs(f)/8)
                elif f<-0.01: color=CC; lw=2+min(5,abs(f)/8)
                else: zero = True
            if zero and self.hide_zero.get():
                continue
            color = self._rod_draw_color(i, color)
            sx0,sy0=w2s(na[0],na[1]); sx1,sy1=w2s(nb[0],nb[1])
            # A rod that carries nothing is dashed, so the load path reads
            # at a glance -- grey alone looked like "not analysed yet".
            c.create_line(sx0,sy0,sx1,sy1,fill=color,width=lw,
                          dash=(6, 4) if zero else ())

            if rod.get('conn') == 'rigid':
                ddx0=sx1-sx0; ddy0=sy1-sy0
                Lr0=math.hypot(ddx0,ddy0) or 1
                ux0,uy0=ddx0/Lr0,ddy0/Lr0
                px0,py0=-uy0,ux0
                tick=7
                for (tx,ty) in [(sx0+ux0*14,sy0+uy0*14), (sx1-ux0*14,sy1-uy0*14)]:
                    c.create_line(tx-px0*tick,ty-py0*tick,tx+px0*tick,ty+py0*tick,
                                  fill='#333333',width=2)

            if rod.get('udl', 0.0):
                n_arrows = max(3, int(math.hypot(sx1-sx0, sy1-sy0)//30))
                ddx, ddy = sx1-sx0, sy1-sy0
                Ld = math.hypot(ddx, ddy) or 1.0
                ux_d, uy_d = ddx/Ld, ddy/Ld
                nx_d, ny_d = -uy_d, ux_d
                rot = math.radians(float(rod.get('udl_rotation_deg', 0.0)))
                dux = ux_d*math.sin(rot) + nx_d*math.cos(rot)
                duy = uy_d*math.sin(rot) + ny_d*math.cos(rot)
                for k in range(n_arrows+1):
                    t = k/n_arrows
                    axp, ayp = sx0+(sx1-sx0)*t, sy0+(sy1-sy0)*t
                    c.create_line(axp-dux*16, ayp-duy*16, axp, ayp,
                                  fill='#D85A30', width=1.5, arrow='last',
                                  arrowshape=(5,6,2))
                rot = float(rod.get('udl_rotation_deg', 0.0))
                q_lbl = self.fmt('line_load', rod['udl'])
                label = (f"{q_lbl} ⟂" if abs(rot) < 1e-12
                         else f"{q_lbl}  rot {rot:g}°")
                c.create_text((sx0+sx1)/2, (sy0+sy1)/2-20,
                             text=label, fill='#D85A30',
                             font=('Helvetica',8,'bold'))

            # Point loads on rigid rods
            for pl in rod.get('point_loads', []):
                t = max(0.0, min(1.0, float(pl.get('t', 0.5))))
                qx = sx0 + (sx1-sx0)*t
                qy = sy0 + (sy1-sy0)*t
                ang = math.radians(float(pl.get('angle_deg', 90.0)))
                pux, puy = math.cos(ang), math.sin(ang)
                c.create_line(qx-pux*22, qy-puy*22, qx, qy,
                              fill='#7A3E9D', width=2, arrow='last',
                              arrowshape=(6,7,2))
                c.create_text(qx+pux*28, qy+puy*28,
                              text=f"{pl.get('P',0):g} kN",
                              fill='#7A3E9D', font=('Helvetica',8,'bold'))

            if self.selected_rods and i in self.selected_rods:
                c.create_line(sx0,sy0,sx1,sy1,fill=CS,width=4,dash=(5,3))

            # rod number — constant screen size regardless of zoom
            mx=(sx0+sx1)/2; my=(sy0+sy1)/2
            ddx=sx1-sx0; ddy=sy1-sy0
            Lr=math.hypot(ddx,ddy) or 1
            px,py=-ddy/Lr,ddx/Lr
            off=11
            # Once solved, the rod's axial force sits beside its number --
            # the one result a truss is about, readable without opening a
            # report.  The sign follows the legend: + tension, - compression.
            # "Force on each member" switches the force off and leaves the
            # number: the rods still have to be told apart.
            lbl = str(i)
            if res and self.show_force_labels.get():
                lbl = '%d: %+.1f' % (i, self.show('force', res['force']))
            label_queue.append((1.0 + (abs(res['force']) if res else 0.0),
                                mx+px*off, my+py*off, lbl,
                                color if color!=CZ else '#555', 'rod_label'))

        # The load-path chevrons go on top of the members they travel
        # along, and under the joints, loads and reactions.
        self._draw_load_path(c, w2s, z)

        # supports
        for s in self.supports:
            n=self.nodes[s['node']]; sx,sy=w2s(n[0],n[1])
            self._draw_support(c,sx,sy,s['type'],z)
            if s['node'] in self.disabled_supports:
                self._draw_disabled_support(c, sx, sy)

        # Load and reaction arrows are sized RELATIVE to the largest of their
        # own kind on the model -- see common.LoadScale. Both were a flat 44 px
        # whatever the magnitude, so a 500 kN load and a 5 kN load drew as the
        # same arrow. Loads and reactions are scaled separately so that a model
        # whose reactions dwarf its applied loads still shows both families
        # spread across the full band.
        load_scale = LoadScale.of(
            (math.hypot(ld['fx'], ld['fy']) for ld in self.loads), 16.0, 56.0)
        rxn_scale = LoadScale.of(
            (math.hypot(r.get('rx', 0.0), r.get('ry', 0.0))
             for r in (self.results['reactions'].values() if self.results else ())),
            16.0, 56.0)

        # reaction arrows
        if self.results:
            for ni, rxn in self.results['reactions'].items():
                n=self.nodes[ni]; sx,sy=w2s(n[0],n[1])
                self._draw_reaction(c,sx,sy,rxn.get('rx',0),rxn.get('ry',0),z,
                                     scale=rxn_scale)

        # load arrows -- while a load is traced, it is drawn in the trace's
        # teal with a halo, and every other load steps back to a pale tone,
        # so the arrow the chevrons start from is the one that stands out.
        lp = self._lp if self.show_load_path.get() else None
        traced = lp['start'] if lp and not lp.get('note') else None
        for ld in self.loads:
            n=self.nodes[ld['node']]; sx,sy=w2s(n[0],n[1])
            self._draw_load(c,sx,sy,ld['fx'],ld['fy'],z, scale=load_scale,
                            traced=None if traced is None
                            else ld['node'] == traced)

        # nodes
        for i,(nx,ny) in enumerate(self.nodes):
            sx,sy=w2s(nx,ny)
            is_sel   = i in self.selected_nodes
            is_start = self.rod_start==i
            is_pload = i in self.pending_load and self.tool.get()=='load'
            is_psup  = i in self.pending_sup  and self.tool.get()=='support'
            r    = 9 if (is_sel or is_start) else 6      # constant on-screen size
            fill = CS if (is_sel or is_start) else CN
            c.create_oval(sx-r,sy-r,sx+r,sy+r,fill=fill,outline='#aaa',width=1)
            label_queue.append((1e12, sx, sy-r-4, self.joint_label(i),
                                '#555', 'node_label'))
            if is_pload:
                c.create_oval(sx-13,sy-13,sx+13,sy+13,outline=CL,width=2,dash=(3,2))
            if is_psup:
                c.create_oval(sx-13,sy-13,sx+13,sy+13,outline='#7F77DD',width=2,dash=(3,2))
            if (self.show_node_moments.get() and self.results is not None
                    and 'node_moments' in self.results):
                # Shows the largest INDIVIDUAL rod moment at this joint, not
                # the net sum -- the net is guaranteed to read ~0 at any
                # free joint by pure equilibrium (see compute_node_moments),
                # which would make this toggle look broken at exactly the
                # joints carrying real Vierendeel moment.
                mdata = self.results['node_moments'].get(i, {'max_abs': 0.0, 'max_signed': 0.0})
                m = mdata.get('max_signed', 0.0)
                if abs(m) > 0.05:
                    # Same circular-arrow glyph used everywhere else a node
                    # moment is shown (Node Force Vectors / Rod Calculations
                    # reports) -- CCW for a positive moment, CW for negative,
                    # so every depiction in the app agrees on which way a
                    # given moment actually curls.
                    arc_r = r + 9
                    self._draw_moment_arc(c, sx, sy, arc_r, m, color=CMOM,
                                          width=2, start_angle=20, extent_mag=250,
                                          head_len=6)
                    c.create_text(sx+arc_r+4, sy+arc_r+2, text=f'M={m:+.1f}',
                                 fill=CMOM, font=('Helvetica',8,'bold'), anchor='w')

        if self.rod_start is not None:
            nx,ny=self.nodes[self.rod_start]; sx,sy=w2s(nx,ny)
            c.create_oval(sx-14,sy-14,sx+14,sy+14,outline=CS,width=2,dash=(4,3))

        # ── ghost node preview ───────────────────────────────────────────────
        t_now = self.tool.get()
        gx, gy = self._ghost_wx, self._ghost_wy
        if gx is not None and t_now in ('node', 'rod'):
            gsx, gsy = w2s(gx, gy)
            # ghost circle — constant on-screen size regardless of zoom
            r_g = 7
            c.create_oval(gsx-r_g, gsy-r_g, gsx+r_g, gsy+r_g,
                           outline='#1a6bbd', fill='', width=1.5, dash=(3,2))
            # coordinates callout
            gmx, gmy = self._world_to_metres(gx, gy)
            c.create_text(gsx+r_g+4, gsy,
                           text=f'({gmx:.3f}, {gmy:.3f})',
                           fill='#1a6bbd', font=('Helvetica',8),
                           anchor='w')
            # if drawing a rod, show live distance + angle line
            if t_now == 'rod' and self.rod_start is not None:
                ref = self.nodes[self.rod_start]
                rsx, rsy = w2s(ref[0], ref[1])
                c.create_line(rsx, rsy, gsx, gsy,
                               fill='#1a6bbd', width=1.5, dash=(6,3))
                L_m = math.hypot(gx-ref[0], gy-ref[1]) / PX_PER_M
                ang = math.degrees(math.atan2(-(gy-ref[1]), gx-ref[0]))
                mid_sx = (rsx+gsx)/2; mid_sy = (rsy+gsy)/2
                c.create_text(mid_sx, mid_sy-12,
                               text=f'L={L_m:.3f}m  α={ang:.1f}°',
                               fill='#1a6bbd',
                               font=('Helvetica',max(7,int(9*z)),'bold'))

        # ── angle snap rays ──────────────────────────────────────────────────
        if (self.snap_angle.get() and self.rod_start is not None
                and t_now == 'rod'):
            ref = self.nodes[self.rod_start]
            rsx, rsy = w2s(ref[0], ref[1])
            deg_step = self.snap_angle_deg.get()
            ray_len  = max(c.winfo_width(), c.winfo_height()) * 2
            for a_deg in range(0, 360, deg_step):
                rad  = math.radians(a_deg)
                ex   = rsx + ray_len * math.cos(rad)
                ey   = rsy - ray_len * math.sin(rad)
                c.create_line(rsx, rsy, ex, ey,
                               fill='#c8d8f0', width=0.5, dash=(4,6))
                # label every step
                lx = rsx + 44*z * math.cos(rad)
                ly = rsy - 44*z * math.sin(rad)
                c.create_text(lx, ly, text=f'{a_deg}°',
                               fill='#9ab', font=('Helvetica', max(6,int(7*z))))

        # ── ruler overlay ────────────────────────────────────────────────────
        if self.ruler_active.get() and self.ruler_start is not None:
            rs = self.ruler_start
            rsx0, rsy0 = w2s(rs[0], rs[1])
            if gx is not None:
                rsx1, rsy1 = w2s(gx, gy)
            else:
                rsx1, rsy1 = w2s(self._mouse_wx, self._mouse_wy)
            # main ruler line
            c.create_line(rsx0, rsy0, rsx1, rsy1,
                           fill='#c0392b', width=2*z, dash=(8,4))
            # end ticks
            for ex, ey in [(rsx0,rsy0),(rsx1,rsy1)]:
                c.create_line(ex, ey-8*z, ex, ey+8*z,
                               fill='#c0392b', width=2)
            # start dot
            c.create_oval(rsx0-4,rsy0-4,rsx0+4,rsy0+4, fill='#c0392b', outline='')
            # measurement label on line
            if gx is not None:
                dm  = math.hypot((gx-rs[0])/PX_PER_M, (gy-rs[1])/PX_PER_M)
                ang = math.degrees(math.atan2(-(gy-rs[1]), gx-rs[0]))
                mx0, my0 = self._world_to_metres(rs[0], rs[1])
                mx1, my1 = self._world_to_metres(gx, gy)
                lbl = f'd={dm:.4f} m  α={ang:.2f}°'
                msx = (rsx0+rsx1)/2; msy = (rsy0+rsy1)/2
                # white halo
                c.create_text(msx, msy-14, text=lbl, fill='white',
                               font=('Helvetica',max(8,int(10*z)),'bold'))
                c.create_text(msx, msy-14, text=lbl, fill='#c0392b',
                               font=('Helvetica',max(8,int(10*z)),'bold'))
            # origin crosshair
            ch = 10*z
            c.create_line(rsx0-ch,rsy0,rsx0+ch,rsy0, fill='#c0392b',width=1)
            c.create_line(rsx0,rsy0-ch,rsx0,rsy0+ch, fill='#c0392b',width=1)

        # ── protractor overlay (shown when angle-snap is on, no rod drawing) ─
        if (self.snap_angle.get() and t_now == 'node'
                and gx is not None and self.nodes):
            # draw a small protractor arc around the ghost node
            gsx2, gsy2 = w2s(gx, gy)
            R = max(30, int(40*z))
            deg_step = self.snap_angle_deg.get()
            c.create_oval(gsx2-R, gsy2-R, gsx2+R, gsy2+R,
                           outline='#aad', width=0.8, dash=(2,4))
            for a_deg in range(0, 360, deg_step):
                rad  = math.radians(a_deg)
                tx   = gsx2 + (R+8) * math.cos(rad)
                ty   = gsy2 - (R+8) * math.sin(rad)
                c.create_text(tx, ty, text=f'{a_deg}°',
                               fill='#99a',
                               font=('Helvetica', max(5, int(6*z))))

        # Guide handles go ON TOP of the structure. Drawn with the guides,
        # underneath, the nodes bury them -- and a handle you cannot see is a
        # handle you will not reach for.
        self._draw_guide_handles(c, w2s, z)

        # ── selection rubber band ────────────────────────────────────────────
        # Drawn LAST so it sits over the structure it is selecting.
        #
        # This was the bug: `_on_drag_motion` has always stored the far corner
        # in `_box_cur` and called `_draw()`, and `_on_release` has always
        # computed the selection correctly from it -- but nothing ever drew
        # the box, so you were selecting blind and the redraw per motion event
        # was pure cost with nothing to show. Only the feedback was missing;
        # the selection logic itself was never wrong.
        if self._dragging_box and self._box_cur is not None and self._press_wx is not None:
            bsx0, bsy0 = w2s(self._press_wx, self._press_wy)
            bsx1, bsy1 = w2s(self._box_cur[0], self._box_cur[1])
            # Dragging right-to-left is a "crossing" box in every CAD tool;
            # this tab selects the same way in both directions (see
            # _nodes_in_box, which normalises the corners), so the two are
            # drawn identically rather than implying a distinction that is
            # not there.
            c.create_rectangle(bsx0, bsy0, bsx1, bsy1,
                               outline=CS, width=1.5, dash=(5, 3))
            c.create_rectangle(bsx0, bsy0, bsx1, bsy1,
                               outline='', fill=CS, stipple='gray12')
            wmm = abs(self._box_cur[0] - self._press_wx) / PX_PER_M
            hmm = abs(self._box_cur[1] - self._press_wy) / PX_PER_M
            c.create_text((bsx0 + bsx1) / 2, min(bsy0, bsy1) - 10,
                           text=f'{wmm:.2f} × {hmm:.2f} m',
                           fill=CS, font=('Helvetica', 8, 'bold'))

        self._place_labels(c, label_queue, W, H)

        if self.results is not None:
            self._draw_force_key(c, H)

        # zoom hint
        c.create_text(6,6,anchor='nw',
                       text=f'zoom {self.zc.zoom:.2f}×  |  scroll=zoom  mid-drag=pan',
                       fill='#aaa',font=('Helvetica',8))

        if getattr(self, '_mech', None) is not None:
            self._draw_mechanism()      # the redraw above wiped the overlay
        self._refresh_learn()

    def _draw_force_key(self, c, H):
        """Bottom-left key for a solved model, so the colours and the
        numbers on the rods explain themselves."""
        x, y = 10, H - 12
        # The analysis draws this and THEN opens the diagram pane, which
        # shrinks the canvas: keep the key pinned to the bottom edge.
        self._force_key_y = y
        if not getattr(self, '_force_key_bound', False):
            self._force_key_bound = True

            def follow(e, c=c):
                y0 = getattr(self, '_force_key_y', None)
                if y0 is None or not c.find_withtag('force_key'):
                    return
                c.move('force_key', 0, (e.height - 12) - y0)
                self._force_key_y = e.height - 12
            c.bind('<Configure>', follow, add='+')
        F = self.u('force')
        items = ((CT, 'tension (+)'), (CC, 'compression (\u2212)'),
                 (CZ, 'zero'))
        for col, txt in items:
            c.create_line(x, y, x + 20, y, fill=col, width=4,
                          tags=('force_key',))
            t = c.create_text(x + 25, y, text=txt, anchor='w', fill='#555',
                              font=('Helvetica', 8), tags=('force_key',))
            x = c.bbox(t)[2] + 12
        c.create_text(x, y, anchor='w', fill='#888', font=('Helvetica', 8),
                      text=('rod labels: number: axial force N (%s)' % F
                            if self.show_force_labels.get()
                            else 'rod labels: number'),
                      tags=('force_key',))

    def _show_plate_checks(self):
        """Write the plate checks into the panel. A panel's shear-buckling
        result is printed on the same line as its tau, never separately: a
        thin plate buckles long before it yields, so a comfortable tau shown
        on its own is the most misleading thing this feature could report."""
        if not self.plates:
            self.plate_res_frame.pack_forget()
            return
        txt = self.plate_res_text
        txt.configure(state='normal')
        txt.delete('1.0', 'end')
        checks = self.plate_checks if len(self.plate_checks) == len(self.plates) else []
        for i, plate in enumerate(self.plates):
            chk = checks[i] if checks else None
            if plate.get('kind') == 'panel':
                nodes_s = '-'.join(str(n) for n in plate.get('nodes', []))
                if not chk or not chk.get('valid'):
                    why = (chk or {}).get('reason', 'not analysed')
                    txt.insert('end', 'Panel %s: %s\n' % (nodes_s, why))
                    continue
                # b/t and every utilisation are ratios: dimensionless, and
                # the same number in any convention.
                SL, ST, Q = (self.u('detail_length'), self.u('stress'),
                             self.u('line_load'))
                sl_ = lambda v: self.show('detail_length', v)
                txt.insert('end',
                    'Panel %s  t=%.2f %s\n'
                    '  q=%+.2f %s  tau=%.2f %s\n'
                    '  b/t=%.0f  tau_cr=%.1f %s\n'
                    '  util %.2f yield / %.2f buckling\n'
                    '  -> %.2f  %s\n'
                    '  weld leg %.2f %s (min %.2f, max %.2f)%s\n'
                    % (nodes_s, sl_(chk['t_mm']), SL,
                       self.show('line_load', chk['q_kN_per_m']), Q,
                       self.show('stress', chk['tau_MPa']), ST,
                       chk['b_over_t'],
                       self.show('stress', chk['tau_cr_MPa']), ST,
                       chk['util_yield'], chk['util_buckling'],
                       chk['util'], chk['governing'],
                       sl_(chk['weld_leg_mm']), SL,
                       sl_(chk['weld_leg_min_mm']),
                       sl_(chk['weld_leg_max_mm']),
                       '' if chk['weld_leg_feasible'] else '  TOO BIG FOR t'))
            else:
                if not chk:
                    txt.insert('end', 'Gusset @%s: not analysed\n'
                               % plate.get('node'))
                    continue
                txt.insert('end',
                    'Gusset @node %d  t=%.0f mm\n'
                    '  resultant %.2f kN\n'
                    '  util %.2f  %s\n'
                    % (chk['node'], chk['t_mm'], chk['resultant_kN'],
                       chk['util'], chk['governing']))
                txt.insert('end', '  %s\n' % chk['detail_note'])
                for mm in chk['members']:
                    txt.insert('end',
                        '   rod %-2d %-5s P=%7.2f kN leg %.1f\n'
                        % (mm['rod'], mm['conn'], mm['P_kN'], mm['weld_leg_mm']))
                    bs = mm['block_shear']
                    txt.insert('end',
                        '     block shear Rd=%.0f kN u=%.2f\n'
                        % (bs['Rd_kN'], bs['util']))
                    gb = mm['buckling']
                    if gb.get('applies'):
                        txt.insert('end',
                            '     buckling Pd=%.0f kN u=%.2f\n'
                            % (gb['Pd_kN'], gb['util']))
                txt.insert('end', '  phi for block shear/buckling is\n'
                                  '  AISC, not read off CIRSOC -\n'
                                  '  confirm before sign-off\n')
        txt.configure(state='disabled')
        self.plate_res_frame.pack(fill='x', padx=8, pady=4)

    def _draw_plates(self, c, w2s, z):
        """Draw every plate beneath the members. Panels are filled and hatched
        and labelled with tau; gussets are a soft outline at their joint."""
        checks = self.plate_checks if len(self.plate_checks) == len(self.plates) else []
        for pi, plate in enumerate(self.plates):
            chk = checks[pi] if checks else None
            if plate.get('kind') == 'panel':
                loop = plate_node_loop(self.nodes, plate)
                if loop is None:
                    continue
                flat = []
                for ni in loop:
                    sx, sy = w2s(*self.nodes[ni])
                    flat += [sx, sy]
                fill, outline = self._plate_fill_for(chk)
                c.create_polygon(*flat, fill=fill, outline=outline, width=1.4)
                cx = sum(flat[0::2]) / len(loop)
                cy = sum(flat[1::2]) / len(loop)
                # diagonal hatching, so a panel still reads as a plate in a
                # black-and-white print and not as a shaded region
                xs, ys = flat[0::2], flat[1::2]
                x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
                step = max(10, int(14 * z))
                k = int(x0 - (y1 - y0))
                while k < x1:
                    c.create_line(k, y1, k + (y1 - y0), y0,
                                  fill=outline, width=1, stipple='gray25')
                    k += step
                if chk and chk.get('valid'):
                    label = 'τ %.1f %s\nutil %.2f' % (
                        self.show('stress', chk['tau_MPa']), self.u('stress'),
                        chk['util'])
                    if chk.get('buckling_governs'):
                        label += '\n(buckling)'
                elif chk and not chk.get('valid'):
                    label = 'invalid panel'
                else:
                    label = 't=%.2f %s' % (
                        self.show('detail_length', float(plate.get('thickness_mm', 0))),
                        self.u('detail_length'))
                c.create_text(cx, cy, text=label, fill='#33526b',
                              font=('Helvetica', max(7, int(8 * z))),
                              justify='center')
            else:
                ni = int(plate.get('node', -1))
                if not (0 <= ni < len(self.nodes)):
                    continue
                outline_m = truss_plates.gusset_outline(
                    self.nodes, self.rods, ni,
                    landing_m=float(plate.get('landing_m', 0.30)))
                if len(outline_m) < 3:
                    continue
                nx, ny = self.nodes[ni]
                flat = []
                for (mx, my) in outline_m:
                    # metres, y-up, relative to the node -> canvas world
                    sx, sy = w2s(nx + mx * PX_PER_M, ny - my * PX_PER_M)
                    flat += [sx, sy]
                fill, outline = self._plate_fill_for(chk)
                c.create_polygon(*flat, fill=fill, outline=outline, width=1.2,
                                 stipple='gray50')
                if chk:
                    sx, sy = w2s(nx, ny)
                    c.create_text(sx + 6, sy - 16,
                                  text='gusset %.0f mm  util %.2f'
                                       % (chk['t_mm'], chk['util']),
                                  fill='#33526b', anchor='w',
                                  font=('Helvetica', max(6, int(7 * z))))

    def _draw_support(self, c, x, y, stype, z=1, label=True):
        sc=1.0   # constant on-screen size regardless of zoom
        pts=[x,y, x-14*sc,y+22*sc, x+14*sc,y+22*sc]
        c.create_polygon(pts,fill='#cccccc',outline=CSP,width=1.5*sc)
        c.create_line(x-18*sc,y+22*sc,x+18*sc,y+22*sc,fill=CSP,width=1.5*sc)
        if stype=='pin':
            for k in range(-3,4):
                c.create_line(x+k*5*sc,y+22*sc,x+k*5*sc-4*sc,y+29*sc,
                               fill=CSP,width=1.5*sc)
        elif stype=='rollerX':
            c.create_oval(x-11*sc,y+23*sc,x-4*sc,y+30*sc,outline=CSP,width=1.5*sc)
            c.create_oval(x+4*sc,y+23*sc,x+11*sc,y+30*sc,outline=CSP,width=1.5*sc)
            c.create_line(x-18*sc,y+31*sc,x+18*sc,y+31*sc,fill=CSP,width=1.5*sc)
        else:
            c.create_oval(x-4*sc,y+23*sc,x+4*sc,y+30*sc,outline=CSP,width=1.5*sc)
            c.create_line(x-18*sc,y+31*sc,x+18*sc,y+31*sc,fill=CSP,width=1.5*sc)
        # Name it the way the panel names it. 'rollerX' told the reader
        # nothing about which way it slides -- the only thing a roller
        # symbol is for.
        #
        # `label=False` for the picker in the Support card: its cells
        # carry a wrapped Tk label of their own, and drawing the caption
        # here too printed the name twice, the canvas copy clipped by the
        # bottom edge and overlapping the symbol.
        if label:
            c.create_text(x, y+36*sc, text=self.support_label(stype),
                          fill='#777', font=('Helvetica', 8))

    #: The trace's colour (see _draw_load_path) and the tone the other
    #: loads step back to while one is being traced.
    LP_COLOUR = '#0F8A7E'
    LOAD_DIMMED = '#ecc3b2'

    def _draw_load(self, c, x, y, fx, fy, z=1, scale=None, traced=None):
        """`traced`: None when no load is being traced; True for the one
        that is (teal, thicker, haloed); False for the others (pale)."""
        mag=math.hypot(fx,fy)
        if mag<0.001: return
        sc=1.0   # constant on-screen size regardless of zoom
        length = scale(mag) if scale is not None else 44.0
        nx_,ny_=fx/mag,fy/mag
        ox,oy=x-nx_*length*sc,y-ny_*length*sc
        colour, width, tag = CL, 2, 'load_arrow'
        if traced:
            colour, width, tag = self.LP_COLOUR, 4, 'load_arrow_traced'
            c.create_line(ox, oy, x, y, fill='#bfe6e1', width=11,
                          capstyle='round', tags=('load_halo',))
        elif traced is False:
            colour = self.LOAD_DIMMED
        c.create_line(ox,oy,x,y,fill=colour,width=width*sc,arrow='last',
                       arrowshape=(12*sc,14*sc,5*sc) if traced
                       else (10*sc,12*sc,4*sc), tags=(tag,))
        c.create_text(ox-ny_*14*sc,oy+nx_*14*sc,
                       text=self.fmt('force', mag),fill=colour,
                       font=('Helvetica',10 if traced else 9,'bold'),
                       tags=(tag + '_text',))

    def _draw_reaction(self, c, x, y, rx, ry, z=1, scale=None):
        """Green arrows pointing away from the support node."""
        sc=1.0   # constant on-screen size regardless of zoom
        mag=math.hypot(rx,ry)
        if mag<0.01: return
        length = scale(mag) if scale is not None else 44.0
        nx_=rx/mag; ny_=ry/mag
        # arrow points outward (reaction direction)
        ex,ey=x+nx_*length*sc,y+ny_*length*sc
        c.create_line(x,y,ex,ey,fill=CR,width=2*sc,arrow='last',
                       arrowshape=(10*sc,12*sc,4*sc),dash=(4,2))
        lx=ex+ny_*14*sc; ly=ey-nx_*14*sc
        c.create_text(lx,ly,text='R=' + self.fmt('force', mag),fill=CR,
                       font=('Helvetica',8,'bold'))

    # ══════════════════════════════════════════════════════════════════════════
    #  Diagram canvas
    # ══════════════════════════════════════════════════════════════════════════
    def _show_diagrams(self):
        # Just above the status bar.  Not "before the root's last child":
        # once a report window is open that child is a Toplevel, which is
        # not packed, and Tk refused the whole call.
        self.shell.show_lower(height=INIT_DH + 30)
        self._draw_diagrams_only()

    def _draw_vierendeel_diagram(self):
        """Draws two silhouettes of the actual structure side by side: shear
        (red) on the left, bending moment (blue) on the right -- following
        the classic Vierendeel-girder diagram convention. Each rigid rod is
        sampled at several points along its own length so a UDL's linear
        shear / parabolic moment variation renders correctly (not just the
        two end values) -- and the global maximum |V| and |M|, including
        every tied location, are marked directly on the diagram. Pin rods
        are pure axial (no V/M), so only rigid rods get a diagram overlay,
        though every rod still gets its outline drawn."""
        dc = self.diag_zc.canvas
        dc.delete('all')
        DW = dc.winfo_width() or INIT_CW
        DH = dc.winfo_height() or INIT_DH

        if not self.results or not self.nodes:
            dc.create_text(DW/2, DH/2, text='Run ▶ Analyze first', fill='#999',
                           font=('Helvetica', 11))
            return

        rod_res = self.results['rod_res']
        xs = [n[0] for n in self.nodes]; ys = [n[1] for n in self.nodes]
        xmin, xmax = min(xs), max(xs); ymin, ymax = min(ys), max(ys)
        span_w = max(xmax-xmin, 1); span_h = max(ymax-ymin, 1)

        pad = 40
        half_w = DW/2
        avail_w = max(half_w - 2*pad, 10)
        avail_h = max(DH - 2*pad - 30, 10)
        scale_geo = min(avail_w/span_w, avail_h/span_h)

        # Zoom/pan: this view uses the SAME ZoomCanvas mouse-wheel-zoom /
        # middle-drag-pan already wired up for the main canvas and the
        # ordinary "Truss diagrams" panel -- it was just never actually
        # wired into this diagram's own transform before, so scrolling had
        # no visible effect here even though the zoom value was updating.
        # Fix: treat the auto-fit layout below as the "world" coordinates
        # fed into diag_zc's own w2s(), exactly like the per-rod panel view
        # already does for its own (differently-shaped) layout space. At
        # zoom=1.0, pan=(0,0) -- diag_zc's default state -- this reduces
        # EXACTLY to the previous fixed auto-fit rendering.
        zc_w2s = self.diag_zc.w2s
        z = self.diag_zc.zoom

        def make_T(origin_x):
            def T(wx, wy):
                return zc_w2s(origin_x + pad + (wx-xmin)*scale_geo,
                              pad + 30 + (wy-ymin)*scale_geo)
            return T
        T_left, T_right = make_T(0), make_T(half_w)

        dc.create_text(half_w/2, 14, text=f'SHEAR V ({self.u("force")})', fill='#c0392b',
                      font=('Helvetica', 11, 'bold'))
        dc.create_text(half_w + half_w/2, 14, text=f'MOMENT M ({self.u("moment")})',
                      fill='#2c5f9e', font=('Helvetica', 11, 'bold'))
        dc.create_line(half_w, 0, half_w, DH, fill='#ccc')

        NSAMP = 13   # samples per rod along its own length
        def sample_rod(res):
            """Returns (v_samples, m_samples), each a list of (frac_0_1, value).
            Point-load positions are inserted with left/right samples so the
            shear jump is visible without changing the continuous UDL curve.
            """
            Lm, wt, V1, Ma = res['length_m'], res.get('w_t', 0.0), res['V'], res['Ma']
            pts = res.get('point_loads_local', [])
            fracs = [k/(NSAMP-1) for k in range(NSAMP)]
            for pl in pts:
                t = max(0.0, min(1.0, pl.get('t', 0.5)))
                eps = 1e-6
                fracs.extend([max(0.0, t-eps), t, min(1.0, t+eps)])
            # Exact M extrema occur where the piecewise-linear shear is zero.
            # Add those stations so the Vierendeel overlay's maximum is not
            # limited by its visual sampling density.
            if abs(wt) > 1e-12:
                breaks = [0.0] + sorted(
                    max(0.0, min(1.0, pl.get('t', 0.5))) for pl in pts
                ) + [1.0]
                for left, right in zip(breaks, breaks[1:]):
                    p_before = sum(pl.get('pt', 0.0) for pl in pts
                                   if pl.get('t', 0.5) <= left + 1e-10)
                    x_zero_v = (V1 - p_before) / wt
                    frac_zero_v = x_zero_v / Lm if Lm else 0.0
                    if left + 1e-10 < frac_zero_v < right - 1e-10:
                        fracs.append(frac_zero_v)
            fracs = sorted(set(fracs))
            vs, ms = [], []
            for frac in fracs:
                x = Lm * frac
                shear = V1 - wt*x
                moment = Ma + V1*x - wt*x**2/2
                for pl in pts:
                    t = max(0.0, min(1.0, pl.get('t', 0.5)))
                    a = Lm * t
                    pt = pl.get('pt', 0.0)
                    if frac >= t:
                        shear -= pt
                        moment -= pt*(x-a)
                vs.append((frac, shear))
                ms.append((frac, moment))
            return vs, ms

        rigid_items = [(rod, res, *sample_rod(res)) for rod, res in zip(self.rods, rod_res)
                       if res.get('conn') == 'rigid']

        max_V = max((max(abs(v) for _, v in vs) for _, _, vs, _ in rigid_items), default=1) or 1
        max_M = max((max(abs(m) for _, m in ms) for _, _, _, ms in rigid_items), default=1) or 1
        max_offset = min(avail_w, avail_h) * 0.16
        amp_V = max_offset / max_V * z
        amp_M = max_offset / max_M * z

        for T in (T_left, T_right):
            for rod in self.rods:
                na, nb = self.nodes[rod['a']], self.nodes[rod['b']]
                pa, pb = T(na[0], na[1]), T(nb[0], nb[1])
                dc.create_line(*pa, *pb, fill='#999', width=2)
            for n in self.nodes:
                px, py = T(n[0], n[1])
                dc.create_oval(px-3, py-3, px+3, py+3, fill='#555', outline='')

        def draw_band(pa, pb, nx, ny, samples, amp, fill, outline):
            segs, cur = [], [samples[0]]
            for i in range(1, len(samples)):
                f0, v0 = samples[i-1]; f1, v1 = samples[i]
                if v0*v1 < 0:
                    fc = f0 + (f1-f0)*(-v0)/(v1-v0)
                    cur.append((fc, 0.0)); segs.append(cur); cur = [(fc, 0.0)]
                cur.append((f1, v1))
            segs.append(cur)
            for seg in segs:
                if len(seg) < 2: continue
                base_pts = [(pa[0]+(pb[0]-pa[0])*f, pa[1]+(pb[1]-pa[1])*f) for f, _ in seg]
                off_pts = [(px+nx*v*amp, py+ny*v*amp) for (px, py), (_, v) in zip(base_pts, seg)]
                poly = base_pts + off_pts[::-1]
                dc.create_polygon(*[c for p in poly for c in p], fill=fill, outline=outline, width=1)

        for rod, res, vs, ms in rigid_items:
            na, nb = self.nodes[rod['a']], self.nodes[rod['b']]
            dx, dy = nb[0]-na[0], nb[1]-na[1]
            Lr = math.hypot(dx, dy) or 1
            nx, ny = -dy/Lr, dx/Lr

            paL, pbL = T_left(na[0], na[1]), T_left(nb[0], nb[1])
            draw_band(paL, pbL, nx, ny, vs, amp_V, '#e8a49c', '#c0392b')
            mxv, myv = (paL[0]+pbL[0])/2, (paL[1]+pbL[1])/2
            dc.create_text(mxv, myv, text=f'{res["V"]:.1f}', font=('Helvetica',7), fill='#c0392b')

            paR, pbR = T_right(na[0], na[1]), T_right(nb[0], nb[1])
            draw_band(paR, pbR, nx, ny, ms, amp_M, '#9fc0e0', '#2c5f9e')
            oxA, oyA = nx*res['Ma']*amp_M, ny*res['Ma']*amp_M
            oxB, oyB = nx*res['Mb']*amp_M, ny*res['Mb']*amp_M
            dc.create_text(paR[0]+oxA*1.2, paR[1]+oyA*1.2, text=f'{res["Ma"]:.1f}',
                          font=('Helvetica',7), fill='#2c5f9e')
            dc.create_text(pbR[0]+oxB*1.2, pbR[1]+oyB*1.2, text=f'{res["Mb"]:.1f}',
                          font=('Helvetica',7), fill='#2c5f9e')

        # ── mark the global maximum |V| and |M|, including every tied location ──
        if rigid_items:
            tol = 1e-3
            v_hits, m_hits = [], []
            for ridx, (rod, res, vs, ms) in enumerate(rigid_items):
                v_abs_max = max(abs(v) for _, v in vs)
                if v_abs_max >= max_V - tol*max_V - 1e-9:
                    f, v = max(vs, key=lambda fv: abs(fv[1]))
                    v_hits.append((ridx, f, v))
                m_abs_max = max(abs(m) for _, m in ms)
                if m_abs_max >= max_M - tol*max_M - 1e-9:
                    f, m = max(ms, key=lambda fm: abs(fm[1]))
                    m_hits.append((ridx, f, m))

            for ridx, f, v in v_hits:
                rod = rigid_items[ridx][0]
                na, nb = self.nodes[rod['a']], self.nodes[rod['b']]
                wx, wy = na[0]+(nb[0]-na[0])*f, na[1]+(nb[1]-na[1])*f
                sx, sy = T_left(wx, wy)
                dc.create_oval(sx-5, sy-5, sx+5, sy+5, fill='white', outline='#c0392b', width=2)
            for ridx, f, m in m_hits:
                rod = rigid_items[ridx][0]
                na, nb = self.nodes[rod['a']], self.nodes[rod['b']]
                wx, wy = na[0]+(nb[0]-na[0])*f, na[1]+(nb[1]-na[1])*f
                sx, sy = T_right(wx, wy)
                dc.create_oval(sx-5, sy-5, sx+5, sy+5, fill='white', outline='#2c5f9e', width=2)

            dc.create_text(half_w/2, DH-10,
                           text=f'max |V| = {self.fmt("force", max_V)}'
                           + (f'  ({len(v_hits)} locations)' if len(v_hits) > 1 else ''),
                           fill='#c0392b', font=('Helvetica', 9, 'bold'))
            dc.create_text(half_w+half_w/2, DH-10,
                           text=f'max |M| = {self.fmt("moment", max_M)}'
                           + (f'  ({len(m_hits)} locations)' if len(m_hits) > 1 else ''),
                           fill='#2c5f9e', font=('Helvetica', 9, 'bold'))
        else:
            dc.create_text(DW/2, DH-14,
                          text='No rigid rods in this model — Vierendeel diagram needs at least one "Rigid" connection.',
                          fill='#999', font=('Helvetica', 9))

    def _draw_fiber_diagram(self):
        """Draws the whole structure once, with each rigid rod rendered as
        two thin parallel fiber bands (top = local '-v' side, bottom =
        local '+v' side -- see compute_fiber_stress docstring) colored
        red/blue per-station for tension/compression, splitting at every
        sign change exactly like the Vierendeel band renderer. Combines
        axial force with bending (N/A +/- M*c/I), so a member in heavy
        axial tension can show a compression-colored patch near a local
        moment peak if bending doesn't fully overcome the axial tension
        there, and vice versa. Pin rods have no bending distinction and
        draw as a single uniformly-colored line, using the same tension/
        compression coloring rule already used for pin rods on the main
        canvas.
        """
        dc = self.diag_zc.canvas
        dc.delete('all')
        DW = dc.winfo_width() or INIT_CW
        DH = dc.winfo_height() or INIT_DH

        if not self.results or not self.nodes or self.diagrams is None:
            dc.create_text(DW/2, DH/2, text='Run ▶ Analyze first', fill='#999',
                           font=('Helvetica', 11))
            return

        rod_res = self.results['rod_res']
        xs_n = [n[0] for n in self.nodes]; ys_n = [n[1] for n in self.nodes]
        xmin, xmax = min(xs_n), max(xs_n); ymin, ymax = min(ys_n), max(ys_n)
        span_w = max(xmax-xmin, 1); span_h = max(ymax-ymin, 1)

        pad = 40
        avail_w = max(DW - 2*pad, 10)
        avail_h = max(DH - 2*pad - 30, 10)
        scale_geo = min(avail_w/span_w, avail_h/span_h)

        # Same fix as _draw_vierendeel_diagram: compose the auto-fit layout
        # with diag_zc's own zoom/pan (already wired to mouse wheel + middle
        # drag) instead of a fixed transform that silently ignored it.
        zc_w2s = self.diag_zc.w2s
        z = self.diag_zc.zoom

        def T(wx, wy):
            return zc_w2s(pad + (wx-xmin)*scale_geo, pad + 30 + (wy-ymin)*scale_geo)

        dc.create_text(DW/2, 14, text='FIBER STRESS (top/bottom of each member)',
                       fill='#555', font=('Helvetica', 11, 'bold'))
        dc.create_text(DW/2, 30,
                       text='red = tension   blue = compression   (combines axial force with bending; '
                            'flips at points of contraflexure)',
                       fill='#888', font=('Helvetica', 8))

        THICK = 6 * z  # band thickness in pixels -- this is a color-coded
                       # strip, not a stress-magnitude-scaled offset, matching
                       # the classic isostatic-beam top/bottom picture.
                       # Scaled by the current zoom so the strip stays
                       # visually proportionate to the rest of the diagram
                       # as the user zooms in or out.

        def draw_fiber_band(pa, pb, nx, ny, xs_m, Lm, sigmas, sign):
            """One band (sign=+1 offsets toward +[nx,ny], sign=-1 toward
            -[nx,ny]) split into red/blue segments at every zero crossing."""
            if Lm <= 0 or not xs_m:
                return
            fracs = [x/Lm for x in xs_m]
            samples = list(zip(fracs, sigmas))
            segs, cur = [], [samples[0]]
            for i in range(1, len(samples)):
                f0, v0 = samples[i-1]; f1, v1 = samples[i]
                if v0*v1 < 0:
                    fc = f0 + (f1-f0)*(-v0)/(v1-v0)
                    cur.append((fc, 0.0)); segs.append(cur); cur = [(fc, 0.0)]
                cur.append((f1, v1))
            segs.append(cur)
            for seg in segs:
                if len(seg) < 2:
                    continue
                avg = sum(v for _, v in seg) / len(seg)
                color = CT if avg > 1e-6 else (CC if avg < -1e-6 else CZ)
                base_pts = [(pa[0]+(pb[0]-pa[0])*f, pa[1]+(pb[1]-pa[1])*f) for f, _ in seg]
                off_pts = [(px+nx*THICK*sign, py+ny*THICK*sign) for (px, py) in base_pts]
                poly = base_pts + off_pts[::-1]
                dc.create_polygon(*[c for p in poly for c in p],
                                  fill=color, outline='', width=0)

        for i, rod in enumerate(self.rods):
            na, nb = self.nodes[rod['a']], self.nodes[rod['b']]
            pa, pb = T(na[0], na[1]), T(nb[0], nb[1])
            rr = rod_res[i] if i < len(rod_res) else None

            if not rr or rr.get('conn', 'pin') != 'rigid' or i >= len(self.diagrams):
                force = rr.get('force', 0.0) if rr else 0.0
                color = CT if force > 0.01 else (CC if force < -0.01 else CZ)
                dc.create_line(*pa, *pb, fill=color, width=3)
                continue

            diag = self.diagrams[i]
            Lm = diag.get('Lm', 0.0)
            dx, dy = nb[0]-na[0], nb[1]-na[1]
            Lr = math.hypot(dx, dy) or 1
            nx, ny = -dy/Lr, dx/Lr   # same local-transverse direction used for Ma/Mb labels

            sigma_neg, sigma_pos = compute_fiber_stress(rod, rr, diag['M'])

            dc.create_line(*pa, *pb, fill='#bbb', width=1)
            draw_fiber_band(pa, pb, nx, ny, diag['xs'], Lm, sigma_neg, sign=-1)
            draw_fiber_band(pa, pb, nx, ny, diag['xs'], Lm, sigma_pos, sign=+1)

        for n in self.nodes:
            px, py = T(n[0], n[1])
            dc.create_oval(px-3, py-3, px+3, py+3, fill='#555', outline='')

    #: One line under the mode radios saying what the pane is showing. It
    #: used to be a fixed caption describing the Vierendeel silhouettes,
    #: displayed in every mode including the two it does not describe.
    DIAG_HINTS = {
        # 'Truss diagrams' draws whichever the model actually has: one
        # signed N bar per rod on a pin-jointed truss, which carries no
        # shear or moment at all, and the V/M rows once a rod bends.
        'truss': 'the force in every member — shear and moment rows '
                 'appear once a rod is rigid',
        'vierendeel': 'shear silhouette left, moment silhouette right — '
                      'rigid rods only',
        'fiber': 'stress across each member’s depth — rigid rods only',
    }

    def _sync_diag_hint(self):
        try:
            self.diag_hint_var.set(
                self.DIAG_HINTS.get(self.diagram_mode.get(), ''))
        except Exception:
            pass

    def _draw_diagrams_only(self):
        """Draw the diagram pane in whichever mode is selected."""
        self._sync_diag_hint()
        if getattr(self, 'diagram_mode', None) is not None and self.diagram_mode.get() == 'vierendeel':
            self._draw_vierendeel_diagram()
            return
        if getattr(self, 'diagram_mode', None) is not None and self.diagram_mode.get() == 'fiber':
            self._draw_fiber_diagram()
            return
        if not self.diagrams:
            # The model was edited (or nodes/rods removed) since the last
            # analysis -- these diagrams would otherwise just keep showing
            # whatever was last computed, silently out of sync with the
            # current model. Make that explicit instead of leaving the old
            # drawing on screen.
            dc = self.diag_zc.canvas
            dc.delete('all')
            DW = dc.winfo_width() or INIT_CW
            DH = dc.winfo_height() or INIT_DH
            dc.create_text(DW/2, DH/2,
                           text='Model changed — re-run ▶ Analyze to refresh diagrams',
                           fill='#999', font=('Helvetica', 11))
            return

        dc = self.diag_zc.canvas
        w2s = self.diag_zc.w2s
        z = self.diag_zc.zoom
        dc.delete('all')

        # A member row has two independent, side-by-side panels.  Their X/Y
        # locations are calculated from the rod INDEX only, never from node
        # coordinates, member midpoint, or member orientation.  This makes
        # coincident/parallel rods impossible to overlay.
        rod_res_all = self.results.get('rod_res', []) if self.results else []
        n_max = max((abs(r.get('force', 0.0)) for r in rod_res_all),
                    default=0.0)

        def bends_of(diag):
            vs, ms = diag.get('V', []), diag.get('M', [])
            return max((abs(v) for v in list(vs) + list(ms)),
                       default=0.0) > 1e-9

        # A classic truss (every rod pinned, loads only at nodes) has no
        # shear or bending anywhere: it gets one compact signed bar per rod
        # -- the whole story on one screen -- instead of a tall row of empty
        # V/M boxes per rod.
        any_bends = any(bends_of(d) for d in self.diagrams)
        LEFT = 128.0
        N_W = 150.0 if any_bends else 520.0
        PANEL_W = 330.0
        PANEL_GAP = 88.0
        ROW_H = 128.0 if any_bends else 24.0
        ROW_GAP = 46.0 if any_bends else 6.0
        TOP = 42.0 if any_bends else 58.0
        x_n0 = LEFT
        x_v0 = LEFT + N_W + PANEL_GAP
        x_m0 = x_v0 + PANEL_W + PANEL_GAP

        def text(wx, wy, value, color='#444', bold=False, anchor='center'):
            sx, sy = w2s(wx, wy)
            dc.create_text(sx, sy, text=value, fill=color, anchor=anchor,
                           font=('Helvetica', max(7, int(8*z)), 'bold' if bold else 'normal'))

        def panel(rod_index, x0, y0, values, xs, length_m, color, title):
            half_h = ROW_H * 0.39
            zero_y = y0 + ROW_H / 2
            max_abs = max((abs(v) for v in values), default=0.0)
            # Keep an unloaded/pin member readable without dividing by zero.
            amplitude = half_h / (max_abs if max_abs > 1e-12 else 1.0)
            p0 = w2s(x0, y0)
            p1 = w2s(x0 + PANEL_W, y0 + ROW_H)
            dc.create_rectangle(p0[0], p0[1], p1[0], p1[1], outline='#dddddd')
            a0 = w2s(x0, zero_y)
            a1 = w2s(x0 + PANEL_W, zero_y)
            dc.create_line(a0[0], a0[1], a1[0], a1[1], fill='#bbbbbb')
            text(x0 + PANEL_W/2, y0 - 13, title, color, bold=True)
            # The largest value is already written at its peak; a second copy
            # here sat at zero_y, exactly on top of the "0".
            text(x0 - 9, zero_y, '0', '#777', anchor='e')

            points = []
            for x, value in zip(xs, values):
                frac = x / length_m if length_m > 1e-12 else 0.0
                sx, sy = w2s(x0 + max(0.0, min(1.0, frac))*PANEL_W,
                             zero_y - value*amplitude)
                points.extend((sx, sy))
            if len(points) >= 4:
                base_l = w2s(x0, zero_y)
                base_r = w2s(x0 + PANEL_W, zero_y)
                dc.create_polygon([base_l[0], base_l[1], *points, base_r[0], base_r[1]],
                                  fill=color, outline='', stipple='gray25')
                dc.create_line(points, fill=color, width=max(1, int(1.5*z)))
            if values:
                peak_i = max(range(len(values)), key=lambda i: abs(values[i]))
                peak = values[peak_i]
                if abs(peak) > 1e-12:
                    frac = xs[peak_i] / length_m if length_m > 1e-12 else 0.0
                    text(x0 + frac*PANEL_W, zero_y - peak*amplitude - (10 if peak >= 0 else -10),
                         f'{peak:.2f}', color, bold=True)

        def axial_panel(x0, y0, force):
            """N is constant along a rod, so its diagram is one signed bar:
            compression to the left of zero, tension to the right, both
            against the largest |N| in the model."""
            mid_x = x0 + N_W/2
            mid_y = y0 + ROW_H/2
            col = CT if force > 0.01 else (CC if force < -0.01 else CZ)
            frac = abs(force) / n_max if n_max > 1e-12 else 0.0
            reach = frac * (N_W/2 - 8) * (1 if force >= 0 else -1)
            hh = min(14.0, ROW_H*0.35)
            if any_bends:
                p0 = w2s(x0, y0)
                p1 = w2s(x0 + N_W, y0 + ROW_H)
                dc.create_rectangle(p0[0], p0[1], p1[0], p1[1],
                                    outline='#dddddd')
                text(mid_x, y0 - 13,
                     f'Axial force N ({self.u("force")})', '#555', bold=True)
            if abs(reach) > 0:
                b0 = w2s(min(mid_x, mid_x + reach), mid_y - hh)
                b1 = w2s(max(mid_x, mid_x + reach), mid_y + hh)
                dc.create_rectangle(b0[0], b0[1], b1[0], b1[1], fill=col,
                                    outline='')
            a0 = w2s(mid_x, (mid_y - hh - 4) if any_bends else y0 - 2)
            a1 = w2s(mid_x, (mid_y + hh + 4) if any_bends else y0 + ROW_H + 2)
            dc.create_line(a0[0], a0[1], a1[0], a1[1], fill='#999999')
            word = ('tension' if force > 0.01 else
                    'compression' if force < -0.01 else 'zero force')
            label = f'{self.show("force", force):+.2f}  {word}'
            if any_bends:
                text(mid_x, mid_y + 30, label, col, bold=True)
            else:
                text(x0 + N_W + 12, mid_y, label, col, bold=True, anchor='w')

        if any_bends:
            text(LEFT, 12, 'Ordered rod diagrams — one row per member', '#555', bold=True, anchor='w')
        else:
            F = self.u('force')
            text(LEFT, 12, f'Axial force N in every rod ({F})', '#555',
                 bold=True, anchor='w')
            text(LEFT, 28, 'Every rod is pinned and loaded only at its nodes, '
                 'so none carries shear or bending: the axial force is the '
                 'whole result.', '#888', anchor='w')
            text(LEFT + N_W/4, 44, '← compression', CC, bold=True)
            text(LEFT + 3*N_W/4, 44, 'tension →', CT, bold=True)
        rod_res_list = rod_res_all
        for i, diag in enumerate(self.diagrams):
            y0 = TOP + i * (ROW_H + ROW_GAP)
            length_m = diag.get('Lm', 1.0) or 1.0
            rr = rod_res_list[i] if i < len(rod_res_list) else None
            is_rigid = bool(rr) and rr.get('conn', 'pin') == 'rigid'
            axial_panel(x_n0, y0, rr.get('force', 0.0) if rr else 0.0)
            if not any_bends:
                text(LEFT - 12, y0 + ROW_H/2, f'Rod {i}', '#333', bold=True, anchor='e')
                continue
            # A flat zero line here has two very different causes -- a pin
            # rod that structurally cannot carry bending at all, versus a
            # rigid rod that happens to have solved to ~zero moment. Label
            # which one this is so a flat line is never ambiguous.
            kind_lbl = 'rigid joints' if is_rigid else 'pinned ends'
            text(LEFT - 12, y0 + ROW_H/2 - 8, f'Rod {i}', '#333', bold=True, anchor='e')
            text(LEFT - 12, y0 + ROW_H/2 + 8, kind_lbl, '#999', bold=False, anchor='e')
            if bends_of(diag):
                panel(i, x_v0, y0, diag.get('V', []), diag.get('xs', []), length_m,
                      CV, f'Shear V ({self.u("force")})')
                panel(i, x_m0, y0, diag.get('M', []), diag.get('xs', []), length_m,
                      CM, f'Moment M ({self.u("moment")})')
            else:
                # Two empty boxes taught nothing: say why they would be empty.
                why = ('no shear or bending: pinned at both ends and loaded '
                       'only at its nodes, so it carries axial force alone'
                       if not is_rigid else
                       'shear and moment solve to ~0 for this rod')
                text(x_v0, y0 + ROW_H/2, why, '#888', anchor='w')

    # ══════════════════════════════════════════════════════════════════════════
    #  On-screen reports  (Excel export/import is further down, at
    #  _export_excel / _import_excel -- this banner used to say "Excel export"
    #  and sat here, above the report windows, which is not what follows it.)
    #
    #  There was also a second diagram renderer here, _draw_diagrams_legacy_-
    #  overview: ~170 lines carrying its own private copy of the diagram
    #  scaling and layout logic, called from nowhere. Deleted 2026-09-06
    #  (DIAGNOSIS_TRUSS_2026-09-05 T-2). The live renderer -- the only one --
    #  is _draw_diagrams_only above; git history has the old one if it is ever
    #  wanted back.
    # ══════════════════════════════════════════════════════════════════════════
    def _show_node_vectors_report(self):
        """Node force vectors: every force on every joint, as cards.

        THE PDF'S CARDS, ON SCREEN (t 15, the owner: "this version is so
        much better and clearer than the one in the app"). The window
        used to build its own Tk free-body diagrams and Courier text
        boxes; it now shows the report's own Node force vectors sheets,
        drawn by truss_pdf from the same compute_node_design_actions --
        so the window and the PDF are one drawing and cannot disagree.
        """
        return self._show_card_report('nodes')

    def _draw_moment_arc(self, canvas, cx, cy, r, moment, color=CMOM, width=2.5,
                         start_angle=20, extent_mag=260, head_len=None):
        """
        Draws a circular-arrow glyph representing a moment: an arc plus a
        real, clearly visible arrowhead at its terminal end, centered at
        (cx, cy) with radius r on `canvas`. This is the ONE place that
        decides which way a moment arrow curls, so every depiction of a
        node moment in the app (main canvas, Node Force Vectors report,
        Rod Calculations report) uses the same rule and always agrees with
        the others.

        Convention: a positive moment (the sagging-positive convention used
        throughout this module) is drawn COUNTER-clockwise; a negative
        moment is drawn CLOCKWISE -- so the arrow always visually curls the
        way the moment would actually rotate the joint, not just a fixed
        color/side code. Tkinter's canvas angle system is already
        counter-clockwise-positive with 0 deg pointing right, so a positive
        `extent` directly gives a CCW arc with no extra sign bookkeeping.

        Arrowhead implementation note: an early version of this drew the
        head as a plain unstyled line segment tangent to the arc, which
        rendered as a barely-visible stub the same width as the arc itself
        -- it had no actual triangular head shape. This version instead
        draws the final short stretch of the sweep as its own straight
        chord with Tkinter's native `arrow='last'` line style (the exact
        same filled-triangle arrowhead already used for the force vectors
        elsewhere in this FBD, via `arrowshape`), which is what actually
        produces a real, clearly visible pointed head rather than an
        approximation of one.

        Returns (tip_x, tip_y) of the arrowhead tip, so callers can anchor
        a text label just outside the glyph without recomputing geometry.
        """
        extent = extent_mag if moment > 0 else -extent_mag
        # Reserve the last `head_span_deg` of the sweep for the arrowhead
        # chord instead of the full arc, so the head sits cleanly at the
        # tip without the arc's own stroke overlapping/burying it. Capped
        # so a small radius (e.g. the compact main-canvas glyph) doesn't
        # reserve more sweep than the arc actually has.
        head_span_deg = max(10, min(24, abs(extent) * 0.12))
        head_span = head_span_deg if extent > 0 else -head_span_deg
        arc_extent = extent - head_span

        canvas.create_arc(cx-r, cy-r, cx+r, cy+r, start=start_angle, extent=arc_extent,
                          style='arc', outline=color, width=width)

        a0 = math.radians(start_angle + arc_extent)
        a1 = math.radians(start_angle + extent)
        x0, y0 = cx + r*math.cos(a0), cy - r*math.sin(a0)
        x1, y1 = cx + r*math.cos(a1), cy - r*math.sin(a1)
        hl = head_len if head_len is not None else max(9, width*4)
        hw = max(6, hl*0.7)
        canvas.create_line(x0, y0, x1, y1, fill=color, width=width,
                           arrow='last', arrowshape=(hl, hl+2, hw))
        return x1, y1

    def _show_rod_calculations_report(self):
        """Rod calculations: one row per rod, as on the report's Rod
        calculations sheets -- see _show_node_vectors_report."""
        return self._show_card_report('rods')

    def _card_report(self, kind):
        """The _Report holding the card sheets of `kind` ('nodes' or
        'rods') for the model as solved, framed like the PDF's."""
        from . import truss_pdf, truss_report_prefs
        who = truss_report_prefs.load()
        rep = truss_pdf._Report(
            self.nodes, self.rods, self._active_supports(),
            self._design_loads(), self.results, self.rod_checks or [],
            self.profiles, self._report_title(), None,
            diagrams=self.diagrams, plates=self.plates,
            plate_checks=getattr(self, 'plate_checks', None),
            stability=getattr(self, '_stab', None),
            author=who['author'], course=who['course'])
        if kind == 'nodes':
            rep.node_vectors()
        else:
            rep.rod_calculations()
        rep.frame()
        return rep

    def _show_card_report(self, kind):
        title = ('Node force vectors' if kind == 'nodes'
                 else 'Rod calculations')
        if not self.results:
            messagebox.showwarning(title, 'Run the analysis first.')
            return None
        from common import _ensure_matplotlib
        if not _ensure_matplotlib():
            messagebox.showerror(title, 'This report needs matplotlib, '
                                 'which could not be installed. Run: pip '
                                 'install matplotlib pillow')
            return None
        from PIL import Image, ImageTk
        from matplotlib.backends.backend_agg import FigureCanvasAgg
        # A hundred-rod model takes a few seconds to draw: say so first.
        self.status_var.set('Drawing the %s cards…' % title.lower())
        try:
            self.root.update_idletasks()
        except tk.TclError:
            pass
        rep = self._card_report(kind)

        win = tk.Toplevel(self.root)
        win.title(title + ' — ' + self._report_title())
        win.geometry('1180x820')
        win.configure(bg='#8f979e')
        bar = tk.Frame(win, bg='#f5f5f3')
        bar.pack(fill='x')
        tk.Label(bar, text='%s — %d sheet%s, as in the PDF report' % (
            title, len(rep.sheets), '' if len(rep.sheets) == 1 else 's'),
            bg='#f5f5f3', fg='#1a6bbd',
            font=('Helvetica', 12, 'bold')).pack(side='left', padx=10,
                                                 pady=6)
        outer = tk.Frame(win, bg='#8f979e')
        outer.pack(fill='both', expand=True)
        sb = tk.Scrollbar(outer, orient='vertical')
        sc = tk.Canvas(outer, bg='#8f979e', highlightthickness=0,
                       yscrollcommand=sb.set)
        sb.config(command=sc.yview)
        sb.pack(side='right', fill='y')
        sc.pack(side='left', fill='both', expand=True)

        # The sheets as pictures, one under another: drawn by Agg at a
        # width that fits the window, so what is on screen is the page.
        width_px = 1120
        win._images = []
        y = 12
        for fig, _heading in rep.sheets:
            fig.set_dpi(width_px / fig.get_size_inches()[0])
            canvas = FigureCanvasAgg(fig)
            canvas.draw()
            w, h = canvas.get_width_height()
            img = Image.frombuffer('RGBA', (w, h), canvas.buffer_rgba(),
                                   'raw', 'RGBA', 0, 1)
            photo = ImageTk.PhotoImage(img, master=win)
            win._images.append(photo)
            sc.create_image(12, y, image=photo, anchor='nw')
            y += h + 12
        sc.configure(scrollregion=(0, 0, width_px + 24, y))
        # What the cards say, for anything that needs to read it back
        # (the plate test reads each joint's equilibrium line).
        win.card_texts = [t.get_text() for fig, _h in rep.sheets
                          for t in fig.texts
                          if t.get_gid() in ('node_table', 'calc_text')]
        win.sheet_count = len(rep.sheets)

        def save_pdf():
            from tkinter import filedialog
            from matplotlib.backends.backend_pdf import PdfPages
            path = filedialog.asksaveasfilename(
                parent=win, defaultextension='.pdf',
                filetypes=[('PDF', '*.pdf')], title='Save these sheets')
            if not path:
                return
            with PdfPages(path) as pdf:
                for fig, _h in rep.sheets:
                    pdf.savefig(fig)
            self.status_var.set('Saved %d %s sheet(s) to %s.' % (
                len(rep.sheets), title.lower(), os.path.basename(path)))
        win.save_pdf = save_pdf

        # bind_all, so the wheel scrolls wherever the pointer is over the
        # window -- and unbound again on close, or it keeps firing at a
        # destroyed canvas (see the Excel and stereo report windows).
        def _wheel(e):
            sc.yview_scroll(int(-1 * (e.delta / 120)), 'units')
        sc.bind_all('<MouseWheel>', _wheel)
        sc.bind_all('<Button-4>', lambda e: sc.yview_scroll(-3, 'units'))
        sc.bind_all('<Button-5>', lambda e: sc.yview_scroll(3, 'units'))

        def _close():
            for seq in ('<MouseWheel>', '<Button-4>', '<Button-5>'):
                sc.unbind_all(seq)
            win.destroy()
        win.protocol('WM_DELETE_WINDOW', _close)
        tk.Button(bar, text='Close', relief='flat', bg='#1a6bbd', fg='white',
                  font=('Helvetica', 10, 'bold'), padx=10,
                  command=_close).pack(side='right', padx=(4, 10), pady=6)
        tk.Button(bar, text='Save as PDF…', relief='flat', bg='#e2e6e4',
                  font=('Helvetica', 10), padx=10,
                  command=save_pdf).pack(side='right', pady=6)
        self._card_window = win
        self.status_var.set('%s: %d sheet(s), the same as in the PDF '
                            'report.' % (title, len(rep.sheets)))
        return win

    def _export_excel(self, _event=None):
        # truss_reports.export_excel has handled results=None all along --
        # its own comment says so. Only this guard stood in the way, which
        # meant a student who had placed twenty joints and had to leave
        # could not save them.
        # openpyxl is needed here, and is never installed behind the user
        if not _ensure_openpyxl():
            messagebox.showerror(
                'Missing library',
                'Excel import and export need the openpyxl library, which is not installed.\n\n'
                'Please open a terminal and run:\n'
                '    pip install openpyxl\n'
                'then try again.')
            return
        if not _ensure_matplotlib():
            self.status_var.set(
                'Note: matplotlib/Pillow unavailable — Excel export will skip '
                'the per-rod picture sheet but everything else still works.')
        path = filedialog.asksaveasfilename(
            defaultextension='.xlsx',
            filetypes=[('Excel workbook','*.xlsx')],
            initialfile='truss_report.xlsx',
            title='Save Excel report')
        if not path: return
        try:
            export_excel(self.nodes, self.rods, self.loads, self.supports,
                         self.results, path, profiles=self.profiles,
                         plates=self.plates, guides=self.guides)
            self.status_var.set(f'Excel report saved → {os.path.basename(path)}')
            messagebox.showinfo('Exported', f'Report saved to:\n{path}\n\n'
                                'Includes a "Model" sheet — use "Import Excel" '
                                'to rebuild this exact truss from the file later.')
        except Exception as e:
            messagebox.showerror('Export failed', str(e))

    def _import_excel(self):
        if not _ensure_openpyxl():
            messagebox.showerror(
                'Missing library',
                'Excel import and export need the openpyxl library, which is not installed.\n\n'
                'Please open a terminal and run:\n'
                '    pip install openpyxl\n'
                'then try again.')
            return
        path = filedialog.askopenfilename(
            filetypes=[('Excel workbook','*.xlsx')],
            title='Import truss from Excel')
        if not path: return
        try:
            (nodes, rods, loads, supports, profiles,
             plates, guides) = import_excel_model(path)
        except Exception as e:
            messagebox.showerror('Import failed', str(e)); return

        self._clear_all()
        self.document_name = os.path.basename(path)  # the window title names it
        self.nodes = [list(n) for n in nodes]
        self.rods = rods
        self.loads = loads
        self.supports = supports
        self.profiles = profiles
        self.plates = plates
        self.guides = guides
        self._refresh_guide_list()
        self._refresh_profile_combo()
        self._draw()
        extra = f', {len(plates)} plate(s)' if plates else ''
        self.status_var.set(
            f'Imported {len(nodes)} node(s), {len(rods)} rod(s){extra} from '
            f'{os.path.basename(path)} — click ▶ Analyze.')

    # ══════════════════════════════════════════════════════════════════════════
    #  Example / clear
    # ══════════════════════════════════════════════════════════════════════════
    def _load_example(self):
        self._push_undo('load example')
        self._clear_all(push_undo=False)
        ox,oy,sp,h = 96,288,120,96
        self.nodes=[
            (ox,oy),(ox+sp,oy-h),(ox+2*sp,oy),
            (ox+3*sp,oy-h),(ox+4*sp,oy)]
        self.rods=[
            {'a':0,'b':1,'E':200,'A':10,'profile':'Default'},
            {'a':1,'b':2,'E':200,'A':10,'profile':'Default'},
            {'a':2,'b':3,'E':200,'A':10,'profile':'Default'},
            {'a':3,'b':4,'E':200,'A':10,'profile':'Default'},
            {'a':0,'b':2,'E':200,'A':8,'profile':'Diagonal'},
            {'a':2,'b':4,'E':200,'A':8,'profile':'Diagonal'},
            {'a':1,'b':3,'E':200,'A':8,'profile':'Diagonal'}]
        self.profiles = {'Default': {'E':200.0,'A':10.0},
                         'Diagonal': {'E':200.0,'A':8.0}}
        self.supports=[{'node':0,'type':'pin'},{'node':4,'type':'rollerX'}]
        self.loads=[{'node':1,'fx':0,'fy':30},
                    {'node':2,'fx':0,'fy':60},
                    {'node':3,'fx':0,'fy':30}]
        self._refresh_profile_combo()
        self._draw()
        self.status_var.set('Warren truss loaded — click ▶ Analyze.')

    def _load_example_vierendeel(self):
        self._push_undo('load Vierendeel example')
        self._clear_all(push_undo=False)
        ox, oy, sp, h = 96, 288, 120, 96
        # bottom chord: nodes 0-4 ; top chord: nodes 5-9 ; no diagonals —
        # every rod is 'rigid' (moment-connected), which is what lets a
        # Vierendeel girder carry load without any diagonal bracing.
        self.nodes = [(ox+i*sp, oy) for i in range(5)] + \
                     [(ox+i*sp, oy-h) for i in range(5)]

        def rigid(a, b):
            return {'a': a, 'b': b, 'E': 200.0, 'A': 10.0, 'I': 8000.0,
                    'conn': 'rigid', 'profile': 'Default'}

        self.rods = (
            [rigid(i, i+1) for i in range(4)] +        # bottom chord
            [rigid(5+i, 6+i) for i in range(4)] +       # top chord
            [rigid(i, 5+i) for i in range(5)]           # verticals (no diagonals)
        )
        self.profiles = {'Default': {'E': 200.0, 'A': 10.0, 'I': 8000.0}}
        self.supports = [{'node': 0, 'type': 'pin'}, {'node': 4, 'type': 'rollerX'}]
        self.loads = [{'node': 6, 'fx': 0, 'fy': 20},
                      {'node': 7, 'fx': 0, 'fy': 20},
                      {'node': 8, 'fx': 0, 'fy': 20}]
        self._refresh_profile_combo()
        self._draw()
        self.status_var.set(
            'Vierendeel girder loaded (all rods rigid, no diagonals) — click ▶ Analyze. '
            'Select rods + "Set Pinned" to turn any of them back into a classic truss bar.')

    def _clear_all(self, push_undo=True):
        if push_undo:
            self._push_undo('clear all')
        self.document_name = None          # a new drawing: "Truss drawing"
        self.nodes=[];self.rods=[];self.loads=[];self.supports=[]
        self.plates=[];self.plate_checks=[]
        self.guides=[]
        self.results=None;self.diagrams=None
        self.selected_nodes=set();self.selected_rods=set();self.rod_start=None
        self.pending_load=set();self.pending_sup=set()
        self.profiles={'Default': {'E':200.0,'A':10.0,'I':8000.0}}
        self.load_frame.pack_forget();self.sup_frame.pack_forget()
        self.rod_res_frame.pack_forget();self.rxn_frame.pack_forget()
        self.plate_res_frame.pack_forget()
        self._show_results_placeholder()
        self.res_var.set('')
        self.show_deform.set(False)
        self.shell.hide_lower()
        self.diag_zc.canvas.delete('all')
        if hasattr(self, '_refresh_profile_combo'): self._refresh_profile_combo()
        self._show_sel();self._draw()
        if hasattr(self, '_forget_example'):
            self._forget_example()
        self.status_var.set('Cleared. Start with the Node tool.')
